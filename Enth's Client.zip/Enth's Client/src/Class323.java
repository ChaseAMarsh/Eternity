/* Class323 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class323 {
	static int anInt3362 = 34;
	static int anInt3363 = 1;
	static int anInt3364 = 2;
	static int anInt3365 = 3;
	static int anInt3366 = 64;
	static int anInt3367 = 5;
	static int anInt3368 = 6;
	static int anInt3369 = 7;
	static int anInt3370 = 38;
	static int anInt3371 = 9;
	static int anInt3372 = 65;
	static int anInt3373 = 11;
	static int anInt3374 = 12;
	static int anInt3375 = 68;
	static int anInt3376 = 13;
	static int anInt3377 = 18;
	static int anInt3378 = 19;
	static int anInt3379 = 20;
	static int anInt3380 = 100;
	static int anInt3381 = 22;
	public static int anInt3382 = 84;
	static int anInt3383 = 24;
	static int anInt3384 = 25;
	static int anInt3385 = 26;
	static int anInt3386 = 27;
	static int anInt3387 = 71;
	static int anInt3388 = 33;
	static int anInt3389 = 55;
	static int anInt3390 = 32;
	static int anInt3391 = 90;
	static int anInt3392 = 37;
	public static int anInt3393 = 101;
	public static int anInt3394 = 86;
	static int anInt3395 = 40;
	static int anInt3396 = 41;
	static int anInt3397 = 42;
	static int anInt3398 = 43;
	static int anInt3399 = 48;
	static int anInt3400 = 49;
	static int anInt3401 = 50;
	static int anInt3402 = 74;
	static int anInt3403 = 52;
	static int anInt3404 = 53;
	static int anInt3405 = 10;
	static int anInt3406 = 4;
	static int anInt3407 = 56;
	static int anInt3408 = 57;
	static int anInt3409 = 58;
	static int anInt3410 = 39;
	static int anInt3411 = 54;
	static int anInt3412 = 8;
	public static int anInt3413 = 67;
	static int anInt3414 = 17;
	static int anInt3415 = 35;
	static int anInt3416 = 70;
	static int anInt3417 = 69;
	static int anInt3418 = 98;
	static int anInt3419 = 73;
	public static int anInt3420 = 80;
	public static int anInt3421 = 81;
	public static int anInt3422 = 82;
	static int anInt3423 = 83;
	static int anInt3424 = 23;
	public static int anInt3425 = 85;
	static int anInt3426 = 51;
	static int anInt3427 = 59;
	static int anInt3428 = 36;
	static int anInt3429 = 28;
	static int anInt3430 = 87;
	static int anInt3431 = 88;
	static int anInt3432 = 89;
	static int anInt3433 = 21;
	static int anInt3434 = 91;
	public static int anInt3435 = 96;
	public static int anInt3436 = 97;
	public static int anInt3437 = 66;
	static int anInt3438 = 99;
	static int anInt3439 = 16;
	static int anInt3440 = 72;
	public static int anInt3441 = 102;
	public static int anInt3442 = 103;
	public static int anInt3443 = 104;
	public static int anInt3444 = 105;

	public abstract void method3934();

	public abstract void method3935();

	public abstract boolean method3936(int i, int i_0_);

	public abstract Interface16 method3937(byte i);

	public abstract void method3938(int i);

	public abstract Interface16 method3939();

	public abstract Interface16 method3940();

	Class323() {
		/* empty */
	}

	public abstract void method3941();

	public abstract void method3942(int i);

	public abstract void method3943();

	public abstract void method3944();

	public abstract boolean method3945(int i);

	static final void method3946(ClientScript2 class403, int i) {
		try {
			int i_1_ = Class431.anInt6502 * -1012194159;
			int i_2_ = 1953279233 * Class249.anInt6465;
			int i_3_ = -1;
			if (Class452.aBoolean5642) {
				Class456[] class456s = Class271.method2545((byte) -2);
				for (int i_4_ = 0; i_4_ < class456s.length; i_4_++) {
					Class456 class456 = class456s[i_4_];
					if (i_1_ == class456.anInt5663 * 28445523 && class456.anInt5665 * 262154323 == i_2_) {
						i_3_ = i_4_;
						break;
					}
				}
			}
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_3_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nl.aeu(").append(')').toString());
		}
	}

	static final void method3947(IComponentDefinition class105, Class119 class119, ClientScript2 class403, int i) {
		try {
			if (4 == class105.anInt1144 * -1215239439)
				Class165.method1781(class105, class119, class403, (short) 8629);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nl.gx(").append(')').toString());
		}
	}

	static void method3948(GraphicsToolkit class_ra, int i, int i_5_, int i_6_, int i_7_, int i_8_, int i_9_, byte i_10_) {
		try {
			class_ra.method5015(i, i_5_, i_6_, i_7_, i_8_, (byte) 7);
			class_ra.method5015(1 + i, 1 + i_5_, i_6_ - 2, 16, i_9_, (byte) 7);
			class_ra.method5014(1 + i, 18 + i_5_, i_6_ - 2, i_7_ - 19, i_9_, -1588493317);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nl.aq(").append(')').toString());
		}
	}

	static final void method3949(ClientScript2 class403, byte i) {
		try {
			String string = (String) (((ClientScript2) class403).anObjectArray5240[(((ClientScript2) class403).anInt5241 -= 969361751) * -203050393]);
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_11_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919]);
			int i_12_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919 + 1]);
			Class505 class505 = Class322.method3931(Class173.aClass243_1758, i_12_, 0, (byte) 49);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = class505.method6259(string, i_11_, Class130_Sub2.aClass57Array6959, -1274509130);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nl.zn(").append(')').toString());
		}
	}
}
