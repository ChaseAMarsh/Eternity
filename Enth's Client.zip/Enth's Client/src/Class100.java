/* Class100 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class100 {
	static Class100 aClass100_953;
	static Class100 aClass100_954;
	static Class100 aClass100_955;
	static Class100 aClass100_956;
	static Class100 aClass100_957;
	static Class100 aClass100_958;
	static Class100 aClass100_959;
	static Class100 aClass100_960;
	static Class100 aClass100_961;
	static Class100 aClass100_962;
	public static Class100 aClass100_963;
	static Class100 aClass100_964;
	static Class100 aClass100_965;
	static Class100 aClass100_966;
	static Class100 aClass100_967;
	static Class100 aClass100_968;
	static Class100 aClass100_969;
	static Class100 aClass100_970;
	static Class100 aClass100_971;
	static Class100 aClass100_972;
	static Class100 aClass100_973;
	static Class100 aClass100_974;
	static Class100 aClass100_975 = new Class100(99);
	static Class100 aClass100_976;
	public static Class100 aClass100_977;
	static Class100 aClass100_978;
	static Class100 aClass100_979;
	static Class100 aClass100_980;
	static Class100 aClass100_981;
	static Class100 aClass100_982;
	static Class100 aClass100_983;
	static Class100 aClass100_984;
	static Class100 aClass100_985;
	static Class100 aClass100_986;
	static Class100 aClass100_987;
	static Class100 aClass100_988;
	static Class100 aClass100_989;
	static Class100 aClass100_990;
	static Class100 aClass100_991;
	static Class100 aClass100_992;
	static Class100 aClass100_993;
	static Class100 aClass100_994;
	public static Class100 aClass100_995;
	public static Class100 aClass100_996;
	static Class100 aClass100_997;
	static Class100 aClass100_998;
	static Class100 aClass100_999;
	static Class100 aClass100_1000;
	public static Class100 aClass100_1001;
	static Class100 aClass100_1002;
	static Class100 aClass100_1003;
	static Class100 aClass100_1004;
	static Class100 aClass100_1005;
	static Class100 aClass100_1006;
	static Class100 aClass100_1007;
	static Class100 aClass100_1008;
	static Class100 aClass100_1009;
	static Class100 aClass100_1010;
	static Class100 aClass100_1011;
	static Class100 aClass100_1012;
	static Class100 aClass100_1013;
	static Class100 aClass100_1014;
	static Class100 aClass100_1015;
	static Class100 aClass100_1016;
	static Class100 aClass100_1017;
	static Class100 aClass100_1018;
	static Class100 aClass100_1019;
	static Class100 aClass100_1020;
	static Class100 aClass100_1021;
	static Class100 aClass100_1022;
	public static Class100 aClass100_1023;
	static Class100 aClass100_1024;
	static Class100 aClass100_1025;
	static Class100 aClass100_1026;
	static Class100 aClass100_1027;
	static Class100 aClass100_1028;
	static Class100 aClass100_1029;
	static Class100 aClass100_1030;
	static Class100 aClass100_1031;
	static Class100 aClass100_1032;
	static Class100 aClass100_1033;
	static Class100 aClass100_1034;
	static Class100 aClass100_1035;
	static Class100 aClass100_1036;
	static Class100 aClass100_1037;
	static Class100 aClass100_1038;
	static Class100 aClass100_1039;
	static Class100 aClass100_1040;
	static Class100 aClass100_1041;
	static Class100 aClass100_1042;
	static Class100 aClass100_1043;
	static Class100 aClass100_1044;
	static Class100 aClass100_1045;
	static Class100 aClass100_1046;
	static Class100 aClass100_1047;
	static Class100 aClass100_1048;
	public static Class100 aClass100_1049;
	static Class100 aClass100_1050;
	static Class100 aClass100_1051;
	static Class100 aClass100_1052;
	static Class100 aClass100_1053;
	static Class100 aClass100_1054;
	static Class100 aClass100_1055;
	static Class100 aClass100_1056;
	static Class100 aClass100_1057;
	static Class100 aClass100_1058;
	static Class100 aClass100_1059;
	static Class100 aClass100_1060;
	static Class100 aClass100_1061;
	static Class100 aClass100_1062;
	static Class100 aClass100_1063;
	static Class100 aClass100_1064;
	static Class100 aClass100_1065;
	static Class100 aClass100_1066;
	static Class100 aClass100_1067;
	static Class100 aClass100_1068;
	static Class100 aClass100_1069;
	static Class100 aClass100_1070;
	static Class100 aClass100_1071;
	public int anInt1072;
	static Class100 aClass100_1073;
	static Class100 aClass100_1074;
	static Class100 aClass100_1075;
	public static Class100 aClass100_1076;
	static Class100 aClass100_1077;
	static Class100 aClass100_1078;
	public static int anInt1079;
	static Class456[] aClass456Array1080;
	public static int anInt1081;

	static {
		aClass100_954 = new Class100(64);
		aClass100_1076 = new Class100(4);
		aClass100_956 = new Class100(63);
		aClass100_957 = new Class100(108);
		aClass100_958 = new Class100(119);
		aClass100_959 = new Class100(46);
		aClass100_1033 = new Class100(123);
		aClass100_961 = new Class100(45);
		aClass100_1042 = new Class100(26);
		aClass100_1028 = new Class100(16);
		aClass100_964 = new Class100(40);
		aClass100_1069 = new Class100(81);
		aClass100_966 = new Class100(120);
		aClass100_984 = new Class100(5);
		aClass100_968 = new Class100(78);
		aClass100_969 = new Class100(33);
		aClass100_970 = new Class100(58);
		aClass100_971 = new Class100(124);
		aClass100_994 = new Class100(95);
		aClass100_1058 = new Class100(42);
		aClass100_967 = new Class100(41);
		aClass100_1073 = new Class100(88);
		aClass100_976 = new Class100(44);
		aClass100_977 = new Class100(75);
		aClass100_1049 = new Class100(80);
		aClass100_995 = new Class100(82);
		aClass100_1001 = new Class100(1);
		aClass100_973 = new Class100(74);
		aClass100_960 = new Class100(111);
		aClass100_983 = new Class100(29);
		aClass100_1031 = new Class100(77);
		aClass100_985 = new Class100(21);
		aClass100_986 = new Class100(2);
		aClass100_987 = new Class100(87);
		aClass100_988 = new Class100(15);
		aClass100_989 = new Class100(53);
		aClass100_990 = new Class100(122);
		aClass100_991 = new Class100(28);
		aClass100_992 = new Class100(91);
		aClass100_1051 = new Class100(39);
		aClass100_963 = new Class100(13);
		aClass100_1078 = new Class100(25);
		aClass100_996 = new Class100(31);
		aClass100_997 = new Class100(79);
		aClass100_998 = new Class100(70);
		aClass100_999 = new Class100(34);
		aClass100_1000 = new Class100(37);
		aClass100_965 = new Class100(116);
		aClass100_1002 = new Class100(7);
		aClass100_1003 = new Class100(109);
		aClass100_1004 = new Class100(84);
		aClass100_1005 = new Class100(90);
		aClass100_1050 = new Class100(85);
		aClass100_1007 = new Class100(8);
		aClass100_1008 = new Class100(101);
		aClass100_1009 = new Class100(20);
		aClass100_1010 = new Class100(54);
		aClass100_1040 = new Class100(51);
		aClass100_1012 = new Class100(55);
		aClass100_1013 = new Class100(17);
		aClass100_1014 = new Class100(49);
		aClass100_1015 = new Class100(10);
		aClass100_981 = new Class100(36);
		aClass100_1018 = new Class100(43);
		aClass100_1025 = new Class100(48);
		aClass100_1019 = new Class100(60);
		aClass100_1020 = new Class100(83);
		aClass100_1021 = new Class100(73);
		aClass100_1022 = new Class100(0);
		aClass100_1023 = new Class100(104);
		aClass100_1024 = new Class100(96);
		aClass100_1041 = new Class100(89);
		aClass100_1026 = new Class100(35);
		aClass100_1027 = new Class100(86);
		aClass100_978 = new Class100(62);
		aClass100_1029 = new Class100(97);
		aClass100_953 = new Class100(93);
		aClass100_1075 = new Class100(66);
		aClass100_1032 = new Class100(57);
		aClass100_980 = new Class100(71);
		aClass100_1034 = new Class100(76);
		aClass100_1039 = new Class100(56);
		aClass100_1036 = new Class100(121);
		aClass100_1037 = new Class100(38);
		aClass100_1030 = new Class100(22);
		aClass100_1064 = new Class100(113);
		aClass100_1035 = new Class100(100);
		aClass100_1061 = new Class100(110);
		aClass100_1006 = new Class100(72);
		aClass100_1043 = new Class100(52);
		aClass100_1044 = new Class100(27);
		aClass100_1038 = new Class100(65);
		aClass100_1046 = new Class100(98);
		aClass100_955 = new Class100(9);
		aClass100_1048 = new Class100(23);
		aClass100_1077 = new Class100(32);
		aClass100_974 = new Class100(106);
		aClass100_962 = new Class100(103);
		aClass100_1052 = new Class100(92);
		aClass100_993 = new Class100(68);
		aClass100_1054 = new Class100(118);
		aClass100_1016 = new Class100(67);
		aClass100_1056 = new Class100(61);
		aClass100_1057 = new Class100(115);
		aClass100_972 = new Class100(24);
		aClass100_1059 = new Class100(94);
		aClass100_1060 = new Class100(117);
		aClass100_1047 = new Class100(19);
		aClass100_1062 = new Class100(107);
		aClass100_1063 = new Class100(105);
		aClass100_1045 = new Class100(12);
		aClass100_1065 = new Class100(30);
		aClass100_1066 = new Class100(69);
		aClass100_1067 = new Class100(47);
		aClass100_1068 = new Class100(18);
		aClass100_1055 = new Class100(6);
		aClass100_1070 = new Class100(14);
		aClass100_1071 = new Class100(3);
		aClass100_982 = new Class100(114);
		aClass100_1053 = new Class100(112);
		aClass100_1074 = new Class100(59);
		aClass100_979 = new Class100(50);
		aClass100_1017 = new Class100(102);
		aClass100_1011 = new Class100(11);
	}

	Class100(int i) {
		anInt1072 = i * -1700037047;
	}

	static final void method1073(ClientScript2 class403, byte i) {
		try {
			IComponentDefinition class105 = Class50.getIComponentDefinitions((((ClientScript2) class403).anIntArray5244[(((ClientScript2) class403).anInt5239 -= -391880689) * 681479919]), (byte) -124);
			class105.aClass105Array1292 = null;
			class105.aClass105Array1293 = null;
			Tradution.method6054(class105, -1793194156);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("eb.bj(").append(')').toString());
		}
	}

	static final void method1074(ClientScript2 class403, int i) {
		try {
			Class298_Sub37_Sub13.method3455((((ClientScript2) class403).anIntArray5244[(((ClientScript2) class403).anInt5239 -= -391880689) * 681479919]), -1482618001);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("eb.xy(").append(')').toString());
		}
	}

	static final void method1075(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_0_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239]);
			int i_1_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919 + 1]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = (GraphicsToolkit.aClass256_5315.method2441(i_0_, 537859491).anIntArray9598[i_1_]);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("eb.acu(").append(')').toString());
		}
	}

	static final void method1076(ClientScript2 class403, int i) {
		try {
			int i_2_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			if (!Class373.aClass_ra4071.method5032())
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = 3;
			else
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub13_7549.method5612(i_2_, 1352882135);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("eb.aou(").append(')').toString());
		}
	}

	static final void method1077(ClientScript2 class403, int i) {
		try {
			if (Class452.aBoolean5642) {
				Class456[] class456s = Class271.method2545((byte) -22);
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = class456s.length;
			} else
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("eb.aec(").append(')').toString());
		}
	}

	static final void method1078(ClientScript2 class403, short i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class229.method2123(1029121048);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("eb.adw(").append(')').toString());
		}
	}
}
