/* Class203 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class203 {
	public static int anInt2311 = 6;
	public static int anInt2312 = 26;
	public static int anInt2313 = 1;
	public static int anInt2314 = 14;
	public static int anInt2315 = 24;
	public static int anInt2316 = 8;
	public static int anInt2317 = 9;
	public static int anInt2318 = 22;
	public static int anInt2319 = 16;
	public static int anInt2320 = 10;
	public static int anInt2321 = 15;
	public static int anInt2322 = 2;
	public static int anInt2323 = 3;
	public static int anInt2324 = 4;
	public static int anInt2325 = 25;
	public static int anInt2326 = 27;
	public static int anInt2327 = 23;
	public static int anInt2328 = 21;
	public static int anInt2329 = 29;
	public static int anInt2330 = 7;
	public static int anInt2331 = 13;
	public static int anInt2332 = 17;
	public static int anInt2333 = 5;
	public static int anInt2334 = 11;
	public static int anInt2335 = 28;
	public static int anInt2336 = 20;
	public static Class225 aClass225_2337;

	Class203() throws Throwable {
		throw new Error();
	}

	static void method1908(Class298_Sub46 class298_sub46, int i, short i_0_) {
		try {
			Object[] parameters = class298_sub46.anObjectArray7530;
			int i_1_ = ((Integer) parameters[0]).intValue();
			ClientScript class298_sub37_sub17 = Class216.getClientScript(i_1_, (byte) 1);
			if (null != class298_sub37_sub17) {
				ClientScript2 class403 = Class211.method1950(974537460);
				((ClientScript2) class403).anIntArray5248 = new int[class298_sub37_sub17.anInt9679 * -1516159487];
				int i_2_ = 0;
				((ClientScript2) class403).anObjectArray5234 = new String[class298_sub37_sub17.anInt9680 * 1787035509];
				int i_3_ = 0;
				((ClientScript2) class403).aLongArray5235 = new long[1679522843 * class298_sub37_sub17.anInt9681];
				int i_4_ = 0;
				for (int i_5_ = 1; i_5_ < parameters.length; i_5_++) {
					if (parameters[i_5_] instanceof Integer) {
						int i_6_ = ((Integer) parameters[i_5_]).intValue();
						if (-2147483647 == i_6_)
							i_6_ = class298_sub46.anInt7526 * 1893415363;
						if (i_6_ == -2147483646)
							i_6_ = -54723935 * class298_sub46.anInt7527;
						if (i_6_ == -2147483645)
							i_6_ = (class298_sub46.aClass105_7525 != null ? -440872681 * (class298_sub46.aClass105_7525.anInt1142) : -1);
						if (-2147483644 == i_6_)
							i_6_ = 426539335 * class298_sub46.anInt7528;
						if (-2147483643 == i_6_)
							i_6_ = (class298_sub46.aClass105_7525 != null ? -1309843523 * (class298_sub46.aClass105_7525.anInt1154) : -1);
						if (-2147483642 == i_6_)
							i_6_ = (null != class298_sub46.aClass105_7529 ? -440872681 * (class298_sub46.aClass105_7529.anInt1142) : -1);
						if (i_6_ == -2147483641)
							i_6_ = (class298_sub46.aClass105_7529 != null ? (class298_sub46.aClass105_7529.anInt1154 * -1309843523) : -1);
						if (-2147483640 == i_6_)
							i_6_ = -1652898593 * class298_sub46.anInt7532;
						if (-2147483639 == i_6_)
							i_6_ = class298_sub46.anInt7531 * -2080757995;
						((ClientScript2) class403).anIntArray5248[i_2_++] = i_6_;
					} else if (parameters[i_5_] instanceof String) {
						String string = (String) parameters[i_5_];
						if (string.equals("event_opbase"))
							string = class298_sub46.aString7523;
						((ClientScript2) class403).anObjectArray5234[i_3_++] = string;
					} else if (parameters[i_5_] instanceof Long) {
						long l = ((Long) parameters[i_5_]).longValue();
						((ClientScript2) class403).aLongArray5235[i_4_++] = l;
					}
				}
				((ClientScript2) class403).anInt5254 = ((Class298_Sub46) class298_sub46).anInt7524 * -323690565;
				ClientScriptsExecutor.method4690(class298_sub37_sub17, i, class403, 546888884);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("io.k(").append(')').toString());
		}
	}

	static final void method1909(ClientScript2 class403, int i) {
		try {
			Class390 class390 = (((ClientScript2) class403).aBoolean5261 ? ((ClientScript2) class403).aClass390_5247 : ((ClientScript2) class403).aClass390_5246);
			IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
			Class119 class119 = ((Class390) class390).aClass119_4167;
			IComponentDefinition class105_7_ = Class523.method6331(class119, class105, -1926129754);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = (null == class105_7_ ? -1 : class105_7_.anInt1142 * -440872681);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("io.oq(").append(')').toString());
		}
	}

	public static void method1910(int i) {
		try {
			try {
				if (1 == 617004265 * Class79.anInt734) {
					int i_8_ = Class79.aClass298_Sub19_Sub1_737.method2953((byte) -56);
					if (i_8_ > 0 && Class79.aClass298_Sub19_Sub1_737.method2985(747355627)) {
						i_8_ -= Class298_Sub24_Sub1.anInt9276 * -1503744809;
						if (i_8_ < 0)
							i_8_ = 0;
						Class79.aClass298_Sub19_Sub1_737.method2961(i_8_, 2100644467);
						return;
					}
					Class79.aClass298_Sub19_Sub1_737.method2959((byte) -38);
					Class79.aClass298_Sub19_Sub1_737.method2957((byte) 81);
					if (Class79.aClass243_744 != null)
						Class79.anInt734 = 1770763954;
					else
						Class79.anInt734 = 0;
					Class417.aClass298_Sub13_5337 = null;
					Class298_Sub32_Sub22.aClass272_9466 = null;
				}
				if (3 == Class79.anInt734 * 617004265) {
					int i_9_ = Class79.aClass298_Sub19_Sub1_737.method2953((byte) -5);
					if (i_9_ < Class79.anInt739 * 643426275 && Class79.aClass298_Sub19_Sub1_737.method2985(1822181710)) {
						i_9_ += 604206485 * Class401.anInt6559;
						if (i_9_ > 643426275 * Class79.anInt739)
							i_9_ = 643426275 * Class79.anInt739;
						Class79.aClass298_Sub19_Sub1_737.method2961(i_9_, 1707423851);
					} else {
						Class401.anInt6559 = 0;
						Class79.anInt734 = 0;
					}
				}
			} catch (Exception exception) {
				exception.printStackTrace();
				Class79.aClass298_Sub19_Sub1_737.method2959((byte) 3);
				Class11.method329(-1137434141);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("io.y(").append(')').toString());
		}
	}
}
