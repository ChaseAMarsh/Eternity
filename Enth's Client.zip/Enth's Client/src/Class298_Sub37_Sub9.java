/* Class298_Sub37_Sub9 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class298_Sub37_Sub9 extends Class298_Sub37 {
	int anInt9600;

	abstract boolean method3436();

	abstract Object method3437(int i);

	abstract boolean method3438(int i);

	abstract boolean method3439();

	abstract Object method3440();

	abstract boolean method3441();

	Class298_Sub37_Sub9(int i) {
		((Class298_Sub37_Sub9) this).anInt9600 = 1222339519 * i;
	}

	abstract Object method3442();
}
