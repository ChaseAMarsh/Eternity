/* Class201 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class201 {
	public static int anInt2100 = 1;
	public static int anInt2101 = 131072;
	public static int anInt2102 = 131072;
	public static int anInt2103 = 32;
	public static int anInt2104 = 64;
	public static int anInt2105 = 262144;
	public static int anInt2106 = 512;
	public static int anInt2107 = 2;
	public static int anInt2108 = 4096;
	public static int anInt2109 = 16;
	public static int anInt2110 = 65536;
	public static int anInt2111 = 512;
	public static int anInt2112 = 2048;
	public static int anInt2113 = 16384;
	public static int anInt2114 = 128;
	public static int anInt2115 = 1024;
	public static int anInt2116 = 2097152;
	public static int anInt2117 = 4194304;
	public static int anInt2118 = 1048576;
	public static int anInt2119 = 1048576;
	public static int anInt2120 = 8;
	public static int anInt2121 = 65536;
	public static int anInt2122 = 524288;
	public static int anInt2123 = 32768;
	public static int anInt2124 = 128;
	public static int anInt2125 = 4;
	public static int anInt2126 = 16;
	public static int anInt2127 = 32;
	public static int anInt2128 = 4;
	public static int anInt2129 = 1;
	public static int anInt2130 = 2097152;
	public static int anInt2131 = 2;
	public static int anInt2132 = 16384;
	public static int anInt2133 = 1024;
	public static int anInt2134 = 256;
	public static int anInt2135 = 33554432;
	public static int anInt2136 = 8;
	public static int anInt2137 = 4096;
	public static int anInt2138 = 8192;
	public static int anInt2139 = 32768;
	public static int anInt2140 = 8388608;
	public static int anInt2141 = 8388608;
	public static int anInt2142 = 262144;
	public static int anInt2143 = 8192;
	public static int anInt2144 = 256;
	public static int anInt2145 = 4194304;
	public static int anInt2146 = 524288;
	public static int anInt2147 = 2048;
	public static int anInt2148 = 16777216;
	public static int anInt2149 = 64;

	Class201() throws Throwable {
		throw new Error();
	}

	public static synchronized void method1900(byte[] is, int i) {
		try {
			if (100 == is.length && 355907107 * Class416.anInt5330 < 1000)
				Class416.aByteArrayArray5332[(Class416.anInt5330 += -996497013) * 355907107 - 1] = is;
			else if (5000 == is.length && Class416.anInt5328 * 1904890379 < 250)
				Class416.aByteArrayArray5327[(Class416.anInt5328 += -1583470173) * 1904890379 - 1] = is;
			else if (30000 == is.length && -1426745913 * Class416.anInt5329 < 50)
				Class416.aByteArrayArray5333[(Class416.anInt5329 += 1975229431) * -1426745913 - 1] = is;
			else if (Class298_Sub37_Sub9_Sub2.aByteArrayArrayArray10001 != null) {
				for (int i_0_ = 0; i_0_ < Class136.anIntArray6388.length; i_0_++) {
					if (is.length == Class136.anIntArray6388[i_0_] && (Class416.anIntArray5331[i_0_] < (Class298_Sub37_Sub9_Sub2.aByteArrayArrayArray10001[i_0_]).length)) {
						Class298_Sub37_Sub9_Sub2.aByteArrayArrayArray10001[i_0_][Class416.anIntArray5331[i_0_]++] = is;
						break;
					}
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("im.f(").append(')').toString());
		}
	}

	static final void method1901(ClientScript2 class403, int i) {
		try {
			int i_1_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_1_ & 0x3fff;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("im.te(").append(')').toString());
		}
	}

	public static int method1902(byte i) {
		try {
			return 1197525581 * Class344.anInt3675;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("im.k(").append(')').toString());
		}
	}
}
