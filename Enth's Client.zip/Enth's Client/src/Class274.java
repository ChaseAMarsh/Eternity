/* Class274 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class274 implements Interface21 {
	static Class274 aClass274_6529;
	public static Class274 aClass274_6530;
	static Class274 aClass274_6531;
	static Class274 aClass274_6532;
	public int anInt6533;
	static Class274 aClass274_6534;
	static Class274 aClass274_6535;
	static Class274 aClass274_6536 = new Class274(7, 0);
	static Class274 aClass274_6537;
	int anInt6538;
	static Class57 aClass57_6539;

	public int method244() {
		return 1575163887 * ((Class274) this).anInt6538;
	}

	public Class274 method2567(byte i) {
		try {
			switch (anInt6533 * 495490839) {
			case 3:
				return aClass274_6534;
			case 1:
				return aClass274_6537;
			case 0:
				return aClass274_6531;
			case 7:
				return aClass274_6530;
			case 4:
				return aClass274_6532;
			case 6:
				return aClass274_6535;
			case 5:
				return aClass274_6529;
			case 2:
				return aClass274_6536;
			default:
				throw new IllegalStateException();
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("lj.b(").append(')').toString());
		}
	}

	static {
		aClass274_6529 = new Class274(3, 1);
		aClass274_6537 = new Class274(6, 2);
		aClass274_6532 = new Class274(0, 3);
		aClass274_6530 = new Class274(2, 4);
		aClass274_6534 = new Class274(5, 5);
		aClass274_6535 = new Class274(1, 6);
		aClass274_6531 = new Class274(4, 7);
	}

	public int method242(int i) {
		try {
			return 1575163887 * ((Class274) this).anInt6538;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("lj.f(").append(')').toString());
		}
	}

	public int method243() {
		return 1575163887 * ((Class274) this).anInt6538;
	}

	Class274(int i, int i_0_) {
		anInt6533 = i * 699142311;
		((Class274) this).anInt6538 = i_0_ * 1812395791;
	}

	static final void method2568(ClientScript2 class403, int i) {
		try {
			int i_1_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_1_, (byte) -68);
			Class119 class119 = Class389.aClass119Array4165[i_1_ >> 16];
			Class518.method6315(class105, class119, class403, 783841228);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("lj.fg(").append(')').toString());
		}
	}

	static final void method2569(ClientScript2 class403, int i) {
		try {
			Class390 class390 = (((ClientScript2) class403).aBoolean5261 ? ((ClientScript2) class403).aClass390_5247 : ((ClientScript2) class403).aClass390_5246);
			IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
			Class119 class119 = ((Class390) class390).aClass119_4167;
			Class298_Sub32_Sub5.method3174(class105, class119, class403, -1683091614);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("lj.nk(").append(')').toString());
		}
	}
}
