/* Class290 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class290 {
	static int anInt3156 = 62;
	static int anInt3157 = 2;
	static int anInt3158 = 16;
	static int anInt3159 = 1;
	static int anInt3160 = 8;
	static int anInt3161 = 63;

	Class290() throws Throwable {
		throw new Error();
	}

	static final void method2747(ClientScript2 class403, int i) {
		try {
			IComponentDefinition class105 = Class50.getIComponentDefinitions((((ClientScript2) class403).anIntArray5244[(((ClientScript2) class403).anInt5239 -= -391880689) * 681479919]), (byte) -49);
			if (-1232467723 * class105.anInt1280 != -1)
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = -66163287 * class105.anInt1281;
			else
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("mb.rw(").append(')').toString());
		}
	}

	static final void method2748(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_0_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239]);
			int i_1_ = (((ClientScript2) class403).anIntArray5244[1 + ((ClientScript2) class403).anInt5239 * 681479919]);
			((ClientScript2) class403).aClass177_5243.anIntArray1789[i_0_] = i_1_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("mb.adb(").append(')').toString());
		}
	}

	public static final int method2749(int i, int i_2_, int i_3_) {
		try {
			if (-1 == i)
				return 12345678;
			i_2_ = (i & 0x7f) * i_2_ >> 7;
			if (i_2_ < 2)
				i_2_ = 2;
			else if (i_2_ > 126)
				i_2_ = 126;
			return (i & 0xff80) + i_2_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("mb.q(").append(')').toString());
		}
	}

	public static void method2750(int i, int i_4_) {
		try {
			Class298_Sub37_Sub12 class298_sub37_sub12 = Class410.method4985(22, (long) i);
			class298_sub37_sub12.method3445(-926641552);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("mb.d(").append(')').toString());
		}
	}
}
