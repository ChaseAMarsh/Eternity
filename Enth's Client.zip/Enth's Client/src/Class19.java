/* Class19 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class19 {
	public int anInt256;
	public int anInt257;
	int anInt258;
	int anInt259;
	public int anInt260;
	public int anInt261;
	int anInt262;
	public int anInt263 = 698073157;
	static CachingHashMap aClass348_264 = new CachingHashMap(4);
	int anInt265;
	public int anInt266;

	Class19() {
		/* empty */
	}

	static final void method363(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = null != Class313.anObjectArray3298 ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("at.yl(").append(')').toString());
		}
	}
}
