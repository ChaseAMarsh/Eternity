/* Class151 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class151 implements Interface5 {
	public int anInt6345;
	public int anInt6346;
	public int anInt6347;
	public int anInt6348;
	public int anInt6349;
	public int anInt6350;
	public Class133 aClass133_6351;
	public Class139 aClass139_6352;
	public String aString6353;
	public int anInt6354;
	public int anInt6355;
	public int anInt6356;
	public int anInt6357;
	public static Class451 aClass451_6358;

	public Class146 method49(int i) {
		try {
			return Class146.aClass146_1564;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("gc.f(").append(')').toString());
		}
	}

	public Class146 method50() {
		return Class146.aClass146_1564;
	}

	public Class146 method51() {
		return Class146.aClass146_1564;
	}

	Class151(String string, Class139 class139, Class133 class133, int i, int i_0_, int i_1_, int i_2_, int i_3_, int i_4_, int i_5_, int i_6_, int i_7_, int i_8_) {
		aString6353 = string;
		aClass139_6352 = class139;
		aClass133_6351 = class133;
		anInt6348 = 983212181 * i;
		anInt6349 = 703753783 * i_0_;
		anInt6350 = -719694677 * i_1_;
		anInt6345 = i_2_ * 1732454243;
		anInt6354 = i_3_ * -1607745933;
		anInt6346 = -2102344545 * i_4_;
		anInt6347 = -299852093 * i_5_;
		anInt6355 = i_6_ * 299588697;
		anInt6356 = -732046791 * i_7_;
		anInt6357 = -1239794753 * i_8_;
	}

	public static Class182 method1643(int i, int i_9_) {
		try {
			Class182 class182 = (Class182) Class182.aClass348_1815.get((long) i);
			if (class182 != null)
				return class182;
			byte[] is = Class182.aClass243_1821.getFileFromArchive(0, i, (byte) -125);
			class182 = new Class182();
			if (null != is)
				class182.method1843(new RsByteBuffer(is), (byte) 20);
			class182.method1845(-721593745);
			Class182.aClass348_1815.method4194(class182, (long) i);
			return class182;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("gc.f(").append(')').toString());
		}
	}

	static boolean method1644(int i) {
		try {
			return Class492.method6184(Class144.aClass381_1563.aClass355_4114, -1572506836);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("gc.a(").append(')').toString());
		}
	}

	static final void method1645(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).aLongArray5251[((((ClientScript2) class403).anInt5245 += -682569305) * 1685767703 - 1)] = (((ClientScript2) class403).aClass298_Sub37_Sub17_5260.aLongArray9677[1883543357 * ((ClientScript2) class403).integerPos]);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("gc.bf(").append(')').toString());
		}
	}

	static boolean method1646(int i, int i_10_) {
		try {
			return i == 18 || i == 16;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("gc.fg(").append(')').toString());
		}
	}

	static final void method1647(ClientScript2 class403, int i) {
		try {
			Class390 class390 = (((ClientScript2) class403).aBoolean5261 ? ((ClientScript2) class403).aClass390_5247 : ((ClientScript2) class403).aClass390_5246);
			IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
			Class119 class119 = ((Class390) class390).aClass119_4167;
			Class244.method2323(class105, class119, class403, 2046664396);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("gc.gt(").append(')').toString());
		}
	}

	public static final void method1648(int i) {
		try {
			if (!client.aBoolean8761) {
				client.aFloat8760 += (-12.0F - client.aFloat8760) / 2.0F;
				client.aBoolean8763 = true;
				client.aBoolean8761 = true;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("gc.hq(").append(')').toString());
		}
	}

	static final void method1649(ClientScript2 class403, int i) {
		try {
			Class365_Sub1_Sub2_Sub1.method4499((byte) -5);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("gc.aet(").append(')').toString());
		}
	}
}
