/* Class336_Sub5 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class336_Sub5 extends Class336 {
	int routeType;

	public boolean method4090(int i, int i_0_, int i_1_, Class289 class289, int i_2_) {
		try {
			return class289.method2739(i_0_, i_1_, i, toX * -1331662251, 1517720743 * toY, sizeX * -1900284579, 772610897 * sizeY, (((Class336_Sub5) this).routeType * -759942815), -86275969);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acp.a(").append(')').toString());
		}
	}

	public boolean method4091(int i, int i_3_, int i_4_, Class289 class289) {
		return class289.method2739(i_3_, i_4_, i, toX * -1331662251, 1517720743 * toY, sizeX * -1900284579, 772610897 * sizeY, (((Class336_Sub5) this).routeType * -759942815), -86275969);
	}

	public boolean method4089(int i, int i_5_, int i_6_, Class289 class289) {
		return class289.method2739(i_5_, i_6_, i, toX * -1331662251, 1517720743 * toY, sizeX * -1900284579, 772610897 * sizeY, (((Class336_Sub5) this).routeType * -759942815), -86275969);
	}

	Class336_Sub5() {
		/* empty */
	}

	public static Class336 method4105(int i, int i_7_, int i_8_, int i_9_, Class424 class424, int i_10_, int i_11_) {
		try {
			Class315.aClass336_Sub1_3308.toX = -760677635 * i;
			Class315.aClass336_Sub1_3308.toY = 167105303 * i_7_;
			Class315.aClass336_Sub1_3308.sizeX = -1544157451 * i_8_;
			Class315.aClass336_Sub1_3308.sizeY = -1468199503 * i_9_;
			((Class336_Sub1) Class315.aClass336_Sub1_3308).aClass424_7712 = class424;
			((Class336_Sub1) Class315.aClass336_Sub1_3308).anInt7711 = i_10_ * 393356885;
			return Class315.aClass336_Sub1_3308;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acp.i(").append(')').toString());
		}
	}
}
