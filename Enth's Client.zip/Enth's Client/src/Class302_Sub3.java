/* Class302_Sub3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class302_Sub3 extends Class302 {
	public Class302_Sub3 aClass302_Sub3_7649;
	public Class302_Sub3 aClass302_Sub3_7650;

	public void method3721(int i) {
		try {
			if (null != aClass302_Sub3_7649) {
				aClass302_Sub3_7649.aClass302_Sub3_7650 = aClass302_Sub3_7650;
				aClass302_Sub3_7650.aClass302_Sub3_7649 = aClass302_Sub3_7649;
				aClass302_Sub3_7650 = null;
				aClass302_Sub3_7649 = null;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aap.b(").append(')').toString());
		}
	}

	public static void method3722(short i) {
		try {
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub17_7564, 2, 933731200);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub17_7565, 2, 15061497);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub2_7547, 1, -996473537);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub28_7573, 1, -1713418665);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub25_7569, 1, -779153916);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub9_7555, 1, 408587278);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub18_7561, 1, -771369154);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub16_7557, 1, -652941935);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub7_7581, 1, -1471206550);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub15_7560, 1, 383050729);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub5_7572, 0, -742030026);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub3_7556, 1, -361136273);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub13_7549, 0, -802724940);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub13_7550, 0, -1875981876);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub4_7563, 1, 1215494852);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub11_7558, Class115.aClass115_1383.anInt1387 * -160182505, -342617786);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub6_7551, 0, -952954318);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub19_7567, 1, 571491634);
			Class490.method6170(1113089752);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub8_7566, 1, -2045258023);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub23_7576, 3, -496921634);
			Class359.method4294(-32585668);
			client.aClass283_8716.method2640((byte) 54).method4324(-1309443074);
			client.aBoolean8676 = true;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aap.u(").append(')').toString());
		}
	}

	static final void method3723(ClientScript2 class403, int i) {
		try {
			int i_0_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_0_, (byte) 8);
			Class119 class119 = Class389.aClass119Array4165[i_0_ >> 16];
			Class214.method1989(class105, class119, class403, (byte) 121);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aap.ks(").append(')').toString());
		}
	}
}
