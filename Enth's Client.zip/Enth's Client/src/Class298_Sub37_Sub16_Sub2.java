/* Class298_Sub37_Sub16_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub37_Sub16_Sub2 extends Class298_Sub37_Sub16 {
	int anInt10006;
	static int anInt10007 = 1;
	static int anInt10008 = 3;
	static int anInt10009 = 2;
	Class329 aClass329_10010;
	byte[] aByteArray10011;

	Class298_Sub37_Sub16_Sub2() {
		/* empty */
	}

	byte[] method3469() {
		if (((Class298_Sub37_Sub16_Sub2) this).aBoolean9670)
			throw new RuntimeException();
		return ((Class298_Sub37_Sub16_Sub2) this).aByteArray10011;
	}

	int method3471() {
		if (((Class298_Sub37_Sub16_Sub2) this).aBoolean9670)
			return 0;
		return 100;
	}

	byte[] method3467() {
		if (((Class298_Sub37_Sub16_Sub2) this).aBoolean9670)
			throw new RuntimeException();
		return ((Class298_Sub37_Sub16_Sub2) this).aByteArray10011;
	}

	byte[] method3466() {
		if (((Class298_Sub37_Sub16_Sub2) this).aBoolean9670)
			throw new RuntimeException();
		return ((Class298_Sub37_Sub16_Sub2) this).aByteArray10011;
	}

	int method3468(int i) {
		try {
			if (((Class298_Sub37_Sub16_Sub2) this).aBoolean9670)
				return 0;
			return 100;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aks.f(").append(')').toString());
		}
	}

	int method3470() {
		if (((Class298_Sub37_Sub16_Sub2) this).aBoolean9670)
			return 0;
		return 100;
	}

	byte[] method3465(short i) {
		try {
			if (((Class298_Sub37_Sub16_Sub2) this).aBoolean9670)
				throw new RuntimeException();
			return ((Class298_Sub37_Sub16_Sub2) this).aByteArray10011;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aks.a(").append(')').toString());
		}
	}

	int method3472() {
		if (((Class298_Sub37_Sub16_Sub2) this).aBoolean9670)
			return 0;
		return 100;
	}
}
