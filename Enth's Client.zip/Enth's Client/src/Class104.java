/* Class104 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class104 {
	int anInt1109;
	byte[] aByteArray1110;
	int anInt1111;
	int anInt1112;
	int anInt1113;
	byte[] aByteArray1114;
	int anInt1115;
	int anInt1116;
	int anInt1117;

	Class104() {
		/* empty */
	}

	static final void method1101(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5239 -= -1175642067;
			long l = (long) (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239]);
			long l_0_ = (long) (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239 + 1]);
			long l_1_ = (long) (((ClientScript2) class403).anIntArray5244[2 + ((ClientScript2) class403).anInt5239 * 681479919]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = (int) (l_1_ * l / l_0_);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ef.zk(").append(')').toString());
		}
	}

	static final void method1102(ClientScript2 class403, int i) {
		try {
			int i_2_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			((ClientScript2) class403).anObjectArray5240[((((ClientScript2) class403).anInt5241 += 969361751) * -203050393 - 1)] = Class285.method2709(i_2_, -1648336964);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ef.zv(").append(')').toString());
		}
	}

	static final void method1103(Entity class365_sub1_sub1_sub2, int i) {
		try {
			Class438 class438 = class365_sub1_sub1_sub2.aClass438_10078;
			if ((client.anInt8884 * 443738891 == class365_sub1_sub1_sub2.anInt10103 * 1450943713) || !class438.method5819((byte) -78) || class438.method5836(1, 2027501470)) {
				int i_3_ = (class365_sub1_sub1_sub2.anInt10103 * 1450943713 - class365_sub1_sub1_sub2.anInt10095 * -412225079);
				int i_4_ = (443738891 * client.anInt8884 - -412225079 * class365_sub1_sub1_sub2.anInt10095);
				int i_5_ = (class365_sub1_sub1_sub2.anInt10098 * -719582720 + class365_sub1_sub1_sub2.getSize() * 256);
				int i_6_ = (1363846656 * class365_sub1_sub1_sub2.anInt10100 + class365_sub1_sub1_sub2.getSize() * 256);
				int i_7_ = (1613909504 * class365_sub1_sub1_sub2.anInt10099 + class365_sub1_sub1_sub2.getSize() * 256);
				int i_8_ = (class365_sub1_sub1_sub2.anInt10101 * 1970654720 + class365_sub1_sub1_sub2.getSize() * 256);
				Class217 class217 = class365_sub1_sub1_sub2.method4337().aClass217_2599;
				class365_sub1_sub1_sub2.method4341((float) ((i_5_ * (i_3_ - i_4_) + i_4_ * i_7_) / i_3_), (float) (int) class217.aFloat2455, (float) ((i_4_ * i_8_ + (i_3_ - i_4_) * i_6_) / i_3_));
			}
			class365_sub1_sub1_sub2.anInt10124 = 0;
			class365_sub1_sub1_sub2.method4415((class365_sub1_sub1_sub2.anInt10104) * -251594591, false, 943014126);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ef.hp(").append(')').toString());
		}
	}

	static final void method1104(int i) {
		try {
			Class83.aClass105Array764 = null;
			Class448.method5912(client.WINDOW_PANE_ID * -257444687, 0, 0, Class462.anInt5683 * -2110394505, Class298_Sub40_Sub9.anInt9716 * -1111710645, 0, 0, -1, 421170136);
			if (null != Class83.aClass105Array764) {
				Class422_Sub24.method5714(Class83.aClass105Array764, -1412584499, 0, 0, Class462.anInt5683 * -2110394505, -1111710645 * Class298_Sub40_Sub9.anInt9716, Class216.anInt6660 * -391533651, LinkedList.anInt5518 * -514549911, (Class82_Sub3.aClass105_6825 == client.aClass105_8712 ? -1 : client.aClass105_8712.anInt1303 * 91937559), true, (byte) 0);
				Class83.aClass105Array764 = null;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ef.kl(").append(')').toString());
		}
	}

	static final void method1105(ClientScript2 class403, int i) {
		try {
			int i_9_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_9_, (byte) -19);
			Class119 class119 = Class389.aClass119Array4165[i_9_ >> 16];
			Class75.method835(class105, class119, class403, (byte) -113);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ef.jj(").append(')').toString());
		}
	}

	static final void method1106(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = (((ClientScript2) class403).anIntArray5248[(((ClientScript2) class403).integerstack[1883543357 * ((ClientScript2) class403).integerPos])]);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ef.az(").append(')').toString());
		}
	}

	public static String method1107(Class298_Sub37_Sub15 class298_sub37_sub15, byte i) {
		try {
			if (Class436.aBoolean5478 || null == class298_sub37_sub15)
				return "";
			if (((((Class298_Sub37_Sub15) class298_sub37_sub15).aString9657 == null) || ((Class298_Sub37_Sub15) class298_sub37_sub15).aString9657.length() == 0) && null != (((Class298_Sub37_Sub15) class298_sub37_sub15).aString9669) && ((Class298_Sub37_Sub15) class298_sub37_sub15).aString9669.length() > 0)
				return (((Class298_Sub37_Sub15) class298_sub37_sub15).aString9669);
			return ((Class298_Sub37_Sub15) class298_sub37_sub15).aString9657;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ef.as(").append(')').toString());
		}
	}

	public static void method1108(int i, int i_10_) {
		try {
			Class79.anInt734 = -1262101671;
			Class79.aClass243_744 = null;
			Class79.anInt745 = 407545223;
			Class79.anInt746 = 956029523;
			Class79.aClass298_Sub19_Sub1_748 = null;
			Class79.anInt739 = 0;
			Class8.aBoolean114 = false;
			Class298_Sub24_Sub1.anInt9276 = 771950311 * i;
			Class313.aClass97_3300 = null;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ef.q(").append(')').toString());
		}
	}
}
