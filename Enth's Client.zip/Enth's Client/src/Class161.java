/* Class161 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class161 {
	protected Class_ra_Sub3 aClass_ra_Sub3_1648;

	void method1712() {
		/* empty */
	}

	abstract void method1713();

	abstract void method1714();

	void method1715(int i) {
		/* empty */
	}

	void method1716() {
		/* empty */
	}

	Class161(Class_ra_Sub3 class_ra_sub3) {
		aClass_ra_Sub3_1648 = class_ra_sub3;
	}

	abstract void method1717();

	abstract void method1718();

	abstract void method1719();

	abstract void method1720();

	abstract void method1721();

	abstract void method1722();

	void method1723() {
		/* empty */
	}

	abstract void method1724();
}
