/* Class298_Sub37_Sub15 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub37_Sub15 extends Class298_Sub37 {
	String aString9657;
	int anInt9658;
	int anInt9659;
	int anInt9660;
	long aLong9661;
	int anInt9662;
	int anInt9663;
	boolean aBoolean9664;
	boolean aBoolean9665;
	long aLong9666;
	String aString9667;
	boolean aBoolean9668;
	String aString9669;

	Class298_Sub37_Sub15(String string, String string_0_, int i, int i_1_, int i_2_, long l, int i_3_, int i_4_, boolean bool, boolean bool_5_, long l_6_, boolean bool_7_) {
		((Class298_Sub37_Sub15) this).aString9657 = string_0_;
		((Class298_Sub37_Sub15) this).aString9667 = string;
		((Class298_Sub37_Sub15) this).anInt9659 = 1854492667 * i;
		((Class298_Sub37_Sub15) this).anInt9662 = i_1_ * 233648799;
		((Class298_Sub37_Sub15) this).anInt9660 = i_2_ * 1821305099;
		((Class298_Sub37_Sub15) this).aLong9661 = -4396451777151645697L * l;
		((Class298_Sub37_Sub15) this).anInt9658 = i_3_ * 622278169;
		((Class298_Sub37_Sub15) this).anInt9663 = 643860849 * i_4_;
		((Class298_Sub37_Sub15) this).aBoolean9664 = bool;
		((Class298_Sub37_Sub15) this).aBoolean9665 = bool_5_;
		((Class298_Sub37_Sub15) this).aLong9666 = l_6_ * -5795929892862797165L;
		((Class298_Sub37_Sub15) this).aBoolean9668 = bool_7_;
	}
}
