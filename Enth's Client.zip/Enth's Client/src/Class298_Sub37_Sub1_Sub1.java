/* Class298_Sub37_Sub1_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub37_Sub1_Sub1 extends Class298_Sub37_Sub1 {
	Object anObject9998;

	Class298_Sub37_Sub1_Sub1(Interface18 interface18, Object object, int i) {
		super(interface18, i);
		((Class298_Sub37_Sub1_Sub1) this).anObject9998 = object;
	}

	boolean method3409() {
		return false;
	}

	boolean method3407() {
		return false;
	}

	Object method3410() {
		return ((Class298_Sub37_Sub1_Sub1) this).anObject9998;
	}

	Object method3408() {
		return ((Class298_Sub37_Sub1_Sub1) this).anObject9998;
	}

	Object method3406() {
		return ((Class298_Sub37_Sub1_Sub1) this).anObject9998;
	}
}
