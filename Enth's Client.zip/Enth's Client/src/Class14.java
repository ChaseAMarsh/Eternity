/* Class14 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class14 {
	static int anInt168;
	static Class89[] aClass89Array169;
	static int anInt170;
	static Class139 aClass139_171;
	static int anInt172;
	static int anInt173;
	static int anInt174;
	static int anInt175;
	static Class505 aClass505_176;
	static Class133 aClass133_177;

	Class14() throws Throwable {
		throw new Error();
	}

	public static void method341(int i, int[] is, int i_0_) {
		try {
			if (i != -1 && Class378.method4671(i, is, -2060750983)) {
				IComponentDefinition[] class105s = Class389.aClass119Array4165[i].aClass105Array1405;
				Graphics.method611(class105s, -1178956884);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ao.p(").append(')').toString());
		}
	}

	static final void method342(ClientScript2 class403, int i) {
		try {
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub30_7575, (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]) != 0 ? 1 : 0, -261887884);
			Class3.method300(656179282);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ao.air(").append(')').toString());
		}
	}

	static final void method343(ClientScript2 class403, int i) {
		try {
			int i_1_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_1_, (byte) -45);
			Class119 class119 = Class389.aClass119Array4165[i_1_ >> 16];
			Class79.method851(class105, class119, class403, -1849275031);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ao.ek(").append(')').toString());
		}
	}

	public static void method344(int i) {
		try {
			Class323_Sub1.method3955(-1, 255, 328240529);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ao.o(").append(')').toString());
		}
	}

	static final void method345(ClientScript2 class403, int i) {
		try {
			int i_2_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			if (i_2_ < 0 || i_2_ > 5)
				i_2_ = 2;
			Class370.method4578(i_2_, false, 622850291);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ao.aic(").append(')').toString());
		}
	}

	static final void method346(byte i) {
		try {
			for (Class298_Sub37_Sub2 class298_sub37_sub2 = ((Class298_Sub37_Sub2) client.aClass453_8824.method5939(1766612795)); null != class298_sub37_sub2; class298_sub37_sub2 = ((Class298_Sub37_Sub2) client.aClass453_8824.method5944(49146))) {
				Class365_Sub1_Sub1_Sub1 class365_sub1_sub1_sub1 = (((Class298_Sub37_Sub2) class298_sub37_sub2).aClass365_Sub1_Sub1_Sub1_9577);
				if (443738891 * client.anInt8884 > class365_sub1_sub1_sub1.anInt10049 * -1349988959) {
					class298_sub37_sub2.method2839(-1460969981);
					class365_sub1_sub1_sub1.method4411(686828159);
				} else if (client.anInt8884 * 443738891 >= (class365_sub1_sub1_sub1.anInt10044 * 1113390887)) {
					class365_sub1_sub1_sub1.method4406(-36689971);
					if (1894383945 * class365_sub1_sub1_sub1.anInt10058 > 0) {
						if (1596783995 * client.anInt8724 == 0) {
							Entity class365_sub1_sub1_sub2 = Class87.aClass94Array794[(class365_sub1_sub1_sub1.anInt10058 * 1894383945) - 1].method1015(1231902873);
							if (null != class365_sub1_sub1_sub2) {
								Class217 class217 = (class365_sub1_sub1_sub2.method4337().aClass217_2599);
								if ((int) class217.aFloat2451 >= 0 && ((int) class217.aFloat2451 < client.aClass283_8716.method2629(-1942094391) * 512) && (int) class217.aFloat2454 >= 0 && ((int) class217.aFloat2454 < client.aClass283_8716.method2630(-1804151587) * 512))
									class365_sub1_sub1_sub1.method4405((int) class217.aFloat2451, (int) class217.aFloat2454, ((Class356.method4271((int) class217.aFloat2451, (int) class217.aFloat2454, class365_sub1_sub1_sub2.plane, -1503815167)) - (2134079017 * (class365_sub1_sub1_sub1.anInt10045))), 443738891 * client.anInt8884, 1121215352);
							}
						} else {
							Class298_Sub29 class298_sub29 = ((Class298_Sub29) (client.aClass437_8696.method5812((long) ((1894383945 * (class365_sub1_sub1_sub1.anInt10058)) - 1))));
							if (class298_sub29 != null) {
								NPC class365_sub1_sub1_sub2_sub1 = ((NPC) class298_sub29.anObject7366);
								Class217 class217 = (class365_sub1_sub1_sub2_sub1.method4337().aClass217_2599);
								if ((int) class217.aFloat2451 >= 0 && ((int) class217.aFloat2451 < client.aClass283_8716.method2629(-1876273086) * 512) && (int) class217.aFloat2454 >= 0 && ((int) class217.aFloat2454 < client.aClass283_8716.method2630(-203309822) * 512))
									class365_sub1_sub1_sub1.method4405((int) class217.aFloat2451, (int) class217.aFloat2454, ((Class356.method4271((int) class217.aFloat2451, (int) class217.aFloat2454, class365_sub1_sub1_sub1.plane, -1366613250)) - (class365_sub1_sub1_sub1.anInt10045 * 2134079017)), client.anInt8884 * 443738891, 2031199219);
							}
						}
					}
					if (1894383945 * class365_sub1_sub1_sub1.anInt10058 < 0) {
						int i_3_ = (-(class365_sub1_sub1_sub1.anInt10058 * 1894383945) - 1);
						Player class365_sub1_sub1_sub2_sub2;
						if (i_3_ == -442628795 * client.playerIndex)
							class365_sub1_sub1_sub2_sub2 = Class287.myPlayer;
						else
							class365_sub1_sub1_sub2_sub2 = (client.aClass365_Sub1_Sub1_Sub2_Sub2Array8805[i_3_]);
						if (null != class365_sub1_sub1_sub2_sub2) {
							Class217 class217 = (class365_sub1_sub1_sub2_sub2.method4337().aClass217_2599);
							if ((int) class217.aFloat2451 >= 0 && ((int) class217.aFloat2451 < client.aClass283_8716.method2629(-1981087344) * 512) && (int) class217.aFloat2454 >= 0 && ((int) class217.aFloat2454 < client.aClass283_8716.method2630(-1284142631) * 512))
								class365_sub1_sub1_sub1.method4405((int) class217.aFloat2451, (int) class217.aFloat2454, ((Class356.method4271((int) class217.aFloat2451, (int) class217.aFloat2454, class365_sub1_sub1_sub1.plane, -1135065402)) - (class365_sub1_sub1_sub1.anInt10045 * 2134079017)), 443738891 * client.anInt8884, 1831333850);
						}
					}
					class365_sub1_sub1_sub1.method4407(client.anInt8961 * 614680345, (byte) 63);
					client.aClass283_8716.method2675(-1611682495).method4022(class365_sub1_sub1_sub1, true, (byte) 0);
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ao.ie(").append(')').toString());
		}
	}
}
