/* Class298_Sub37_Sub9_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub37_Sub9_Sub1 extends Class298_Sub37_Sub9 {
	Object anObject10000;

	boolean method3439() {
		return false;
	}

	Object method3437(int i) {
		try {
			return ((Class298_Sub37_Sub9_Sub1) this).anObject10000;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aki.a(").append(')').toString());
		}
	}

	boolean method3438(int i) {
		try {
			return false;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aki.f(").append(')').toString());
		}
	}

	Object method3440() {
		return ((Class298_Sub37_Sub9_Sub1) this).anObject10000;
	}

	Class298_Sub37_Sub9_Sub1(Object object, int i) {
		super(i);
		((Class298_Sub37_Sub9_Sub1) this).anObject10000 = object;
	}

	boolean method3441() {
		return false;
	}

	Object method3442() {
		return ((Class298_Sub37_Sub9_Sub1) this).anObject10000;
	}

	boolean method3436() {
		return false;
	}
}
