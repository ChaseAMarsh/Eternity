/* Class20 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class20 {
	short aShort267;
	byte aByte268;
	short aShort269;
	short aShort270;
	int anInt271 = -1;
	short aShort272;
	short aShort273;

	Class20() {
		/* empty */
	}
}
