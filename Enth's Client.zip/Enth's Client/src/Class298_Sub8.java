/* Class298_Sub8 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class298_Sub8 extends Class298 {
	boolean aBoolean7221;
	Class_ra_Sub2 aClass_ra_Sub2_7222;

	abstract void method2867();

	abstract boolean method2868();

	abstract boolean method2869();

	abstract void method2870();

	abstract void method2871(int i, int i_0_);

	abstract void method2872(int i, Class30_Sub2 class30_sub2, Class30_Sub2 class30_sub2_1_);

	abstract void method2873(int i);

	int method2874() {
		return 1;
	}

	Class298_Sub8(Class_ra_Sub2 class_ra_sub2) {
		((Class298_Sub8) this).aClass_ra_Sub2_7222 = class_ra_sub2;
	}

	Class77 method2875() {
		return Class77.aClass77_717;
	}

	abstract boolean method2876();

	abstract void method2877(int i, Class30_Sub2 class30_sub2, Class30_Sub2 class30_sub2_2_);

	abstract void method2878(int i, Class30_Sub2 class30_sub2, Class30_Sub2 class30_sub2_3_);

	abstract void method2879(int i);

	abstract void method2880(int i);

	boolean method2881() {
		return false;
	}

	abstract boolean method2882();

	abstract void method2883(int i, int i_4_);

	abstract boolean method2884();

	abstract void method2885(int i, int i_5_);

	boolean method2886() {
		return ((Class298_Sub8) this).aBoolean7221;
	}
}
