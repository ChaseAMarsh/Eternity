/* Class302_Sub3_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class302_Sub3_Sub1 extends Class302_Sub3 {
	public int anInt9785;
	public static int anInt9786 = 12;
	public boolean aBoolean9787;
	public static int anInt9788 = 8191;
	public int anInt9789;
	public int anInt9790;
	public int anInt9791;
	public int anInt9792;
	public byte aByte9793 = 5;
	public int anInt9794;

	Class302_Sub3_Sub1() {
		/* empty */
	}
}
