/* Class298_Sub24_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jagtheora.ogg.OggPacket;
import jagtheora.ogg.OggStreamState;

public class Class298_Sub24_Sub2 extends Class298_Sub24 {
	void method3078(OggPacket oggpacket) {
		/* empty */
	}

	void method3075(int i) {
		try {
			/* empty */
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajd.b(").append(')').toString());
		}
	}

	void method3074(OggPacket oggpacket, int i) {
		try {
			/* empty */
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajd.f(").append(')').toString());
		}
	}

	void method3076(OggPacket oggpacket) {
		/* empty */
	}

	void method3077(OggPacket oggpacket) {
		/* empty */
	}

	Class298_Sub24_Sub2(OggStreamState oggstreamstate) {
		super(oggstreamstate);
	}

	void method3072() {
		/* empty */
	}

	void method3079() {
		/* empty */
	}
}
