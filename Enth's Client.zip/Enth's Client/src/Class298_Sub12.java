/* Class298_Sub12 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub12 extends Class298 {
	int anInt7256;
	public int anInt7257;

	Class298_Sub12(int i, int i_0_) {
		anInt7257 = i * 388289509;
		((Class298_Sub12) this).anInt7256 = i_0_ * -1076181017;
	}
}
