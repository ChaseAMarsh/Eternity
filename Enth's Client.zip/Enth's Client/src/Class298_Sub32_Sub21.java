/* Class298_Sub32_Sub21 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub32_Sub21 extends Class298_Sub32 {
	static int anInt9453 = 3;
	static int anInt9454 = 1;
	static int anInt9455 = 0;
	int[] anIntArray9456 = new int[257];
	static int anInt9457 = 4;
	static int anInt9458 = 5;
	static int anInt9459 = 6;
	static int anInt9460 = 2;
	int[][] anIntArrayArray9461;

	void method3264(int i, int i_0_) {
		try {
			if (0 != i) {
				switch (i) {
				case 2:
					((Class298_Sub32_Sub21) this).anIntArrayArray9461 = new int[8][4];
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][0] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][1] = 2650;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][2] = 2602;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][3] = 2361;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][0] = 2867;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][1] = 2313;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][2] = 1799;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][3] = 1558;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][0] = 3072;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][1] = 2618;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][2] = 1734;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][3] = 1413;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][0] = 3276;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][1] = 2296;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][2] = 1220;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][3] = 947;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][0] = 3481;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][1] = 2072;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][2] = 963;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][3] = 722;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][0] = 3686;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][1] = 2730;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][2] = 2152;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][3] = 1766;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][0] = 3891;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][1] = 2232;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][2] = 1060;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][3] = 915;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[7][0] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[7][1] = 1686;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[7][2] = 1413;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[7][3] = 1140;
					break;
				case 1:
					((Class298_Sub32_Sub21) this).anIntArrayArray9461 = new int[2][4];
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][0] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][1] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][2] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][3] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][0] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][1] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][2] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][3] = 4096;
					break;
				default:
					throw new RuntimeException();
				case 5:
					((Class298_Sub32_Sub21) this).anIntArrayArray9461 = new int[16][4];
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][0] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][1] = 80;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][2] = 192;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][3] = 321;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][0] = 155;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][1] = 321;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][2] = 449;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][3] = 562;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][0] = 389;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][1] = 578;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][2] = 690;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][3] = 803;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][0] = 671;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][1] = 947;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][2] = 995;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][3] = 1140;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][0] = 897;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][1] = 1285;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][2] = 1397;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][3] = 1509;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][0] = 1175;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][1] = 1525;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][2] = 1429;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][3] = 1413;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][0] = 1368;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][1] = 1734;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][2] = 1461;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][3] = 1333;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[7][0] = 1507;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[7][1] = 1413;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[7][2] = 1525;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[7][3] = 1702;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[8][0] = 1736;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[8][1] = 1108;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[8][2] = 1590;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[8][3] = 2056;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[9][0] = 2088;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[9][1] = 1766;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[9][2] = 2056;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[9][3] = 2666;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[10][0] = 2355;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[10][1] = 2409;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[10][2] = 2586;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[10][3] = 3276;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[11][0] = 2691;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[11][1] = 3116;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[11][2] = 3148;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[11][3] = 3228;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[12][0] = 3031;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[12][1] = 3806;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[12][2] = 3710;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[12][3] = 3196;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[13][0] = 3522;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[13][1] = 3437;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[13][2] = 3421;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[13][3] = 3019;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[14][0] = 3727;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[14][1] = 3116;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[14][2] = 3148;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[14][3] = 3228;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[15][0] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[15][1] = 2377;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[15][2] = 2505;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[15][3] = 2746;
					break;
				case 4:
					((Class298_Sub32_Sub21) this).anIntArrayArray9461 = new int[6][4];
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][0] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][1] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][2] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][3] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][0] = 1843;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][1] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][2] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][3] = 1493;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][0] = 2457;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][1] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][2] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][3] = 2939;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][0] = 2781;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][1] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][2] = 1124;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][3] = 3565;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][0] = 3481;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][1] = 546;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][2] = 3084;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][3] = 4031;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][0] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][1] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][2] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][3] = 4096;
					break;
				case 3:
					((Class298_Sub32_Sub21) this).anIntArrayArray9461 = new int[7][4];
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][0] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][1] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][2] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][3] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][0] = 663;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][1] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][2] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][3] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][0] = 1363;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][1] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][2] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][3] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][0] = 2048;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][1] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][2] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][3] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][0] = 2727;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][1] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][2] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[4][3] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][0] = 3411;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][1] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][2] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[5][3] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][0] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][1] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][2] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[6][3] = 4096;
					break;
				case 6:
					((Class298_Sub32_Sub21) this).anIntArrayArray9461 = new int[4][4];
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][0] = 2048;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][1] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][2] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[0][3] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][0] = 2867;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][1] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][2] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[1][3] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][0] = 3276;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][1] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][2] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[2][3] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][0] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][1] = 4096;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][2] = 0;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[3][3] = 0;
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ahj.am(").append(')').toString());
		}
	}

	void method3133(int i) {
		try {
			if (((Class298_Sub32_Sub21) this).anIntArrayArray9461 == null)
				method3264(1, 59657097);
			method3265((short) 24492);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ahj.x(").append(')').toString());
		}
	}

	void method3265(short i) {
		try {
			int i_1_ = ((Class298_Sub32_Sub21) this).anIntArrayArray9461.length;
			if (i_1_ > 0) {
				for (int i_2_ = 0; i_2_ < 257; i_2_++) {
					int i_3_ = 0;
					int i_4_ = i_2_ << 4;
					for (int i_5_ = 0; i_5_ < i_1_; i_5_++) {
						if (i_4_ < (((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_5_][0])) {
							if (i <= 255) {
								/* empty */
							}
							break;
						}
						i_3_++;
					}
					int i_6_;
					int i_7_;
					int i_8_;
					if (i_3_ < i_1_) {
						int[] is = (((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_3_]);
						if (i_3_ > 0) {
							int[] is_9_ = (((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_3_ - 1]);
							int i_10_ = (i_4_ - is_9_[0] << 12) / (is[0] - is_9_[0]);
							int i_11_ = 4096 - i_10_;
							i_6_ = is_9_[1] * i_11_ + is[1] * i_10_ >> 12;
							i_7_ = i_11_ * is_9_[2] + is[2] * i_10_ >> 12;
							i_8_ = i_11_ * is_9_[3] + i_10_ * is[3] >> 12;
						} else {
							i_6_ = is[1];
							i_7_ = is[2];
							i_8_ = is[3];
						}
					} else {
						int[] is = (((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_1_ - 1]);
						i_6_ = is[1];
						i_7_ = is[2];
						i_8_ = is[3];
					}
					i_6_ >>= 4;
					i_7_ >>= 4;
					i_8_ >>= 4;
					if (i_6_ < 0)
						i_6_ = 0;
					else if (i_6_ > 255)
						i_6_ = 255;
					if (i_7_ < 0)
						i_7_ = 0;
					else if (i_7_ > 255)
						i_7_ = 255;
					if (i_8_ < 0)
						i_8_ = 0;
					else if (i_8_ > 255)
						i_8_ = 255;
					((Class298_Sub32_Sub21) this).anIntArray9456[i_2_] = i_6_ << 16 | i_7_ << 8 | i_8_;
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ahj.ac(").append(')').toString());
		}
	}

	void method3137(int i, RsByteBuffer class298_sub53, byte i_12_) {
		try {
			if (i == 0) {
				int i_13_ = class298_sub53.readUnsignedByte();
				if (0 == i_13_) {
					((Class298_Sub32_Sub21) this).anIntArrayArray9461 = new int[class298_sub53.readUnsignedByte()][4];
					for (int i_14_ = 0; i_14_ < (((Class298_Sub32_Sub21) this).anIntArrayArray9461).length; i_14_++) {
						((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_14_][0] = class298_sub53.readUnsignedShort();
						((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_14_][1] = class298_sub53.readUnsignedByte() << 4;
						((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_14_][2] = class298_sub53.readUnsignedByte() << 4;
						((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_14_][3] = class298_sub53.readUnsignedByte() << 4;
					}
				} else
					method3264(i_13_, 335415156);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ahj.r(").append(')').toString());
		}
	}

	void method3266() {
		if (((Class298_Sub32_Sub21) this).anIntArrayArray9461 == null)
			method3264(1, -112292785);
		method3265((short) 20837);
	}

	void method3267() {
		if (((Class298_Sub32_Sub21) this).anIntArrayArray9461 == null)
			method3264(1, 10351702);
		method3265((short) 29849);
	}

	void method3268(int i, RsByteBuffer class298_sub53) {
		if (i == 0) {
			int i_15_ = class298_sub53.readUnsignedByte();
			if (0 == i_15_) {
				((Class298_Sub32_Sub21) this).anIntArrayArray9461 = new int[class298_sub53.readUnsignedByte()][4];
				for (int i_16_ = 0; i_16_ < (((Class298_Sub32_Sub21) this).anIntArrayArray9461).length; i_16_++) {
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_16_][0] = class298_sub53.readUnsignedShort();
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_16_][1] = class298_sub53.readUnsignedByte() << 4;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_16_][2] = class298_sub53.readUnsignedByte() << 4;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_16_][3] = class298_sub53.readUnsignedByte() << 4;
				}
			} else
				method3264(i_15_, 1188552239);
		}
	}

	void method3269(int i, RsByteBuffer class298_sub53) {
		if (i == 0) {
			int i_17_ = class298_sub53.readUnsignedByte();
			if (0 == i_17_) {
				((Class298_Sub32_Sub21) this).anIntArrayArray9461 = new int[class298_sub53.readUnsignedByte()][4];
				for (int i_18_ = 0; i_18_ < (((Class298_Sub32_Sub21) this).anIntArrayArray9461).length; i_18_++) {
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_18_][0] = class298_sub53.readUnsignedShort();
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_18_][1] = class298_sub53.readUnsignedByte() << 4;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_18_][2] = class298_sub53.readUnsignedByte() << 4;
					((Class298_Sub32_Sub21) this).anIntArrayArray9461[i_18_][3] = class298_sub53.readUnsignedByte() << 4;
				}
			} else
				method3264(i_17_, -1310770801);
		}
	}

	int[][] method3270(int i) {
		int[][] is = aClass239_7380.method2205(i, (byte) 40);
		if (aClass239_7380.aBoolean2607) {
			int[] is_19_ = method3129(0, i, -1887337990);
			int[] is_20_ = is[0];
			int[] is_21_ = is[1];
			int[] is_22_ = is[2];
			for (int i_23_ = 0; i_23_ < -1474554145 * Class250.anInt2755; i_23_++) {
				int i_24_ = is_19_[i_23_] >> 4;
				if (i_24_ < 0)
					i_24_ = 0;
				if (i_24_ > 256)
					i_24_ = 256;
				i_24_ = ((Class298_Sub32_Sub21) this).anIntArray9456[i_24_];
				is_20_[i_23_] = (i_24_ & 0xff0000) >> 12;
				is_21_[i_23_] = (i_24_ & 0xff00) >> 4;
				is_22_[i_23_] = (i_24_ & 0xff) << 4;
			}
		}
		return is;
	}

	int[][] method3271(int i) {
		int[][] is = aClass239_7380.method2205(i, (byte) 83);
		if (aClass239_7380.aBoolean2607) {
			int[] is_25_ = method3129(0, i, -1887337990);
			int[] is_26_ = is[0];
			int[] is_27_ = is[1];
			int[] is_28_ = is[2];
			for (int i_29_ = 0; i_29_ < -1474554145 * Class250.anInt2755; i_29_++) {
				int i_30_ = is_25_[i_29_] >> 4;
				if (i_30_ < 0)
					i_30_ = 0;
				if (i_30_ > 256)
					i_30_ = 256;
				i_30_ = ((Class298_Sub32_Sub21) this).anIntArray9456[i_30_];
				is_26_[i_29_] = (i_30_ & 0xff0000) >> 12;
				is_27_[i_29_] = (i_30_ & 0xff00) >> 4;
				is_28_[i_29_] = (i_30_ & 0xff) << 4;
			}
		}
		return is;
	}

	public Class298_Sub32_Sub21() {
		super(1, false);
	}

	int[][] method3132(int i, byte i_31_) {
		try {
			int[][] is = aClass239_7380.method2205(i, (byte) 109);
			if (aClass239_7380.aBoolean2607) {
				int[] is_32_ = method3129(0, i, -1887337990);
				int[] is_33_ = is[0];
				int[] is_34_ = is[1];
				int[] is_35_ = is[2];
				for (int i_36_ = 0; i_36_ < -1474554145 * Class250.anInt2755; i_36_++) {
					int i_37_ = is_32_[i_36_] >> 4;
					if (i_37_ < 0)
						i_37_ = 0;
					if (i_37_ > 256)
						i_37_ = 256;
					i_37_ = ((Class298_Sub32_Sub21) this).anIntArray9456[i_37_];
					is_33_[i_36_] = (i_37_ & 0xff0000) >> 12;
					is_34_[i_36_] = (i_37_ & 0xff00) >> 4;
					is_35_[i_36_] = (i_37_ & 0xff) << 4;
				}
			}
			return is;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ahj.k(").append(')').toString());
		}
	}

	void method3272() {
		if (((Class298_Sub32_Sub21) this).anIntArrayArray9461 == null)
			method3264(1, 1248712713);
		method3265((short) 13149);
	}

	static final void method3273(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_38_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919]);
			int i_39_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239 + 1]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_38_ / i_39_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ahj.yw(").append(')').toString());
		}
	}
}
