/* Class3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class3 {
	public static int anInt54;
	static boolean aBoolean55;
	static int anInt56;
	static int anInt57;
	static int[] anIntArray58;
	static int[] anIntArray59;
	static int[] anIntArray60;
	static Class453 aClass453_61;
	public static int anInt62;
	static boolean aBoolean63;
	static boolean aBoolean64 = false;
	static boolean aBoolean65;
	static int anInt66 = 48;
	static int anInt67;
	static Class284 aClass284_68;

	static {
		aBoolean55 = false;
		anInt57 = 955770805;
		anInt67 = 0;
		anIntArray58 = new int[1003];
		anIntArray59 = new int[1004];
		anIntArray60 = new int[1005];
		aClass453_61 = new Class453();
		anInt62 = 1129029761;
		anInt54 = 1835291189;
		aBoolean63 = true;
		aBoolean65 = false;
		anInt56 = 0;
	}

	Class3() throws Throwable {
		throw new Error();
	}

	public static void method300(int i) {
		try {
			Class476 class476 = null;
			try {
				class476 = Class86.method962("", client.aClass411_8944.aString5317, true, -1804643872);
				RsByteBuffer class298_sub53 = Class422_Sub25.aClass298_Sub48_8425.method3542(-804179286);
				class476.method6078(class298_sub53.buffer, 0, class298_sub53.index * 385051775, -1257925796);
			} catch (Exception exception) {
				/* empty */
			}
			try {
				if (null != class476)
					class476.method6079(1091393691);
			} catch (Exception exception) {
				/* empty */
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ad.f(").append(')').toString());
		}
	}

	static final void method301(ClientScript2 class403, byte i) {
		try {
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub16_7557, (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]) == 1 ? 1 : 0, -223155318);
			method300(656179282);
			Class359.method4294(1660250591);
			client.aBoolean8666 = false;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ad.aim(").append(')').toString());
		}
	}

	static final int method302(Class513 class513, int i) {
		try {
			if (class513 == null)
				return 12;
			switch (-1062992263 * ((Class513) class513).anInt6638) {
			case 3:
				return 20;
			default:
				return 12;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ad.a(").append(')').toString());
		}
	}

	static final void method303(ClientScript2 class403, int i) {
		try {
			String string = (String) (((ClientScript2) class403).anObjectArray5240[(((ClientScript2) class403).anInt5241 -= 969361751) * -203050393]);
			if (string.startsWith(Class247.method2368(0, -278777595)) || string.startsWith(Class247.method2368(1, -278777595)))
				string = string.substring(7);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class494.method6192(string, -1912416826) ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ad.vj(").append(')').toString());
		}
	}
}
