/* Class107 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class107 {
	static int anInt1310;
	static int anInt1311 = 100;
	static Class102[] aClass102Array1312 = new Class102[100];
	static int anInt1313 = 0;
	static String aString1314;
	public static short[] aShortArray1315;

	Class107() throws Throwable {
		throw new Error();
	}

	static final void method1138(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_0_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239]);
			int i_1_ = (((ClientScript2) class403).anIntArray5244[1 + ((ClientScript2) class403).anInt5239 * 681479919]);
			Interface class298_sub51 = ((Interface) client.aClass437_8841.method5812((long) i_0_));
			if (null != class298_sub51 && class298_sub51.interfaceId * -1617025021 == i_1_)
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = 1;
			else
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ej.sc(").append(')').toString());
		}
	}

	static final void method1139(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5241 -= 1938723502;
			String string = (String) (((ClientScript2) class403).anObjectArray5240[-203050393 * ((ClientScript2) class403).anInt5241]);
			String string_2_ = ((String) (((ClientScript2) class403).anObjectArray5240[1 + -203050393 * ((ClientScript2) class403).anInt5241]));
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_3_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919]);
			int i_4_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919 + 1]);
			if (null == string_2_)
				string_2_ = "";
			if (string_2_.length() > 80)
				string_2_ = string_2_.substring(0, 80);
			Class25 class25 = Class429.method5760((short) 512);
			Class298_Sub36 class298_sub36 = Class18.method359(OutcommingPacket.aClass198_2085, class25.aClass449_330, (byte) 119);
			class298_sub36.aClass298_Sub53_Sub2_7396.writeByte((Class58.method693(string, 824741758) + 2 + Class58.method693(string_2_, 1825350693)));
			class298_sub36.aClass298_Sub53_Sub2_7396.writeString(string, 2106957480);
			class298_sub36.aClass298_Sub53_Sub2_7396.writeByte(i_3_ - 1);
			class298_sub36.aClass298_Sub53_Sub2_7396.writeByte(i_4_);
			class298_sub36.aClass298_Sub53_Sub2_7396.writeString(string_2_, 2102628417);
			class25.method390(class298_sub36, (byte) -56);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ej.abn(").append(')').toString());
		}
	}

	static final void method1140(ClientScript2 class403, int i) {
		try {
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub25_7569, (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]), -2044130238);
			Class3.method300(656179282);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ej.aiu(").append(')').toString());
		}
	}

	static final void method1141(ClientScript2 class403, short i) {
		try {
			int i_5_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_5_, (byte) 78);
			Class119 class119 = Class389.aClass119Array4165[i_5_ >> 16];
			Class284.method2696(class105, class119, class403, (short) 909);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ej.gn(").append(')').toString());
		}
	}

	static final void method1142(ClientScript2 class403, int i) {
		try {
			Class390 class390 = (((ClientScript2) class403).aBoolean5261 ? ((ClientScript2) class403).aClass390_5247 : ((ClientScript2) class403).aClass390_5246);
			IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = class105.anInt1284 * -261021353;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ej.pq(").append(')').toString());
		}
	}

	static final void method1143(ClientScript2 class403, int i) {
		try {
			int i_6_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = ((ClientScript2) class403).aClass162_5252.aByteArray1657[i_6_];
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ej.xa(").append(')').toString());
		}
	}

	public static void method1144(boolean bool, short i) {
		try {
			if (1596783995 * client.anInt8724 != 2 && 1596783995 * client.anInt8724 != 3) {
				if (!bool) {
					Class82[] class82s = Class87.aClass82Array797;
					for (int i_7_ = 0; i_7_ < class82s.length; i_7_++) {
						Class82 class82 = class82s[i_7_];
						class82.method867(-2077321818);
					}
				}
				client.anInt8724 = 1973597030;
				Class298_Sub37.anIntArrayArray7407 = null;
				Class128_Sub1.aClass298_Sub53_8555 = null;
				client.aBoolean8725 = false;
				Class228.method2117(1960223809);
				Class298_Sub36 class298_sub36 = Class18.method359(OutcommingPacket.aClass198_2011, client.aClass25_8711.aClass449_330, (byte) 30);
				class298_sub36.aClass298_Sub53_Sub2_7396.writeByte(bool ? 1 : 0);
				client.aClass25_8711.method390(class298_sub36, (byte) -61);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ej.i(").append(')').toString());
		}
	}
}
