/* Class298_Sub50_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Point;

public class Class298_Sub50_Sub2 extends Class298_Sub50 {
	static int anInt9741 = 174;
	static int anInt9742 = 161;
	static int anInt9743 = 170;
	static int anInt9744 = 163;
	static int anInt9745 = 164;
	static int anInt9746 = 165;
	static int anInt9747 = 520;
	int anInt9748;
	static int anInt9749 = 168;
	static int anInt9750 = 169;
	static int anInt9751 = 519;
	static int anInt9752 = 171;
	static int anInt9753 = 172;
	static int anInt9754 = 173;
	static int anInt9755 = 674;
	static int anInt9756 = 512;
	static int anInt9757 = 513;
	static int anInt9758 = 514;
	static int anInt9759 = 167;
	static int anInt9760 = 516;
	static int anInt9761 = 517;
	int anInt9762;
	static int anInt9763 = 672;
	static int anInt9764 = 160;
	static int anInt9765 = 521;
	static int anInt9766 = 522;
	static int anInt9767 = 525;
	long aLong9768;
	static int anInt9769 = 162;
	static Class298_Sub50_Sub2[] aClass298_Sub50_Sub2Array9770 = new Class298_Sub50_Sub2[0];
	int anInt9771;
	int anInt9772;
	static int anInt9773 = 515;
	static int anInt9774 = 166;
	static int anInt9775 = 518;

	public int method3568(byte i) {
		try {
			return ((Class298_Sub50_Sub2) this).anInt9772 * -1497786335;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.at(").append(')').toString());
		}
	}

	public int method3569(byte i) {
		try {
			return 1151921009 * ((Class298_Sub50_Sub2) this).anInt9771;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.ah(").append(')').toString());
		}
	}

	public int method3554() {
		return ((Class298_Sub50_Sub2) this).anInt9762 * 2113899933;
	}

	public int method3546(int i) {
		try {
			switch (((Class298_Sub50_Sub2) this).anInt9771 * 1151921009) {
			case 167:
			case 169:
			case 519:
			case 521:
				return 1;
			case 161:
			case 163:
			case 513:
			case 515:
				return 0;
			case 164:
			case 166:
			case 516:
			case 518:
				return 2;
			case 162:
			case 514:
				return 3;
			case 170:
			case 522:
				return 6;
			case 160:
			case 512:
				return -1;
			case 165:
			case 517:
				return 5;
			case 168:
			case 520:
				return 4;
			default:
				return -2;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.a(").append(')').toString());
		}
	}

	public int method3548(int i) {
		try {
			switch (((Class298_Sub50_Sub2) this).anInt9771 * 1151921009) {
			default:
				return 1;
			case 163:
			case 166:
			case 169:
			case 173:
			case 515:
			case 518:
			case 521:
			case 525:
				return 2;
			case 160:
			case 512:
				return 0;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.p(").append(')').toString());
		}
	}

	public long method3549(byte i) {
		try {
			return (-1729630536048907557L * ((Class298_Sub50_Sub2) this).aLong9768);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.i(").append(')').toString());
		}
	}

	public int method3547(byte i) {
		try {
			return ((Class298_Sub50_Sub2) this).anInt9762 * 2113899933;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.f(").append(')').toString());
		}
	}

	public int method3560(int i) {
		try {
			return -1537929791 * ((Class298_Sub50_Sub2) this).anInt9748;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.b(").append(')').toString());
		}
	}

	public boolean method3570(int i) {
		try {
			switch (((Class298_Sub50_Sub2) this).anInt9771 * 1151921009) {
			case 160:
			case 161:
			case 162:
			case 163:
			case 164:
			case 165:
			case 166:
			case 167:
			case 168:
			case 169:
			case 170:
			case 171:
			case 172:
			case 173:
			case 174:
			case 672:
			case 674:
				return true;
			default:
				return false;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.ai(").append(')').toString());
		}
	}

	public void method3555() {
		synchronized (aClass298_Sub50_Sub2Array9770) {
			if (656179585 * Class446.anInt5614 < 200219789 * Class521.anInt6282 - 1)
				aClass298_Sub50_Sub2Array9770[(Class446.anInt5614 += 453361281) * 656179585 - 1] = this;
		}
	}

	public int method3557() {
		switch (((Class298_Sub50_Sub2) this).anInt9771 * 1151921009) {
		case 167:
		case 169:
		case 519:
		case 521:
			return 1;
		case 161:
		case 163:
		case 513:
		case 515:
			return 0;
		case 164:
		case 166:
		case 516:
		case 518:
			return 2;
		case 162:
		case 514:
			return 3;
		case 170:
		case 522:
			return 6;
		case 160:
		case 512:
			return -1;
		case 165:
		case 517:
			return 5;
		case 168:
		case 520:
			return 4;
		default:
			return -2;
		}
	}

	public int method3553() {
		return ((Class298_Sub50_Sub2) this).anInt9762 * 2113899933;
	}

	public void method3550(int i) {
		try {
			synchronized (aClass298_Sub50_Sub2Array9770) {
				if (656179585 * Class446.anInt5614 < 200219789 * Class521.anInt6282 - 1)
					aClass298_Sub50_Sub2Array9770[(Class446.anInt5614 += 453361281) * 656179585 - 1] = this;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.d(").append(')').toString());
		}
	}

	public int method3562() {
		return -1537929791 * ((Class298_Sub50_Sub2) this).anInt9748;
	}

	Class298_Sub50_Sub2() {
		/* empty */
	}

	public long method3556() {
		return -1729630536048907557L * ((Class298_Sub50_Sub2) this).aLong9768;
	}

	public long method3558() {
		return -1729630536048907557L * ((Class298_Sub50_Sub2) this).aLong9768;
	}

	public long method3559() {
		return -1729630536048907557L * ((Class298_Sub50_Sub2) this).aLong9768;
	}

	public int method3564() {
		switch (((Class298_Sub50_Sub2) this).anInt9771 * 1151921009) {
		default:
			return 1;
		case 163:
		case 166:
		case 169:
		case 173:
		case 515:
		case 518:
		case 521:
		case 525:
			return 2;
		case 160:
		case 512:
			return 0;
		}
	}

	public long method3552() {
		return -1729630536048907557L * ((Class298_Sub50_Sub2) this).aLong9768;
	}

	public int method3565() {
		return -1537929791 * ((Class298_Sub50_Sub2) this).anInt9748;
	}

	public void method3563() {
		synchronized (aClass298_Sub50_Sub2Array9770) {
			if (656179585 * Class446.anInt5614 < 200219789 * Class521.anInt6282 - 1)
				aClass298_Sub50_Sub2Array9770[(Class446.anInt5614 += 453361281) * 656179585 - 1] = this;
		}
	}

	public int method3561() {
		switch (((Class298_Sub50_Sub2) this).anInt9771 * 1151921009) {
		default:
			return 1;
		case 163:
		case 166:
		case 169:
		case 173:
		case 515:
		case 518:
		case 521:
		case 525:
			return 2;
		case 160:
		case 512:
			return 0;
		}
	}

	public int method3551() {
		switch (((Class298_Sub50_Sub2) this).anInt9771 * 1151921009) {
		case 167:
		case 169:
		case 519:
		case 521:
			return 1;
		case 161:
		case 163:
		case 513:
		case 515:
			return 0;
		case 164:
		case 166:
		case 516:
		case 518:
			return 2;
		case 162:
		case 514:
			return 3;
		case 170:
		case 522:
			return 6;
		case 160:
		case 512:
			return -1;
		case 165:
		case 517:
			return 5;
		case 168:
		case 520:
			return 4;
		default:
			return -2;
		}
	}

	public void method3571(Point point, int i) {
		try {
			((Class298_Sub50_Sub2) this).anInt9762 -= point.x * 1060004021;
			((Class298_Sub50_Sub2) this).anInt9748 -= point.y * 1196163649;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.al(").append(')').toString());
		}
	}

	static void method3572(int i, byte i_0_) {
		try {
			Class298_Sub50_Sub1.anInt9734 = 912274055 * i;
			Class298_Sub50_Sub1.aClass298_Sub50_Sub1Array9735 = new Class298_Sub50_Sub1[i];
			Class298_Sub50_Sub1.anInt9733 = 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajw.ad(").append(')').toString());
		}
	}
}
