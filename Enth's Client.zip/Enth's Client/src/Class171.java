/* Class171 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class171 {
	static Class171 aClass171_1739;
	static Class171 aClass171_1740;
	public static Class171 aClass171_1741;
	public static Class171 aClass171_1742 = new Class171(2);
	static Class171 aClass171_1743;
	static Class171 aClass171_1744;
	public int anInt1745;

	Class171(int i) {
		anInt1745 = i;
	}

	static {
		aClass171_1740 = new Class171(1);
		aClass171_1741 = new Class171(0);
		aClass171_1743 = new Class171(4);
		aClass171_1739 = new Class171(5);
		aClass171_1744 = new Class171(3);
	}
}
