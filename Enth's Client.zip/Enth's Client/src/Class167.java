/* Class167 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class167 {
	Interface7_Impl2 anInterface7_Impl2_1707;
	boolean aBoolean1708;
	Interface7_Impl2 anInterface7_Impl2_1709;
	boolean aBoolean1710;

	Class167(boolean bool) {
		((Class167) this).aBoolean1708 = bool;
	}

	boolean method1787() {
		return (((Class167) this).aBoolean1710 && !((Class167) this).aBoolean1708);
	}

	void method1788() {
		if (((Class167) this).anInterface7_Impl2_1709 != null)
			((Class167) this).anInterface7_Impl2_1709.b();
		((Class167) this).aBoolean1710 = false;
	}
}
