/* Class127 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class127 implements Interface6 {
	int anInt6371;
	CacheIndex aClass243_6372;
	Class264 aClass264_6373;
	CacheIndex aClass243_6374;
	Class128 aClass128_6375;
	long aLong6376;
	public static CacheIndex aClass243_6377;

	abstract void method1409(boolean bool, int i, int i_0_);

	abstract void method1410(boolean bool, int i, int i_1_);

	public boolean method54() {
		boolean bool = true;
		if (!((Class127) this).aClass243_6372.method2310(((((Class127) this).aClass128_6375.anInt6329) * 955568089), -457216440))
			bool = false;
		if (!((Class127) this).aClass243_6374.method2310((955568089 * (((Class127) this).aClass128_6375.anInt6329)), -457216440))
			bool = false;
		return bool;
	}

	public boolean method52(int i) {
		try {
			boolean bool = true;
			if (!((Class127) this).aClass243_6372.method2310(((Class127) this).aClass128_6375.anInt6329 * 955568089, -457216440))
				bool = false;
			if (!((Class127) this).aClass243_6374.method2310(955568089 * ((Class127) this).aClass128_6375.anInt6329, -457216440))
				bool = false;
			return bool;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fd.b(").append(')').toString());
		}
	}

	abstract void method1411(boolean bool, int i, int i_2_, int i_3_);

	public void method58(boolean bool, byte i) {
		try {
			int i_4_ = ((((Class127) this).aClass128_6375.aClass139_6322.method1545(-944287579 * ((Class127) this).aClass128_6375.anInt6326, client.anInt8794 * 775068819, -2137791831)) + ((Class127) this).aClass128_6375.anInt6327 * -39975161);
			int i_5_ = ((((Class127) this).aClass128_6375.aClass133_6323.method1482(-1387457793 * ((Class127) this).aClass128_6375.anInt6330, -791746413 * client.anInt8803, -1715218341)) + ((Class127) this).aClass128_6375.anInt6325 * 1886882435);
			method1412(bool, i_4_, i_5_, 589039750);
			method1411(bool, i_4_, i_5_, -2096633602);
			String string = Class288_Sub1.aClass219_7147.method2039((short) 8868);
			if ((Class122.method1319((byte) 1) - ((Class127) this).aLong6376 * 109366757865047727L) > 10000L)
				string = new StringBuilder().append(string).append(" (").append((Class288_Sub1.aClass219_7147.method2034(-1233866115).anInt2548) * -861845079).append(")").toString();
			((Class127) this).aClass264_6373.method2490(string, (-944287579 * ((Class127) this).aClass128_6375.anInt6326 / 2 + i_4_), (4 + ((-1387457793 * ((Class127) this).aClass128_6375.anInt6330 / 2) + i_5_) + ((Class127) this).aClass128_6375.anInt6328 * -684094775), ((Class127) this).aClass128_6375.anInt6324 * 782326281, -1, -370673990);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fd.f(").append(')').toString());
		}
	}

	abstract void method1412(boolean bool, int i, int i_6_, int i_7_);

	public void method56(boolean bool) {
		int i = ((((Class127) this).aClass128_6375.aClass139_6322.method1545(-944287579 * ((Class127) this).aClass128_6375.anInt6326, client.anInt8794 * 775068819, -1925244247)) + ((Class127) this).aClass128_6375.anInt6327 * -39975161);
		int i_8_ = ((((Class127) this).aClass128_6375.aClass133_6323.method1482(-1387457793 * ((Class127) this).aClass128_6375.anInt6330, -791746413 * client.anInt8803, -1769429058)) + ((Class127) this).aClass128_6375.anInt6325 * 1886882435);
		method1412(bool, i, i_8_, -895632654);
		method1411(bool, i, i_8_, -358621562);
		String string = Class288_Sub1.aClass219_7147.method2039((short) 24747);
		if ((Class122.method1319((byte) 1) - ((Class127) this).aLong6376 * 109366757865047727L) > 10000L)
			string = new StringBuilder().append(string).append(" (").append((Class288_Sub1.aClass219_7147.method2034(-1233866115).anInt2548) * -861845079).append(")").toString();
		((Class127) this).aClass264_6373.method2490(string, -944287579 * ((Class127) this).aClass128_6375.anInt6326 / 2 + i, (4 + (-1387457793 * ((Class127) this).aClass128_6375.anInt6330 / 2 + i_8_) + ((Class127) this).aClass128_6375.anInt6328 * -684094775), ((Class127) this).aClass128_6375.anInt6324 * 782326281, -1, -1547657926);
	}

	public boolean method57() {
		boolean bool = true;
		if (!((Class127) this).aClass243_6372.method2310(((((Class127) this).aClass128_6375.anInt6329) * 955568089), -457216440))
			bool = false;
		if (!((Class127) this).aClass243_6374.method2310((955568089 * (((Class127) this).aClass128_6375.anInt6329)), -457216440))
			bool = false;
		return bool;
	}

	public void method55() {
		Class505 class505 = Class255.method2439(((Class127) this).aClass243_6374, 955568089 * (((Class127) this).aClass128_6375.anInt6329), 325683529);
		((Class127) this).aClass264_6373 = (Class373.aClass_ra4071.method5092(class505, Class89.method981(((Class127) this).aClass243_6372, 955568089 * (((Class127) this).aClass128_6375.anInt6329)), true));
	}

	public boolean method59() {
		boolean bool = true;
		if (!((Class127) this).aClass243_6372.method2310(((((Class127) this).aClass128_6375.anInt6329) * 955568089), -457216440))
			bool = false;
		if (!((Class127) this).aClass243_6374.method2310((955568089 * (((Class127) this).aClass128_6375.anInt6329)), -457216440))
			bool = false;
		return bool;
	}

	abstract void method1413(boolean bool, int i, int i_9_);

	abstract void method1414(boolean bool, int i, int i_10_);

	abstract void method1415(boolean bool, int i, int i_11_);

	abstract void method1416(boolean bool, int i, int i_12_);

	Class127(CacheIndex class243, CacheIndex class243_13_, Class128 class128) {
		((Class127) this).aClass243_6372 = class243;
		((Class127) this).aClass243_6374 = class243_13_;
		((Class127) this).aClass128_6375 = class128;
	}

	public void method53(int i) {
		try {
			Class505 class505 = Class255.method2439(((Class127) this).aClass243_6374, 955568089 * (((Class127) this).aClass128_6375.anInt6329), 1681337882);
			((Class127) this).aClass264_6373 = (Class373.aClass_ra4071.method5092(class505, Class89.method981(((Class127) this).aClass243_6372, 955568089 * (((Class127) this).aClass128_6375.anInt6329)), true));
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fd.a(").append(')').toString());
		}
	}

	abstract void method1417(boolean bool, int i, int i_14_);

	int method1418(int i) {
		try {
			int i_15_ = Class288_Sub1.aClass219_7147.method2038(-15916663);
			int i_16_ = i_15_ * 100;
			if (-1729871315 * ((Class127) this).anInt6371 == i_15_ && i_15_ != 0) {
				int i_17_ = Class288_Sub1.aClass219_7147.method2041((byte) 7);
				if (i_17_ > i_15_) {
					long l = (109366757865047727L * ((Class127) this).aLong6376 - Class288_Sub1.aClass219_7147.method2040(-2093041337));
					if (l > 0L) {
						long l_18_ = (l * 10000L / (long) i_15_ * (long) (i_17_ - i_15_));
						long l_19_ = ((Class122.method1319((byte) 1) - (((Class127) this).aLong6376 * 109366757865047727L)) * 10000L);
						if (l_19_ < l_18_)
							i_16_ = (int) ((100L * (l_19_ * (long) (i_17_ - i_15_)) / l_18_) + (long) (100 * i_15_));
						else
							i_16_ = 100 * i_17_;
					}
				}
			} else {
				((Class127) this).anInt6371 = 1301503397 * i_15_;
				((Class127) this).aLong6376 = Class122.method1319((byte) 1) * -1063467934392987569L;
			}
			return i_16_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fd.q(").append(')').toString());
		}
	}

	static final void method1419(IComponentDefinition class105, Class119 class119, ClientScript2 class403, int i) {
		try {
			if (5 == -1215239439 * class105.anInt1144)
				Class165.method1781(class105, class119, class403, (short) -9019);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fd.gi(").append(')').toString());
		}
	}

	static final void method1420(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub28_7573.method5724(1673845033) == 1 ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fd.ajr(").append(')').toString());
		}
	}

	static final void method1421(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anInt5239 -= -1175642067;
			int i_20_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919]);
			int i_21_ = (((ClientScript2) class403).anIntArray5244[1 + ((ClientScript2) class403).anInt5239 * 681479919]);
			int i_22_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239 + 2]);
			Class301_Sub1.method3713(2, i_20_ << 16 | i_21_, i_22_, "", -474820428);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fd.ali(").append(')').toString());
		}
	}

	static final void method1422(ClientScript2 class403, short i) {
		try {
			int i_23_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			((ClientScript2) class403).anObjectArray5240[((((ClientScript2) class403).anInt5241 += 969361751) * -203050393 - 1)] = (GraphicsToolkit.aClass256_5315.method2441(i_23_, 1350033014).aString9596);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fd.acc(").append(')').toString());
		}
	}

	static final void method1423(IComponentDefinition class105, int i, int i_24_, int i_25_, ClientScript2 class403, int i_26_) {
		try {
			if (null == class105.aByteArray1185) {
				if (0 != i_24_) {
					class105.aByteArray1185 = new byte[11];
					class105.aByteArray1222 = new byte[11];
					class105.anIntArray1276 = new int[11];
				} else
					return;
			}
			class105.aByteArray1185[i] = (byte) i_24_;
			if (0 != i_24_)
				class105.aBoolean1220 = true;
			else {
				class105.aBoolean1220 = false;
				for (int i_27_ = 0; i_27_ < class105.aByteArray1185.length; i_27_++) {
					if (class105.aByteArray1185[i_27_] != 0) {
						class105.aBoolean1220 = true;
						break;
					}
				}
			}
			class105.aByteArray1222[i] = (byte) i_25_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fd.kd(").append(')').toString());
		}
	}
}
