/* Class187 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class187 {
	public static Class187 aClass187_1904;
	public static Class187 aClass187_1905;
	public static Class187 aClass187_1906;
	public static Class187 aClass187_1907;
	public static Class187 aClass187_1908 = new Class187(2);
	public int anInt1909;
	static Class187 aClass187_1910;

	static {
		aClass187_1905 = new Class187(4);
		aClass187_1910 = new Class187(0);
		aClass187_1907 = new Class187(5);
		aClass187_1906 = new Class187(1);
		aClass187_1904 = new Class187(3);
	}

	Class187(int i) {
		anInt1909 = i;
	}
}
