/* Class149 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class149 {
	static Class149 aClass149_1582 = new Class149();
	static Class149 aClass149_1583 = new Class149();
	static Class149 aClass149_1584 = new Class149();

	Class149() {
		/* empty */
	}
}
