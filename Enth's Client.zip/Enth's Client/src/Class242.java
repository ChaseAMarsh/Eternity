/* Class242 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class242 {
	public static Class401 aClass401_2708;
	public static int anInt2709;
	public static int anInt2710;

	abstract void method2249(int i);

	abstract Class226 method2250(int i);

	abstract byte[] method2251(int i, byte i_0_);

	abstract byte[] method2252(int i);

	abstract int method2253(int i, int i_1_);

	abstract Class226 method2254();

	abstract Class226 method2255();

	abstract void method2256(int i, short i_2_);

	abstract int method2257(int i);

	abstract byte[] method2258(int i);

	Class242() {
		/* empty */
	}

	abstract byte[] method2259(int i);

	abstract void method2260(int i);

	abstract int method2261(int i);

	abstract byte[] method2262(int i);

	abstract void method2263(int i);

	abstract Class226 method2264();

	abstract void method2265(int i);

	static final void method2266(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_3_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919]);
			int i_4_ = (((ClientScript2) class403).anIntArray5244[1 + ((ClientScript2) class403).anInt5239 * 681479919]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_4_ * i_3_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("kd.yr(").append(')').toString());
		}
	}

	static final void method2267(ClientScript2 class403, byte i) {
		try {
			int i_5_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_5_, (byte) -71);
			Class119 class119 = Class389.aClass119Array4165[i_5_ >> 16];
			Class102.method1085(class105, class119, class403, 1901866056);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("kd.dn(").append(')').toString());
		}
	}

	static final void method2268(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5239 -= -15720283;
			Class139[] class139s = Class491.method6176((byte) 58);
			Class133[] class133s = Class113.method1255(1297575712);
			Class238.method2200(class139s[(((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239])], (class133s[(((ClientScript2) class403).anIntArray5244[1 + 681479919 * ((ClientScript2) class403).anInt5239])]), (((ClientScript2) class403).anIntArray5244[2 + ((ClientScript2) class403).anInt5239 * 681479919]), (((ClientScript2) class403).anIntArray5244[3 + 681479919 * ((ClientScript2) class403).anInt5239]), (((ClientScript2) class403).anIntArray5244[4 + 681479919 * ((ClientScript2) class403).anInt5239]), (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919 + 5]), (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919 + 6]), (((ClientScript2) class403).anIntArray5244[7 + 681479919 * ((ClientScript2) class403).anInt5239]), (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919 + 8]), (((ClientScript2) class403).anIntArray5244[9 + 681479919 * ((ClientScript2) class403).anInt5239]), (((ClientScript2) class403).anIntArray5244[10 + 681479919 * ((ClientScript2) class403).anInt5239]), -1940539575);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("kd.se(").append(')').toString());
		}
	}

	static void method2269(int i, int i_6_, int i_7_) {
		try {
			Class298_Sub37_Sub12 class298_sub37_sub12 = Class410.method4985(13, (long) i);
			class298_sub37_sub12.method3449((byte) 67);
			((Class298_Sub37_Sub12) class298_sub37_sub12).anInt9610 = i_6_ * 1274450087;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("kd.aq(").append(')').toString());
		}
	}
}
