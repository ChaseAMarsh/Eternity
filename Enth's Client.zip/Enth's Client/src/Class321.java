/* Class321 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class321 {
	static int anInt3324 = 14;
	static int anInt3325 = 1;
	static int anInt3326 = 2;
	int anInt3327;
	static int anInt3328 = 10;
	static int anInt3329 = 5;
	static int anInt3330 = 3;
	public static int anInt3331 = 0;
	static int anInt3332 = 4;
	static int anInt3333 = 11;
	int anInt3334;
	static int anInt3335 = 7;
	static int anInt3336 = 8;
	public Class298_Sub10 aClass298_Sub10_3337;
	public static int anInt3338 = 31;
	static int anInt3339 = 3;
	static int anInt3340 = 12;
	static int anInt3341 = 13;
	static int anInt3342 = 16;
	static int anInt3343 = 15;
	static int anInt3344 = 9;
	public int anInt3345;
	static int anInt3346 = 2;
	boolean aBoolean3347;
	boolean aBoolean3348;
	static int anInt3349 = 6;
	short[] aShortArray3350;
	public int anInt3351;
	int anInt3352;
	int anInt3353;
	int anInt3354;
	static int anInt3355 = 5;
	static int anInt3356 = 4;
	public static Class429 aClass429_3357;

	void method3915(int i) {
		try {
			switch (anInt3351 * 589172669) {
			case 13:
				((Class321) this).anInt3334 = -2012607286;
				((Class321) this).anInt3327 = 0;
				((Class321) this).anInt3352 = 399235072;
				((Class321) this).anInt3353 = -1108516864;
				break;
			case 4:
				((Class321) this).anInt3334 = 269752724;
				((Class321) this).anInt3327 = 0;
				((Class321) this).anInt3352 = 399235072;
				((Class321) this).anInt3353 = 1870354432;
				break;
			case 15:
				((Class321) this).anInt3334 = 1141180005;
				((Class321) this).anInt3327 = -1783300608;
				((Class321) this).anInt3352 = 1173550592;
				((Class321) this).anInt3353 = -554258432;
				break;
			case 16:
				((Class321) this).anInt3334 = 1141180005;
				((Class321) this).anInt3327 = -2080517376;
				((Class321) this).anInt3352 = 586775296;
				((Class321) this).anInt3353 = -1108516864;
				break;
			case 12:
				((Class321) this).anInt3334 = -2012607286;
				((Class321) this).anInt3327 = 0;
				((Class321) this).anInt3352 = 399235072;
				((Class321) this).anInt3353 = 1870354432;
				break;
			case 2:
				((Class321) this).anInt3334 = 1141180005;
				((Class321) this).anInt3327 = 0;
				((Class321) this).anInt3352 = 399235072;
				((Class321) this).anInt3353 = 1870354432;
				break;
			case 14:
				((Class321) this).anInt3334 = 1141180005;
				((Class321) this).anInt3327 = -1486083840;
				((Class321) this).anInt3352 = 1760325888;
				((Class321) this).anInt3353 = 1870354432;
				break;
			case 11:
				((Class321) this).anInt3334 = -871427281;
				((Class321) this).anInt3327 = -1783300608;
				((Class321) this).anInt3352 = 1173550592;
				((Class321) this).anInt3353 = -554258432;
				break;
			case 7:
				((Class321) this).anInt3334 = -871427281;
				((Class321) this).anInt3327 = -1486083840;
				((Class321) this).anInt3352 = 1760325888;
				((Class321) this).anInt3353 = -554258432;
				break;
			case 5:
				((Class321) this).anInt3334 = 269752724;
				((Class321) this).anInt3327 = 0;
				((Class321) this).anInt3352 = 399235072;
				((Class321) this).anInt3353 = -1108516864;
				break;
			default:
				((Class321) this).anInt3327 = 0;
				((Class321) this).anInt3334 = 0;
				((Class321) this).anInt3352 = 399235072;
				((Class321) this).anInt3353 = 1870354432;
				break;
			case 6:
				((Class321) this).anInt3334 = -871427281;
				((Class321) this).anInt3327 = -1486083840;
				((Class321) this).anInt3352 = 1760325888;
				((Class321) this).anInt3353 = 1870354432;
				break;
			case 3:
				((Class321) this).anInt3334 = 1141180005;
				((Class321) this).anInt3327 = 0;
				((Class321) this).anInt3352 = 399235072;
				((Class321) this).anInt3353 = -554258432;
				break;
			case 8:
				((Class321) this).anInt3334 = -871427281;
				((Class321) this).anInt3327 = -1188867072;
				((Class321) this).anInt3352 = -1947866112;
				((Class321) this).anInt3353 = 1870354432;
				break;
			case 9:
				((Class321) this).anInt3334 = -871427281;
				((Class321) this).anInt3327 = -1188867072;
				((Class321) this).anInt3352 = -1947866112;
				((Class321) this).anInt3353 = -554258432;
				break;
			case 10:
				((Class321) this).anInt3334 = -871427281;
				((Class321) this).anInt3327 = -1783300608;
				((Class321) this).anInt3352 = 1173550592;
				((Class321) this).anInt3353 = 1870354432;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.b(").append(')').toString());
		}
	}

	void method3916(GraphicsToolkit class_ra, int i, int i_0_, int i_1_, int i_2_, int i_3_, int i_4_) {
		try {
			aClass298_Sub10_3337 = class_ra.method5049(i, i_0_, i_1_, i_2_, i_3_, 1.0F);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.a(").append(')').toString());
		}
	}

	public void method3917(int i, int i_5_, int i_6_, int i_7_, int i_8_) {
		try {
			((Class321) this).anInt3334 = 1141180005 * i;
			((Class321) this).anInt3327 = i_7_ * -2098313003;
			((Class321) this).anInt3352 = -282920581 * i_6_;
			((Class321) this).anInt3353 = i_5_ * -212996245;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.f(").append(')').toString());
		}
	}

	void method3918(int i, boolean bool, byte i_9_) {
		try {
			int i_10_;
			if (!bool) {
				int i_11_ = ((((Class321) this).anInt3354 * 240739725 + i * (-195574461 * ((Class321) this).anInt3353) / 50) & 0x7ff);
				switch (((Class321) this).anInt3334 * -936952979) {
				case 5:
					i_10_ = (i_11_ < 1024 ? i_11_ : 2048 - i_11_) << 1;
					break;
				case 1:
					i_10_ = 1024 + (Class220.anIntArray2483[i_11_ << 3] >> 4);
					break;
				case 2:
					i_10_ = i_11_;
					break;
				default:
					i_10_ = 2048;
					break;
				case 4:
					i_10_ = i_11_ >> 10 << 11;
					break;
				case 3:
					i_10_ = Class121.anIntArray6321[i_11_] >> 1;
				}
			} else
				i_10_ = 2048;
			aClass298_Sub10_3337.method2896(((float) ((-1796735565 * ((Class321) this).anInt3352 * i_10_ >> 11) + ((Class321) this).anInt3327 * -884690819) / 2048.0F), (byte) 3);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.p(").append(')').toString());
		}
	}

	public Class321(GraphicsToolkit class_ra, int i, RsByteBuffer class298_sub53, int i_12_) {
		if (null == Class121.anIntArray6321)
			Class50.method534((byte) 0);
		anInt3345 = class298_sub53.readUnsignedByte() * 657475255;
		((Class321) this).aBoolean3347 = (-1565952249 * anInt3345 & 0x8) != 0;
		((Class321) this).aBoolean3348 = 0 != (anInt3345 * -1565952249 & 0x10);
		anInt3345 = 657475255 * (anInt3345 * -1565952249 & 0x7);
		int i_13_ = class298_sub53.readUnsignedShort() << i_12_;
		int i_14_ = class298_sub53.readUnsignedShort() << i_12_;
		int i_15_ = class298_sub53.readUnsignedShort() << i_12_;
		int i_16_ = class298_sub53.readUnsignedByte();
		int i_17_ = 1 + i_16_ * 2;
		((Class321) this).aShortArray3350 = new short[i_17_];
		for (int i_18_ = 0; i_18_ < ((Class321) this).aShortArray3350.length; i_18_++) {
			int i_19_ = (short) class298_sub53.readUnsignedShort();
			int i_20_ = i_19_ >>> 8;
			int i_21_ = i_19_ & 0xff;
			if (i_20_ >= i_17_)
				i_20_ = i_17_ - 1;
			if (i_21_ > i_17_ - i_20_)
				i_21_ = i_17_ - i_20_;
			((Class321) this).aShortArray3350[i_18_] = (short) (i_20_ << 8 | i_21_);
		}
		i_16_ = (1 << i >> 1) + (i_16_ << i);
		int i_22_ = (Class294.anIntArray3165 != null ? (Class294.anIntArray3165[class298_sub53.readUnsignedShort()]) : (Class379.anIntArray4096[Class173.method1823(class298_sub53.readUnsignedShort(), (byte) 0) & 0xffff]));
		int i_23_ = class298_sub53.readUnsignedByte();
		anInt3351 = (i_23_ & 0x1f) * 1902257045;
		((Class321) this).anInt3354 = 1492346181 * ((i_23_ & 0xe0) << 3);
		if (31 != 589172669 * anInt3351)
			method3915(567522459);
		method3916(class_ra, i_13_, i_15_, i_14_, i_16_, i_22_, -1201005825);
	}

	static final void method3919(ClientScript2 class403, int i) {
		try {
			int i_24_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			if (null != client.aString8804 && i_24_ < -1801543887 * Class489.anInt6071)
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = (-1071570519 * Class82_Sub6.aClass7Array6846[i_24_].anInt95);
			else
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.wd(").append(')').toString());
		}
	}

	static final void method3920(ClientScript2 class403, int i) {
		try {
			String string = (String) (((ClientScript2) class403).anObjectArray5240[(((ClientScript2) class403).anInt5241 -= 969361751) * -203050393]);
			Class398.method4922(string, 655510254);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.wm(").append(')').toString());
		}
	}

	static final void method3921(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5241 -= 1938723502;
			String string = (String) (((ClientScript2) class403).anObjectArray5240[-203050393 * ((ClientScript2) class403).anInt5241]);
			String string_25_ = ((String) (((ClientScript2) class403).anObjectArray5240[-203050393 * ((ClientScript2) class403).anInt5241 + 1]));
			((ClientScript2) class403).anObjectArray5240[((((ClientScript2) class403).anInt5241 += 969361751) * -203050393 - 1)] = new StringBuilder().append(string).append(string_25_).toString();
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.zt(").append(')').toString());
		}
	}

	static final void method3922(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_26_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239]);
			int i_27_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919 + 1]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class77.method841(i_26_, i_27_, (byte) -125) ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.afa(").append(')').toString());
		}
	}

	static String method3923(int i, int i_28_, boolean bool, int i_29_) {
		try {
			if (i_28_ < 2 || i_28_ > 36)
				throw new IllegalArgumentException(new StringBuilder().append("").append(i_28_).toString());
			if (!bool || i < 0)
				return Integer.toString(i, i_28_);
			int i_30_ = 2;
			int i_31_ = i / i_28_;
			while (0 != i_31_) {
				i_31_ /= i_28_;
				i_30_++;
			}
			char[] cs = new char[i_30_];
			cs[0] = '+';
			for (int i_32_ = i_30_ - 1; i_32_ > 0; i_32_--) {
				int i_33_ = i;
				i /= i_28_;
				int i_34_ = i_33_ - i * i_28_;
				if (i_34_ >= 10)
					cs[i_32_] = (char) (i_34_ + 87);
				else
					cs[i_32_] = (char) (i_34_ + 48);
			}
			return new String(cs);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.x(").append(')').toString());
		}
	}

	static final void method3924(ClientScript2 class403, int i) {
		try {
			if (Class372.aClass323_4052.method3936(82, -596957727))
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = 1;
			else
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.ady(").append(')').toString());
		}
	}

	static final void method3925(IComponentDefinition class105, Class119 class119, ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			class105.anInt1241 = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239]) * 381202251;
			class105.anInt1252 = (-283274507 * (((ClientScript2) class403).anIntArray5244[1 + ((ClientScript2) class403).anInt5239 * 681479919]));
			Tradution.method6054(class105, 702048915);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.iy(").append(')').toString());
		}
	}

	static final void method3926(int i, int i_35_, int i_36_, int i_37_, int i_38_) {
		try {
			if (i_36_ >= Class372_Sub2.anInt4049 * 1155384281 && i_36_ <= Class372_Sub2.anInt4050 * -1062447355) {
				i = Class463.method6012(i, -1424479739 * Class372_Sub2.anInt4051, 1135094847 * Class372_Sub2.anInt4048, -1212608691);
				i_35_ = Class463.method6012(i_35_, (Class372_Sub2.anInt4051 * -1424479739), Class372_Sub2.anInt4048 * 1135094847, -1212608691);
				Class474.method6072(i, i_35_, i_36_, i_37_, 181729650);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.q(").append(')').toString());
		}
	}

	public static void method3927(int i) {
		try {
			Class203.method1910(1654985168);
			Class247.method2365(676003999);
			Class141.method1561(-507349147);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.k(").append(')').toString());
		}
	}

	static void method3928(int i, byte i_39_) {
		try {
			if (20 == i)
				throw new Error();
			if (26 == i)
				throw new OutOfMemoryError();
			try {
				if (i == 1)
					Class_v.method3673(-200374470);
				else if (i == 5)
					Class255.method2435(new StringBuilder().append("").append(914379507 * Class291.anInt6467).toString(), 1771664525);
				else if (i == 24) {
					Class333 class333 = (client.aClass283_8716.method2675(-1611682495).aClass333_3512);
					class333.aBoolean3583 = !class333.aBoolean3583;
				} else if (i == 8)
					client.aBoolean8667 = true;
				else if (27 == i)
					client.aBoolean8667 = false;
				else if (i == 22)
					client.aClass442_8650.method5869(355993737);
				else if (16 == i) {
					Class373.method4610(-851414705);
					for (int i_40_ = 0; i_40_ < 10; i_40_++)
						System.gc();
					Runtime runtime = Runtime.getRuntime();
					int i_41_ = (int) ((runtime.totalMemory() - runtime.freeMemory()) / 1024L);
					Class255.method2435(new StringBuilder().append("").append(i_41_).toString(), 1598262745);
				} else if (10 == i) {
					Class373.method4610(1839277481);
					for (int i_42_ = 0; i_42_ < 10; i_42_++)
						System.gc();
					Runtime runtime = Runtime.getRuntime();
					int i_43_ = (int) ((runtime.totalMemory() - runtime.freeMemory()) / 1024L);
					Class255.method2435(new StringBuilder().append("").append(i_43_).toString(), 840220855);
					Class234.method2183(-792495658);
					Class373.method4610(-1340221001);
					for (int i_44_ = 0; i_44_ < 10; i_44_++)
						System.gc();
					i_43_ = (int) ((runtime.totalMemory() - runtime.freeMemory()) / 1024L);
					Class255.method2435(new StringBuilder().append("").append(i_43_).toString(), 1145170625);
				} else if (15 == i)
					Class255.method2435((Class84.aClass305_770.method264(-242181565) ? "Success" : "Failure"), 1719326530);
				else if (2 == i)
					Class474.aClass471_5979.method6058(-89990065);
				else if (i == 14)
					Class248.aClass247_2752.method2346((byte) -87);
				else if (13 == i)
					Class248.aClass247_2752.method2345((byte) 0);
				else if (4 == i)
					Class52_Sub2_Sub1.aCanvas9079.setLocation(50, 50);
				else if (i == 25)
					Class52_Sub2_Sub1.aCanvas9079.setLocation(1898544019 * Class291.anInt6473, 540368727 * Class291.anInt6474);
				else if (i == 23)
					Class365_Sub1.method4403((byte) -117);
				else if (21 == i) {
					client.aClass283_8716.aLong3045 = Class122.method1319((byte) 1) * 3385627052850178407L;
					client.aClass283_8716.aBoolean3008 = true;
					Class365_Sub1.method4403((byte) -48);
				} else if (29 == i) {
					Class217 class217 = (Class287.myPlayer.method4337().aClass217_2599);
					Class255.method2435(new StringBuilder().append((int) class217.aFloat2451 >> 9).append(" ").append((int) class217.aFloat2454 >> 9).toString(), 2030018099);
				} else if (i == 7) {
					Class217 class217 = (Class287.myPlayer.method4337().aClass217_2599);
					Class255.method2435(new StringBuilder().append("").append(client.aClass283_8716.method2675(-1611682495).aClass_xaArray3517[(Class287.myPlayer.plane)].method6341((int) class217.aFloat2451 >> 9, (int) class217.aFloat2454 >> 9, (byte) -102)).toString(), 417961088);
				} else if (i == 3) {
					Class255.method2435(new StringBuilder().append(IComponentDefinition.aClass348_1135.method4192(-262201221)).append(" ").append(IComponentDefinition.aClass348_1135.method4188(-480173906)).toString(), 1301637250);
					Class255.method2435(new StringBuilder().append(IComponentDefinition.aClass348_1138.method4192(509188014)).append(" ").append(IComponentDefinition.aClass348_1138.method4188(2067697941)).toString(), 1826870364);
					Class255.method2435(new StringBuilder().append(Class298_Sub32_Sub14.aClass477_9400.aClass340_5995.method4135()).append(" ").append(Class298_Sub32_Sub14.aClass477_9400.aClass340_5995.method4133()).toString(), 1449325870);
				} else if (i == 6)
					Class223.method2082(false, -1663847334);
				else if (i == 17) {
					client.aBoolean8668 = !client.aBoolean8668;
					Class373.aClass_ra4071.method5061(client.aBoolean8668);
					Class422_Sub1.method5626(-1727592457);
				} else if (11 == i) {
					client.anInt8814 = 0;
					client.aClass283_8716.method2667(72202504);
				} else if (9 == i) {
					client.anInt8814 = 1482609571;
					client.aClass283_8716.method2667(418889356);
				} else if (28 == i) {
					client.anInt8814 = -1329748154;
					client.aClass283_8716.method2667(989855246);
				}
			} catch (Exception exception) {
				Class255.method2435(Tradution.aClass470_5782.method6049(aClass429_3357, -875414210), 1297300690);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("nj.h(").append(')').toString());
		}
	}
}
