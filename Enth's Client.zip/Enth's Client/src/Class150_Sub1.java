/* Class150_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class150_Sub1 extends Class150 {
	public static float aFloat7011;
	public static float aFloat7012 = 0.25F;
	public static float aFloat7013 = 1.0F;
	Class298_Sub31_Sub1 aClass298_Sub31_Sub1_7014;
	public static float aFloat7015;
	Class123 aClass123_7016;
	Class110 aClass110_7017;
	Class110 aClass110_7018;
	Class110 aClass110_7019;
	Class298_Sub31_Sub1 aClass298_Sub31_Sub1_7020;
	Class298_Sub31_Sub1 aClass298_Sub31_Sub1_7021;
	Class110 aClass110_7022;
	Class298_Sub31_Sub1 aClass298_Sub31_Sub1_7023;
	Class298_Sub31_Sub1 aClass298_Sub31_Sub1_7024;
	Class298_Sub31_Sub1 aClass298_Sub31_Sub1_7025;
	Class110 aClass110_7026;
	static int anInt7027 = 256;
	boolean aBoolean7028;

	void method1622() {
		/* empty */
	}

	boolean method1635() {
		return (aClass_ra_Sub3_1585.aBoolean8349 && aClass_ra_Sub3_1585.method5483());
	}

	boolean method1617() {
		return ((Class150_Sub1) this).aBoolean7028;
	}

	void method1630(int i, Class52_Sub1 class52_sub1, Interface9_Impl2 interface9_impl2, Interface8_Impl1_Impl2 interface8_impl1_impl2, Interface9_Impl2 interface9_impl2_0_) {
		float f = aClass_ra_Sub3_1585.method5315();
		float f_1_ = (float) class52_sub1.method545();
		float f_2_ = (float) class52_sub1.method552();
		Interface9_Impl2 interface9_impl2_3_ = interface9_impl2;
		float[] fs = { -1.0F, 1.0F, 0.0F, 0.0F, -1.0F, -3.0F, 0.0F, 2.0F, 3.0F, 1.0F, 2.0F, 0.0F };
		int i_4_ = (int) f_1_;
		int i_5_ = (int) f_2_;
		int i_6_ = i_4_;
		int i_7_ = i_5_;
		if (i == 0) {
			i_4_ = 256;
			i_5_ = 256;
			((Class150_Sub1) this).aClass123_7016.method1331(((Class150_Sub1) this).aClass110_7026);
			((Class150_Sub1) this).aClass123_7016.method1340();
		} else if (i == 1) {
			i_4_ = 256;
			i_5_ = 256;
			i_6_ = i_4_;
			i_7_ = i_5_;
			((Class150_Sub1) this).aClass123_7016.method1331(((Class150_Sub1) this).aClass110_7019);
			((Class150_Sub1) this).aClass123_7016.method1340();
			((Class150_Sub1) this).aClass123_7016.method1324(((Class150_Sub1) this).aClass298_Sub31_Sub1_7025, aFloat7015 / f_1_, 0.0F, 1650378474);
		} else if (i == 2) {
			i_4_ = 256;
			i_5_ = 256;
			i_6_ = i_4_;
			i_7_ = i_5_;
			((Class150_Sub1) this).aClass123_7016.method1331(((Class150_Sub1) this).aClass110_7019);
			((Class150_Sub1) this).aClass123_7016.method1340();
			((Class150_Sub1) this).aClass123_7016.method1324(((Class150_Sub1) this).aClass298_Sub31_Sub1_7025, 0.0F, aFloat7015 / f_2_, 1292626481);
		} else if (i == 3) {
			((Class150_Sub1) this).aClass123_7016.method1331(((Class150_Sub1) this).aClass110_7017);
			interface9_impl2_3_ = interface9_impl2_0_;
			((Class150_Sub1) this).aClass123_7016.method1341(((Class150_Sub1) this).aClass298_Sub31_Sub1_7023, 1, interface9_impl2, -1982319210);
			((Class150_Sub1) this).aClass123_7016.method1340();
		}
		float f_8_ = (float) i_4_ / f_1_;
		float f_9_ = (float) i_5_ / f_2_;
		float f_10_ = (float) i_6_ / f_1_;
		float f_11_ = (float) i_7_ / f_2_;
		fs[8] = (fs[8] + 1.0F) * f_8_ - 1.0F;
		fs[5] = (fs[5] - 1.0F) * f_9_ + 1.0F;
		fs[10] *= f_10_;
		fs[7] *= f_11_;
		((Class150_Sub1) this).aClass123_7016.method1347(((Class150_Sub1) this).aClass298_Sub31_Sub1_7020, fs, (byte) -59);
		((Class150_Sub1) this).aClass123_7016.method1341(((Class150_Sub1) this).aClass298_Sub31_Sub1_7021, 0, interface9_impl2_3_, -2011924567);
		((Class150_Sub1) this).aClass123_7016.method1366(((Class150_Sub1) this).aClass298_Sub31_Sub1_7024, aFloat7011, aFloat7012, aFloat7013, 0.0F, -256612832);
		((Class150_Sub1) this).aClass123_7016.method1366(((Class150_Sub1) this).aClass298_Sub31_Sub1_7014, f / f_1_, f / f_2_, 256.0F / f_1_, 256.0F / f_2_, 841962720);
		aClass_ra_Sub3_1585.method5187(0, 0, i_4_, i_5_);
		aClass_ra_Sub3_1585.r(0, 0, i_4_, i_5_);
	}

	void method1621(int i, int i_12_) {
		/* empty */
	}

	int method1624() {
		return 4;
	}

	void method1633(int i, Class52_Sub1 class52_sub1, Interface9_Impl2 interface9_impl2, Interface8_Impl1_Impl2 interface8_impl1_impl2, Interface9_Impl2 interface9_impl2_13_) {
		float f = aClass_ra_Sub3_1585.method5315();
		float f_14_ = (float) class52_sub1.method545();
		float f_15_ = (float) class52_sub1.method552();
		Interface9_Impl2 interface9_impl2_16_ = interface9_impl2;
		float[] fs = { -1.0F, 1.0F, 0.0F, 0.0F, -1.0F, -3.0F, 0.0F, 2.0F, 3.0F, 1.0F, 2.0F, 0.0F };
		int i_17_ = (int) f_14_;
		int i_18_ = (int) f_15_;
		int i_19_ = i_17_;
		int i_20_ = i_18_;
		if (i == 0) {
			i_17_ = 256;
			i_18_ = 256;
			((Class150_Sub1) this).aClass123_7016.method1331(((Class150_Sub1) this).aClass110_7026);
			((Class150_Sub1) this).aClass123_7016.method1340();
		} else if (i == 1) {
			i_17_ = 256;
			i_18_ = 256;
			i_19_ = i_17_;
			i_20_ = i_18_;
			((Class150_Sub1) this).aClass123_7016.method1331(((Class150_Sub1) this).aClass110_7019);
			((Class150_Sub1) this).aClass123_7016.method1340();
			((Class150_Sub1) this).aClass123_7016.method1324(((Class150_Sub1) this).aClass298_Sub31_Sub1_7025, aFloat7015 / f_14_, 0.0F, -1570489076);
		} else if (i == 2) {
			i_17_ = 256;
			i_18_ = 256;
			i_19_ = i_17_;
			i_20_ = i_18_;
			((Class150_Sub1) this).aClass123_7016.method1331(((Class150_Sub1) this).aClass110_7019);
			((Class150_Sub1) this).aClass123_7016.method1340();
			((Class150_Sub1) this).aClass123_7016.method1324(((Class150_Sub1) this).aClass298_Sub31_Sub1_7025, 0.0F, aFloat7015 / f_15_, 895542574);
		} else if (i == 3) {
			((Class150_Sub1) this).aClass123_7016.method1331(((Class150_Sub1) this).aClass110_7017);
			interface9_impl2_16_ = interface9_impl2_13_;
			((Class150_Sub1) this).aClass123_7016.method1341(((Class150_Sub1) this).aClass298_Sub31_Sub1_7023, 1, interface9_impl2, -1586296471);
			((Class150_Sub1) this).aClass123_7016.method1340();
		}
		float f_21_ = (float) i_17_ / f_14_;
		float f_22_ = (float) i_18_ / f_15_;
		float f_23_ = (float) i_19_ / f_14_;
		float f_24_ = (float) i_20_ / f_15_;
		fs[8] = (fs[8] + 1.0F) * f_21_ - 1.0F;
		fs[5] = (fs[5] - 1.0F) * f_22_ + 1.0F;
		fs[10] *= f_23_;
		fs[7] *= f_24_;
		((Class150_Sub1) this).aClass123_7016.method1347(((Class150_Sub1) this).aClass298_Sub31_Sub1_7020, fs, (byte) 51);
		((Class150_Sub1) this).aClass123_7016.method1341(((Class150_Sub1) this).aClass298_Sub31_Sub1_7021, 0, interface9_impl2_16_, -709560507);
		((Class150_Sub1) this).aClass123_7016.method1366(((Class150_Sub1) this).aClass298_Sub31_Sub1_7024, aFloat7011, aFloat7012, aFloat7013, 0.0F, -749411893);
		((Class150_Sub1) this).aClass123_7016.method1366(((Class150_Sub1) this).aClass298_Sub31_Sub1_7014, f / f_14_, f / f_15_, 256.0F / f_14_, 256.0F / f_15_, -14612883);
		aClass_ra_Sub3_1585.method5187(0, 0, i_17_, i_18_);
		aClass_ra_Sub3_1585.r(0, 0, i_17_, i_18_);
	}

	void method1623(int i) {
		((Class150_Sub1) this).aClass123_7016.method1372();
	}

	void method1629(int i, int i_25_) {
		/* empty */
	}

	boolean method1618() {
		if (method1635()) {
			((Class150_Sub1) this).aClass123_7016 = aClass_ra_Sub3_1585.method5297("FilterBloom");
			if (((Class150_Sub1) this).aClass123_7016 == null)
				return false;
			try {
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7021 = ((Class150_Sub1) this).aClass123_7016.method1360("sceneTex", -490582709);
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7023 = ((Class150_Sub1) this).aClass123_7016.method1360("bloomTex1", 1106954447);
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7024 = ((Class150_Sub1) this).aClass123_7016.method1360("params", 903814817);
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7025 = ((Class150_Sub1) this).aClass123_7016.method1360("sampleSize", 1499503394);
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7014 = ((Class150_Sub1) this).aClass123_7016.method1360("pixelOffsetAndBloomScale", 348725520);
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7020 = ((Class150_Sub1) this).aClass123_7016.method1360("PosAndTexCoords", -1410472149);
				((Class150_Sub1) this).aClass123_7016.method1327("test", (byte) -51);
				((Class150_Sub1) this).aClass110_7022 = ((Class150_Sub1) this).aClass123_7016.method1327("techFullscreenTri", (byte) -32);
				((Class150_Sub1) this).aClass110_7026 = ((Class150_Sub1) this).aClass123_7016.method1327("brightpass", (byte) -69);
				((Class150_Sub1) this).aClass110_7019 = ((Class150_Sub1) this).aClass123_7016.method1327("blur", (byte) -25);
				((Class150_Sub1) this).aClass110_7017 = ((Class150_Sub1) this).aClass123_7016.method1327("composite", (byte) -20);
				((Class150_Sub1) this).aClass110_7018 = ((Class150_Sub1) this).aClass123_7016.method1327("techDefault", (byte) -52);
			} catch (Exception_Sub2_Sub1 exception_sub2_sub1) {
				return false;
			} catch (Exception_Sub2_Sub2 exception_sub2_sub2) {
				return false;
			}
			if (!((Class150_Sub1) this).aClass110_7022.method1221())
				return false;
			if (!((Class150_Sub1) this).aClass110_7026.method1221())
				return false;
			if (!((Class150_Sub1) this).aClass110_7019.method1221())
				return false;
			if (!((Class150_Sub1) this).aClass110_7017.method1221())
				return false;
			if (!((Class150_Sub1) this).aClass110_7018.method1221())
				return false;
			((Class150_Sub1) this).aBoolean7028 = true;
			return true;
		}
		return false;
	}

	boolean method1628() {
		if (method1635()) {
			((Class150_Sub1) this).aClass123_7016 = aClass_ra_Sub3_1585.method5297("FilterBloom");
			if (((Class150_Sub1) this).aClass123_7016 == null)
				return false;
			try {
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7021 = ((Class150_Sub1) this).aClass123_7016.method1360("sceneTex", 1800902874);
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7023 = ((Class150_Sub1) this).aClass123_7016.method1360("bloomTex1", 258882417);
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7024 = ((Class150_Sub1) this).aClass123_7016.method1360("params", 710877895);
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7025 = ((Class150_Sub1) this).aClass123_7016.method1360("sampleSize", -764686170);
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7014 = ((Class150_Sub1) this).aClass123_7016.method1360("pixelOffsetAndBloomScale", -2115103811);
				((Class150_Sub1) this).aClass298_Sub31_Sub1_7020 = ((Class150_Sub1) this).aClass123_7016.method1360("PosAndTexCoords", 279862210);
				((Class150_Sub1) this).aClass123_7016.method1327("test", (byte) -106);
				((Class150_Sub1) this).aClass110_7022 = ((Class150_Sub1) this).aClass123_7016.method1327("techFullscreenTri", (byte) -43);
				((Class150_Sub1) this).aClass110_7026 = ((Class150_Sub1) this).aClass123_7016.method1327("brightpass", (byte) -115);
				((Class150_Sub1) this).aClass110_7019 = ((Class150_Sub1) this).aClass123_7016.method1327("blur", (byte) -80);
				((Class150_Sub1) this).aClass110_7017 = ((Class150_Sub1) this).aClass123_7016.method1327("composite", (byte) -103);
				((Class150_Sub1) this).aClass110_7018 = ((Class150_Sub1) this).aClass123_7016.method1327("techDefault", (byte) -21);
			} catch (Exception_Sub2_Sub1 exception_sub2_sub1) {
				return false;
			} catch (Exception_Sub2_Sub2 exception_sub2_sub2) {
				return false;
			}
			if (!((Class150_Sub1) this).aClass110_7022.method1221())
				return false;
			if (!((Class150_Sub1) this).aClass110_7026.method1221())
				return false;
			if (!((Class150_Sub1) this).aClass110_7019.method1221())
				return false;
			if (!((Class150_Sub1) this).aClass110_7017.method1221())
				return false;
			if (!((Class150_Sub1) this).aClass110_7018.method1221())
				return false;
			((Class150_Sub1) this).aBoolean7028 = true;
			return true;
		}
		return false;
	}

	int method1625() {
		return 1;
	}

	int method1636() {
		return 1;
	}

	void method1620() {
		/* empty */
	}

	void method1631(int i) {
		((Class150_Sub1) this).aClass123_7016.method1372();
	}

	void method1632(int i) {
		((Class150_Sub1) this).aClass123_7016.method1372();
	}

	int method1637() {
		return 1;
	}

	int method1638() {
		return 1;
	}

	public Class150_Sub1(Class_ra_Sub3 class_ra_sub3) {
		super(class_ra_sub3);
	}

	int method1639() {
		return 1;
	}

	int method1640() {
		return 4;
	}

	int method1641() {
		return 1;
	}

	boolean method1634() {
		return ((Class150_Sub1) this).aBoolean7028;
	}

	static {
		aFloat7011 = 1.0F;
		aFloat7015 = 1.0F;
	}

	int method1642() {
		return 4;
	}
}
