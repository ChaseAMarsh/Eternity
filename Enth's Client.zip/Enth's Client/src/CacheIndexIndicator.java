/* Class111 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class CacheIndexIndicator {
	public static CacheIndexIndicator aClass111_1329;
	public static CacheIndexIndicator aClass111_1330;
	public static CacheIndexIndicator aClass111_1331;
	public static CacheIndexIndicator aClass111_1332;
	public static CacheIndexIndicator aClass111_1333;
	public static CacheIndexIndicator aClass111_1334;
	public static CacheIndexIndicator aClass111_1335;
	public static CacheIndexIndicator aClass111_1336;
	public static CacheIndexIndicator aClass111_1337;
	public static CacheIndexIndicator aClass111_1338;
	public static CacheIndexIndicator aClass111_1339 = new CacheIndexIndicator(0);
	public static CacheIndexIndicator aClass111_1340;
	public static CacheIndexIndicator aClass111_1341 = new CacheIndexIndicator(1);
	public static CacheIndexIndicator aClass111_1342;
	public static CacheIndexIndicator aClass111_1343;
	public static CacheIndexIndicator aClass111_1344;
	public static CacheIndexIndicator aClass111_1345;
	public static CacheIndexIndicator aClass111_1346;
	public static CacheIndexIndicator aClass111_1347;
	public static CacheIndexIndicator aClass111_1348;
	public static CacheIndexIndicator aClass111_1349;
	public static CacheIndexIndicator aClass111_1350;
	public static CacheIndexIndicator aClass111_1351;
	public static CacheIndexIndicator aClass111_1352;
	public static CacheIndexIndicator aClass111_1353;
	public static CacheIndexIndicator aClass111_1354;
	public static CacheIndexIndicator aClass111_1355;
	public static CacheIndexIndicator aClass111_1356;
	public static CacheIndexIndicator aClass111_1357;
	public static CacheIndexIndicator aClass111_1358;
	public static CacheIndexIndicator aClass111_1359;
	public static CacheIndexIndicator aClass111_1360;
	public static CacheIndexIndicator aClass111_1361;
	public static CacheIndexIndicator aClass111_1362;
	public static CacheIndexIndicator aClass111_1363;
	public static CacheIndexIndicator indicator_worldMap;
	public static CacheIndexIndicator aClass111_1365;
	int anInt1366;
	static int anInt1367;

	static {
		aClass111_1331 = new CacheIndexIndicator(2);
		aClass111_1332 = new CacheIndexIndicator(3);
		aClass111_1359 = new CacheIndexIndicator(4);
		aClass111_1334 = new CacheIndexIndicator(5);
		aClass111_1335 = new CacheIndexIndicator(6);
		aClass111_1353 = new CacheIndexIndicator(7);
		aClass111_1330 = new CacheIndexIndicator(8);
		aClass111_1338 = new CacheIndexIndicator(9);
		aClass111_1336 = new CacheIndexIndicator(10);
		aClass111_1340 = new CacheIndexIndicator(11);
		aClass111_1351 = new CacheIndexIndicator(12);
		aClass111_1342 = new CacheIndexIndicator(13);
		aClass111_1343 = new CacheIndexIndicator(14);
		aClass111_1344 = new CacheIndexIndicator(15);
		aClass111_1333 = new CacheIndexIndicator(16);
		aClass111_1346 = new CacheIndexIndicator(17);
		aClass111_1347 = new CacheIndexIndicator(18);
		aClass111_1360 = new CacheIndexIndicator(19);
		aClass111_1348 = new CacheIndexIndicator(20);
		aClass111_1350 = new CacheIndexIndicator(21);
		aClass111_1349 = new CacheIndexIndicator(22);
		indicator_worldMap = new CacheIndexIndicator(23);
		aClass111_1329 = new CacheIndexIndicator(24);
		aClass111_1354 = new CacheIndexIndicator(25);
		aClass111_1355 = new CacheIndexIndicator(26);
		aClass111_1356 = new CacheIndexIndicator(27);
		aClass111_1357 = new CacheIndexIndicator(28);
		aClass111_1345 = new CacheIndexIndicator(29);
		aClass111_1358 = new CacheIndexIndicator(30);
		aClass111_1352 = new CacheIndexIndicator(31);
		aClass111_1361 = new CacheIndexIndicator(32);
		aClass111_1362 = new CacheIndexIndicator(33);
		aClass111_1363 = new CacheIndexIndicator(34);
		aClass111_1337 = new CacheIndexIndicator(35);
		aClass111_1365 = new CacheIndexIndicator(36);
		anInt1367 = 1700689323;
	}

	CacheIndexIndicator(int i) {
		((CacheIndexIndicator) this).anInt1366 = i * 1424986353;
	}

	public int method1233(int i) {
		try {
			return ((CacheIndexIndicator) this).anInt1366 * -1047699439;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("en.f(").append(')').toString());
		}
	}

	static final void method1234(ClientScript2 class403, int i) {
		try {
			int i_0_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			int i_1_ = client.aClass251Array8920[i_0_].method2400(-574288948);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_1_ == 5 ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("en.ye(").append(')').toString());
		}
	}

	static final void method1235(IComponentDefinition class105, ClientScript2 class403, byte i) {
		try {
			Class505 class505 = class105.method1113(Class497.aClass197_6105, client.anInterface10_8700, (byte) 88);
			int i_2_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			int i_3_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			int i_4_ = class505.method6261(class105.aString1212, class105.anInt1156 * -2093041337, class105.anInt1191 * 418216501, i_3_, i_2_, Class130_Sub2.aClass57Array6959, (byte) -62);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_4_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("en.qg(").append(')').toString());
		}
	}

	public static boolean method1236(int i, int i_5_) {
		try {
			return (i >= -1976050083 * Class424.aClass424_6612.anInt6613 && i <= Class424.aClass424_6597.anInt6613 * -1976050083);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("en.d(").append(')').toString());
		}
	}

	static final void method1237(ClientScript2 class403, int i) {
		try {
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub13_7549, (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]), -800925761);
			Class3.method300(656179282);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("en.aix(").append(')').toString());
		}
	}

	public static Class456[] method1238(Class457 class457, short i) {
		try {
			int[] is = class457.method5961();
			Class456[] class456s = new Class456[is.length >> 2];
			for (int i_6_ = 0; i_6_ < class456s.length; i_6_++) {
				Class456 class456 = new Class456();
				class456s[i_6_] = class456;
				class456.anInt5663 = -1110150949 * is[i_6_ << 2];
				class456.anInt5665 = is[1 + (i_6_ << 2)] * 1756912603;
				class456.anInt5664 = 1912690475 * is[2 + (i_6_ << 2)];
				((Class456) class456).anInt5662 = 2041694879 * is[(i_6_ << 2) + 3];
			}
			return class456s;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("en.a(").append(')').toString());
		}
	}
}
