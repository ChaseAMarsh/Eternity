/* Class212 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class212 {
	public static Class212 aClass212_2421;
	public static Class212 aClass212_2422;
	public static Class212 aClass212_2423;
	public static Class212 aClass212_2424;
	public static Class212 aClass212_2425;
	public static Class212 aClass212_2426;
	public static Class212 aClass212_2427;
	public static Class212 aClass212_2428;
	public static Class212 aClass212_2429;
	public static Class212 aClass212_2430;
	public static Class212 aClass212_2431 = new Class212(8);
	int anInt2432;
	public static Class144 aClass144_2433;

	public String method1951(int i) {
		try {
			return new StringBuilder().append("_").append(368445667 * ((Class212) this).anInt2432).toString();
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("iy.a(").append(')').toString());
		}
	}

	public void method1952(int i) {
		try {
			try {
				method1954(-1654113322);
			} catch (Throwable throwable) {
				/* empty */
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("iy.i(").append(')').toString());
		}
	}

	public Object method1953(Object[] objects, int i) throws Throwable {
		try {
			return Class466.method6022(ClientScriptMap.anApplet6044, method1951(-1115089525), objects, (byte) 42);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("iy.f(").append(')').toString());
		}
	}

	public Object method1954(int i) throws Throwable {
		try {
			return Class466.method6021(ClientScriptMap.anApplet6044, method1951(-1685973242), (short) 7317);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("iy.b(").append(')').toString());
		}
	}

	public void method1955(Object[] objects, short i) {
		try {
			try {
				method1953(objects, -505878478);
			} catch (Throwable throwable) {
				/* empty */
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("iy.p(").append(')').toString());
		}
	}

	Class212(int i) {
		((Class212) this).anInt2432 = i * -665617205;
	}

	static {
		aClass212_2422 = new Class212(2);
		aClass212_2423 = new Class212(5);
		aClass212_2427 = new Class212(1);
		aClass212_2425 = new Class212(4);
		aClass212_2426 = new Class212(11);
		aClass212_2428 = new Class212(7);
		aClass212_2421 = new Class212(9);
		aClass212_2429 = new Class212(10);
		aClass212_2430 = new Class212(6);
		aClass212_2424 = new Class212(3);
	}

	static final void method1956(ClientScript2 class403, byte i) {
		try {
			int i_0_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_0_, (byte) 9);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = 7329457 * class105.anInt1190;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("iy.ry(").append(')').toString());
		}
	}

	static final void method1957(ClientScript2 class403, int i) {
		try {
			if (client.aBoolean8638)
				aClass212_2428.method1952(-1282139057);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("iy.ano(").append(')').toString());
		}
	}
}
