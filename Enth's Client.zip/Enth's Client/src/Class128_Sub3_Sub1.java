/* Class128_Sub3_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class128_Sub3_Sub1 extends Class128_Sub3 {
	public int anInt9942;

	public Class146 method49(int i) {
		try {
			return Class146.aClass146_1571;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("afr.f(").append(')').toString());
		}
	}

	Class128_Sub3_Sub1(Class139 class139, Class133 class133, int i, int i_0_, int i_1_, int i_2_, int i_3_, int i_4_, int i_5_, int i_6_, int i_7_, int i_8_, int i_9_, int i_10_, int i_11_, int i_12_) {
		super(class139, class133, i, i_0_, i_1_, i_2_, i_3_, i_4_, i_5_, i_6_, i_7_, i_8_, i_9_, i_10_, i_11_);
		anInt9942 = i_12_ * -1980199237;
	}

	public Class146 method51() {
		return Class146.aClass146_1571;
	}

	public Class146 method50() {
		return Class146.aClass146_1571;
	}
}
