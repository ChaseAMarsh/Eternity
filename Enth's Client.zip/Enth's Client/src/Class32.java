/* Class32 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class32 {
	short aShort395;
	byte aByte396;
	Interface1 anInterface1_397;
	byte aByte398;

	Class32(Interface1 interface1, int i, int i_0_, int i_1_) {
		((Class32) this).anInterface1_397 = interface1;
		((Class32) this).aShort395 = (short) i;
		((Class32) this).aByte396 = (byte) i_0_;
		((Class32) this).aByte398 = (byte) i_1_;
	}
}
