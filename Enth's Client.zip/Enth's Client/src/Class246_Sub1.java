/* Class246_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class246_Sub1 extends Class246 implements Interface7_Impl2 {
	Class77 aClass77_8577;

	public boolean method63(int i, int i_0_, long l) {
		return super.method63(i, i_0_, l);
	}

	public void d() {
		super.b();
	}

	Class77 method2335() {
		return ((Class246_Sub1) this).aClass77_8577;
	}

	public void method114(int i) {
		super.method113(i * (((Class246_Sub1) this).aClass77_8577.anInt724 * 685647847));
	}

	public void b() {
		super.b();
	}

	public void method113(int i) {
		super.method113(i * (((Class246_Sub1) this).aClass77_8577.anInt724 * 685647847));
	}

	public void method66() {
		super.method69();
	}

	Class246_Sub1(Class_ra_Sub3_Sub1 class_ra_sub3_sub1, Class77 class77, boolean bool) {
		super(class_ra_sub3_sub1, 34963, bool);
		((Class246_Sub1) this).aClass77_8577 = class77;
	}

	public long method62(int i, int i_1_) {
		return super.method62(i, i_1_);
	}

	public void u() {
		super.b();
	}

	public void x() {
		super.b();
	}

	public int method64() {
		return super.method60();
	}

	public int method65() {
		return super.method60();
	}

	public boolean method61(int i, int i_2_, long l) {
		return super.method63(i, i_2_, l);
	}

	public boolean method67(int i, int i_3_, long l) {
		return super.method63(i, i_3_, l);
	}

	public long method68(int i, int i_4_) {
		return super.method62(i, i_4_);
	}

	public int method60() {
		return super.method60();
	}

	public void method112(int i) {
		super.method113(i * (((Class246_Sub1) this).aClass77_8577.anInt724 * 685647847));
	}

	public void method69() {
		super.method69();
	}

	public void method115(int i) {
		super.method113(i * (((Class246_Sub1) this).aClass77_8577.anInt724 * 685647847));
	}

	public void method116(int i) {
		super.method113(i * (((Class246_Sub1) this).aClass77_8577.anInt724 * 685647847));
	}
}
