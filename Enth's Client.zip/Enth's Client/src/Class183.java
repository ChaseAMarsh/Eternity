/* Class183 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class183 {
	public static Class183 aClass183_1887 = new Class183(0);
	public static Class183 aClass183_1888 = new Class183(2);
	public static Class183 aClass183_1889 = new Class183(3);
	public static Class183 aClass183_1890 = new Class183(1);
	public int anInt1891;

	Class183(int i) {
		anInt1891 = i;
	}
}
