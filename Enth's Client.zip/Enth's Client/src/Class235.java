/* Class235 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class235 {
	public Class217 aClass217_2599;
	public Class218 aClass218_2600;

	public Class235(Class235 class235_0_) {
		aClass218_2600 = new Class218();
		aClass217_2599 = new Class217();
		method2186(class235_0_);
	}

	public final void method2185() {
		aClass218_2600.method2024();
		aClass217_2599.method2008();
		aClass217_2599.method2014(aClass218_2600);
	}

	public Class235() {
		aClass218_2600 = new Class218();
		aClass217_2599 = new Class217();
	}

	public void method2186(Class235 class235_1_) {
		aClass218_2600.method2022(class235_1_.aClass218_2600);
		aClass217_2599.method2013(class235_1_.aClass217_2599);
	}

	public final void method2187(Class235 class235_2_) {
		aClass218_2600.method2026(class235_2_.aClass218_2600);
		aClass217_2599.method2014(class235_2_.aClass218_2600);
		aClass217_2599.method2009(class235_2_.aClass217_2599);
	}
}
