/* Class191 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class191 {
	int anInt1944;
	boolean aBoolean1945;
	int anInt1946;
	int anInt1947;
	short aShort1948;
	short aShort1949;
	short aShort1950;
	int anInt1951;
	int anInt1952;

	Class191(int i, int i_0_, int i_1_, int i_2_, int i_3_, int i_4_, int i_5_, int i_6_, int i_7_, boolean bool, boolean bool_8_, int i_9_) {
		((Class191) this).anInt1947 = i;
		((Class191) this).anInt1951 = i_0_;
		((Class191) this).anInt1946 = i_1_;
		((Class191) this).anInt1944 = i_2_;
		((Class191) this).aShort1948 = (short) i_3_;
		((Class191) this).aShort1949 = (short) i_4_;
		((Class191) this).aShort1950 = (short) i_5_;
		((Class191) this).aBoolean1945 = bool_8_;
		((Class191) this).anInt1952 = i_9_;
	}
}
