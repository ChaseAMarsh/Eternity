/* Class307 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class307 {
	Class307() {
		/* empty */
	}

	abstract void method3757(int i, int i_0_, int i_1_, int i_2_, float f, float f_3_, float f_4_, float f_5_, float[] fs, int i_6_);

	abstract void method3758(int i, int i_7_, int i_8_, int i_9_, float f, float f_10_, float f_11_, float f_12_, float[] fs, int i_13_);

	abstract void method3759(int i, int i_14_, int i_15_, int i_16_, float f, float f_17_, float f_18_, float f_19_, float[] fs, int i_20_);
}
