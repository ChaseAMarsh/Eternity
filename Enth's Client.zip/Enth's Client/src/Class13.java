/* Class13 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class13 {
	short[] aShortArray157;
	short aShort158;
	byte aByte159;
	short[] aShortArray160;
	short[] aShortArray161;
	short[] aShortArray162;
	int[] anIntArray163;
	int[] anIntArray164;
	short[] aShortArray165;
	short[] aShortArray166;
	short aShort167;

	Class13() {
		/* empty */
	}
}
