/* Class126 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.io.IOException;

public class Class126 implements Interface6 {
	CacheIndex aClass243_6367;
	Class151 aClass151_6368;
	CacheIndex aClass243_6369;
	Class264 aClass264_6370;

	public boolean method52(int i) {
		try {
			boolean bool = true;
			if (!((Class126) this).aClass243_6369.method2310(((Class126) this).aClass151_6368.anInt6355 * 180759529, -457216440))
				bool = false;
			if (!((Class126) this).aClass243_6367.method2310(((Class126) this).aClass151_6368.anInt6355 * 180759529, -457216440))
				bool = false;
			return bool;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fc.b(").append(')').toString());
		}
	}

	public void method55() {
		Class505 class505 = Class255.method2439(((Class126) this).aClass243_6367, 180759529 * (((Class126) this).aClass151_6368.anInt6355), 1190428797);
		((Class126) this).aClass264_6370 = (Class373.aClass_ra4071.method5092(class505, Class89.method981(((Class126) this).aClass243_6369, (((Class126) this).aClass151_6368.anInt6355 * 180759529)), true));
	}

	public void method58(boolean bool, byte i) {
		try {
			if (bool) {
				int i_0_ = ((((Class126) this).aClass151_6368.aClass139_6352.method1545((1296783199 * ((Class126) this).aClass151_6368.anInt6346), client.anInt8794 * 775068819, -2104401433)) + (((Class126) this).aClass151_6368.anInt6348 * -591189315));
				int i_1_ = ((((Class126) this).aClass151_6368.aClass133_6351.method1482((-1025867285 * ((Class126) this).aClass151_6368.anInt6347), client.anInt8803 * -791746413, -1504826584)) + (-842094713 * ((Class126) this).aClass151_6368.anInt6349));
				((Class126) this).aClass264_6370.method2475(((Class126) this).aClass151_6368.aString6353, i_0_, i_1_, ((Class126) this).aClass151_6368.anInt6346 * 1296783199, ((Class126) this).aClass151_6368.anInt6347 * -1025867285, 1046344713 * ((Class126) this).aClass151_6368.anInt6356, -122178497 * ((Class126) this).aClass151_6368.anInt6357, ((Class126) this).aClass151_6368.anInt6350 * -434174461, ((Class126) this).aClass151_6368.anInt6345 * -1329622453, 35264187 * ((Class126) this).aClass151_6368.anInt6354, null, null, null, 0, 0, -45995166);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fc.f(").append(')').toString());
		}
	}

	public boolean method57() {
		boolean bool = true;
		if (!((Class126) this).aClass243_6369.method2310(((((Class126) this).aClass151_6368.anInt6355) * 180759529), -457216440))
			bool = false;
		if (!((Class126) this).aClass243_6367.method2310(((((Class126) this).aClass151_6368.anInt6355) * 180759529), -457216440))
			bool = false;
		return bool;
	}

	public boolean method54() {
		boolean bool = true;
		if (!((Class126) this).aClass243_6369.method2310(((((Class126) this).aClass151_6368.anInt6355) * 180759529), -457216440))
			bool = false;
		if (!((Class126) this).aClass243_6367.method2310(((((Class126) this).aClass151_6368.anInt6355) * 180759529), -457216440))
			bool = false;
		return bool;
	}

	public void method56(boolean bool) {
		if (bool) {
			int i = ((((Class126) this).aClass151_6368.aClass139_6352.method1545(1296783199 * ((Class126) this).aClass151_6368.anInt6346, client.anInt8794 * 775068819, -1797975072)) + ((Class126) this).aClass151_6368.anInt6348 * -591189315);
			int i_2_ = ((((Class126) this).aClass151_6368.aClass133_6351.method1482(-1025867285 * ((Class126) this).aClass151_6368.anInt6347, client.anInt8803 * -791746413, -792749412)) + -842094713 * ((Class126) this).aClass151_6368.anInt6349);
			((Class126) this).aClass264_6370.method2475(((Class126) this).aClass151_6368.aString6353, i, i_2_, ((Class126) this).aClass151_6368.anInt6346 * 1296783199, ((Class126) this).aClass151_6368.anInt6347 * -1025867285, 1046344713 * ((Class126) this).aClass151_6368.anInt6356, -122178497 * ((Class126) this).aClass151_6368.anInt6357, ((Class126) this).aClass151_6368.anInt6350 * -434174461, ((Class126) this).aClass151_6368.anInt6345 * -1329622453, 35264187 * ((Class126) this).aClass151_6368.anInt6354, null, null, null, 0, 0, -45995166);
		}
	}

	public void method53(int i) {
		try {
			Class505 class505 = Class255.method2439(((Class126) this).aClass243_6367, 180759529 * (((Class126) this).aClass151_6368.anInt6355), 1240803660);
			((Class126) this).aClass264_6370 = (Class373.aClass_ra4071.method5092(class505, Class89.method981(((Class126) this).aClass243_6369, (((Class126) this).aClass151_6368.anInt6355) * 180759529), true));
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fc.a(").append(')').toString());
		}
	}

	Class126(CacheIndex class243, CacheIndex class243_3_, Class151 class151) {
		((Class126) this).aClass151_6368 = class151;
		((Class126) this).aClass243_6369 = class243;
		((Class126) this).aClass243_6367 = class243_3_;
	}

	public boolean method59() {
		boolean bool = true;
		if (!((Class126) this).aClass243_6369.method2310(((((Class126) this).aClass151_6368.anInt6355) * 180759529), -457216440))
			bool = false;
		if (!((Class126) this).aClass243_6367.method2310(((((Class126) this).aClass151_6368.anInt6355) * 180759529), -457216440))
			bool = false;
		return bool;
	}

	static int method1403(int i) {
		try {
			return (Class107.anInt1313 += 1968838043) * -239712109 - 1;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fc.a(").append(')').toString());
		}
	}

	static final void method1404(ClientScript2 class403, byte i) {
		try {
			int i_4_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_4_, (byte) -105);
			Class119 class119 = Class389.aClass119Array4165[i_4_ >> 16];
			Class499.method6218(class105, class119, class403, (byte) 46);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fc.lf(").append(')').toString());
		}
	}

	public static void method1405(Class502 class502, int i, int i_5_, int i_6_) {
		try {
			ClientScript2 class403 = Class211.method1950(-1745561895);
			SubIncommingPacket.method1925(class502, i, i_5_, class403, 536465062);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fc.r(").append(')').toString());
		}
	}

	static char method1406(char c, int i) {
		try {
			switch (c) {
			case '\u00d9':
			case '\u00da':
			case '\u00db':
			case '\u00dc':
			case '\u00f9':
			case '\u00fa':
			case '\u00fb':
			case '\u00fc':
				return 'u';
			case '\u00cd':
			case '\u00ce':
			case '\u00cf':
			case '\u00ed':
			case '\u00ee':
			case '\u00ef':
				return 'i';
			case '\u00d1':
			case '\u00f1':
				return 'n';
			case '\u00c8':
			case '\u00c9':
			case '\u00ca':
			case '\u00cb':
			case '\u00e8':
			case '\u00e9':
			case '\u00ea':
			case '\u00eb':
				return 'e';
			case '#':
			case '[':
			case ']':
				return c;
			case '\u00c7':
			case '\u00e7':
				return 'c';
			case '\u00c0':
			case '\u00c1':
			case '\u00c2':
			case '\u00c3':
			case '\u00c4':
			case '\u00e0':
			case '\u00e1':
			case '\u00e2':
			case '\u00e3':
			case '\u00e4':
				return 'a';
			default:
				return Character.toLowerCase(c);
			case '\u00ff':
			case '\u0178':
				return 'y';
			case '\u00d2':
			case '\u00d3':
			case '\u00d4':
			case '\u00d5':
			case '\u00d6':
			case '\u00f2':
			case '\u00f3':
			case '\u00f4':
			case '\u00f5':
			case '\u00f6':
				return 'o';
			case ' ':
			case '-':
			case '_':
			case '\u00a0':
				return '_';
			case '\u00df':
				return 'b';
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fc.k(").append(')').toString());
		}
	}

	static final void method1407(byte i) {
		try {
			if (1592380953 * client.anInt8669 > 1) {
				client.anInt8669 -= -2090750423;
				client.anInt8888 = 1991119277 * client.anInt8933;
			}
			if (client.aClass25_8711.aBoolean347) {
				client.aClass25_8711.aBoolean347 = false;
				SubIncommingPacket.method1923(-1982513993);
			} else {
				if (!Class436.aBoolean5478)
					Class98_Sub2.method1065((byte) 60);
				for (int i_7_ = 0; i_7_ < 100; i_7_++) {
					if (!Class247.method2370(client.aClass25_8711, 2136824168)) {
						if (i <= 4)
							throw new IllegalStateException();
						break;
					}
				}
				if (client.anInt8752 * -1233866115 == 0) {
					while (Class370.method4577((byte) 35)) {
						Class298_Sub36 class298_sub36 = Class18.method359(OutcommingPacket.aClass198_2005, (client.aClass25_8711.aClass449_330), (byte) 105);
						class298_sub36.aClass298_Sub53_Sub2_7396.writeByte(0);
						int i_8_ = ((class298_sub36.aClass298_Sub53_Sub2_7396.index) * 385051775);
						Class234.method2181((class298_sub36.aClass298_Sub53_Sub2_7396), -1720754748);
						class298_sub36.aClass298_Sub53_Sub2_7396.method3649((class298_sub36.aClass298_Sub53_Sub2_7396.index) * 385051775 - i_8_, (byte) -105);
						client.aClass25_8711.method390(class298_sub36, (byte) -102);
					}
					if (null != Class_xa.aClass396_6291) {
						if (Class_xa.aClass396_6291.anInt5195 * -747638219 != -1) {
							Class298_Sub36 class298_sub36 = Class18.method359(OutcommingPacket.aClass198_2009, (client.aClass25_8711.aClass449_330), (byte) 64);
							class298_sub36.aClass298_Sub53_Sub2_7396.writeShort((-747638219 * Class_xa.aClass396_6291.anInt5195), 16711935);
							client.aClass25_8711.method390(class298_sub36, (byte) -33);
							Class_xa.aClass396_6291 = null;
							Class365_Sub1_Sub2_Sub1.aLong9911 = ((Class122.method1319((byte) 1) + 30000L) * -5619030756491206545L);
						}
					} else if (Class122.method1319((byte) 1) >= (Class365_Sub1_Sub2_Sub1.aLong9911 * 416520701245947535L))
						Class_xa.aClass396_6291 = client.aClass404_8715.method4946((Class474.aClass471_5979.address), (byte) 25);
					if (!Loader.DISABLE_USELESS_PACKETS)
						Class247.method2371((byte) 82);
					Class298_Sub50 class298_sub50 = ((Class298_Sub50) client.aClass453_8827.method5939(1766612795));
					if (client.aClass283_8716.method2675(-1611682495) != null) {
						if (3 == Class298_Sub1.anInt7164 * -863531439)
							Class298_Sub39.method3506(78506535);
						else if (1 == -863531439 * Class298_Sub1.anInt7164)
							Class397.method4913((byte) 94);
					}
					if (client.aBoolean8761)
						client.aBoolean8761 = false;
					else
						client.aFloat8760 /= 2.0F;
					if (client.aBoolean8762)
						client.aBoolean8762 = false;
					else
						client.aFloat8759 /= 2.0F;
					SubIncommingPacket.method1921((byte) 111);
					if (0 == -1233866115 * client.anInt8752) {
						client.aClass283_8716.method2640((byte) 2).method4323(client.aClass283_8716, -2061035316);
						Class271.method2546(-2124691803);
						Graphics.method609((short) -26190);
						if (596487115 * client.anInt8723 > 10)
							((Class25) client.aClass25_8711).anInt338 += 157945923;
						if ((((Class25) client.aClass25_8711).anInt338 * 1237236843) > 2250)
							SubIncommingPacket.method1923(1705248535);
						else {
							if (client.anInt8724 * 1596783995 == 3) {
								Class162.method1771(921260863);
								Class298_Sub19_Sub3.method3037(1729319705);
							} else if (LinkedList.aClass377_5519.anInterface19_4091.method239(class298_sub50, client.anInterface16Array8688, -1625219821 * client.anInt8687, Class372.aClass323_4052, -490402318))
								Class107.method1144(false, (short) -10206);
							else {
								if (client.anInt8724 * 1596783995 == 1 && (Class298_Sub24_Sub3.method3090(577335585 * client.anInt8870, -275734557))) {
									client.aClass283_8716.sendMapScene(new Class267(Class266.aClass266_2846, null), -1991819579);
									client.anInt8724 = -347773236;
								}
								if (4 == 1596783995 * client.anInt8724 && 17 != client.anInt8752 * -1233866115) {
									Class87.aClass437_793.method5811((byte) -51);
									client.anInt8724 = 0;
									client.anInt8726 = -96767293 * client.anInt8884;
									client.anInt8930 = 0;
									Interface.method3575((byte) -114);
								}
								if (0 == 1596783995 * client.anInt8724) {
									int i_9_ = (443738891 * client.anInt8884 - client.anInt8726 * -1846472167);
									while_61_: do {
										if (1247173565 * client.anInt8930 < (Class87.aClass82Array797).length) {
											do {
												Class82 class82 = (Class87.aClass82Array797[(1247173565 * client.anInt8930)]);
												if ((class82.anInt761 * 1147432229) > i_9_) {
													if (i <= 4) {
														/* empty */
													}
													break while_61_;
												}
												class82.method866(-2077694254);
												if (0 != (1596783995 * client.anInt8724))
													break while_61_;
											} while (((client.anInt8930 += 1259550613) * 1247173565) < (Class87.aClass82Array797).length);
											if (i > 4)
												break;
										}
									} while (false);
									if (client.anInt8724 * 1596783995 == 0) {
										for (int i_10_ = 0; (i_10_ < (Class87.aClass94Array794).length); i_10_++) {
											Class94 class94 = (Class87.aClass94Array794[i_10_]);
											if (!class94.aBoolean912) {
												if (i <= 4)
													throw new IllegalStateException();
											} else {
												Entity class365_sub1_sub1_sub2 = (class94.method1015(21832379));
												Class135.method1494(class365_sub1_sub1_sub2, true, -1897267593);
											}
										}
									}
								}
							}
							Class422_Sub3.method5635(-1841664621);
							if (!client.aBoolean8917) {
								Class422_Sub30.method5732(1446435433);
								client.aBoolean8917 = true;
							}
							Class422_Sub5.method5644(-1345932063);
							client.anInt8961 += 512435497;
							if (0 != -392325587 * client.anInt8748) {
								client.anInt8786 += -421126628;
								if (client.anInt8786 * 1347929875 >= 400)
									client.anInt8748 = 0;
							}
							if (null != Class236.aClass105_2606) {
								client.anInt8788 += 289473031;
								if (client.anInt8788 * -2018194505 >= 15) {
									Tradution.method6054((Class236.aClass105_2606), -1829287170);
									Class236.aClass105_2606 = null;
								}
							}
							client.aClass105_8854 = null;
							client.aBoolean8938 = false;
							client.aBoolean8855 = false;
							Class113.aClass105_1373 = null;
							Class82_Sub17.method918(null, -1, -1, -6089367);
							if (!client.aBoolean8835)
								client.anInt8937 = 280458557;
							Class62.method732(-640926851);
							client.anInt8933 += -908761385;
							if (client.aBoolean8866) {
								Class298_Sub36 class298_sub36 = Class18.method359((OutcommingPacket.WORLD_MAP_CLICK_PACKET), (client.aClass25_8711.aClass449_330), (byte) 91);
								class298_sub36.aClass298_Sub53_Sub2_7396.writeInt((924378211 * Class241.anInt2706 << 28 | Class98.anInt950 * -537916961 << 14 | Class221.anInt6663 * -605610561), -1116555169);
								System.out.println(Class221.anInt6663);
								client.aClass25_8711.method390(class298_sub36, (byte) -83);
								client.aBoolean8866 = false;
							}
							for (;;) {
								Class298_Sub46 class298_sub46 = ((Class298_Sub46) client.aClass453_8660.method5936(2107909159));
								if (class298_sub46 == null) {
									if (i <= 4) {
										/* empty */
									}
									break;
								}
								IComponentDefinition class105 = class298_sub46.aClass105_7525;
								if (-1309843523 * class105.anInt1154 >= 0) {
									IComponentDefinition class105_11_ = Class50.getIComponentDefinitions((class105.anInt1160 * 1573706803), (byte) 54);
									if (class105_11_ == null || (class105_11_.aClass105Array1292 == null) || (class105.anInt1154 * -1309843523 >= (class105_11_.aClass105Array1292).length))
										continue;
									if ((class105_11_.aClass105Array1292[class105.anInt1154 * -1309843523]) != class105) {
										if (i <= 4) {
											/* empty */
										}
										continue;
									}
								}
								Class444.method5889(class298_sub46, (byte) 9);
							}
							for (;;) {
								Class298_Sub46 class298_sub46 = ((Class298_Sub46) client.aClass453_8895.method5936(2126788731));
								if (class298_sub46 == null) {
									if (i <= 4) {
										/* empty */
									}
									break;
								}
								IComponentDefinition class105 = class298_sub46.aClass105_7525;
								if (-1309843523 * class105.anInt1154 >= 0) {
									IComponentDefinition class105_12_ = Class50.getIComponentDefinitions((class105.anInt1160 * 1573706803), (byte) 80);
									if (null == class105_12_ || (class105_12_.aClass105Array1292 == null) || (class105.anInt1154 * -1309843523 >= (class105_12_.aClass105Array1292).length))
										continue;
									if ((class105_12_.aClass105Array1292[class105.anInt1154 * -1309843523]) != class105) {
										if (i <= 4) {
											/* empty */
										}
										continue;
									}
								}
								Class444.method5889(class298_sub46, (byte) 64);
							}
							for (;;) {
								Class298_Sub46 class298_sub46 = ((Class298_Sub46) client.aClass453_8893.method5936(2113415758));
								if (null == class298_sub46) {
									if (i <= 4)
										throw new IllegalStateException();
									break;
								}
								IComponentDefinition class105 = class298_sub46.aClass105_7525;
								if (class105.anInt1154 * -1309843523 >= 0) {
									IComponentDefinition class105_13_ = Class50.getIComponentDefinitions((class105.anInt1160 * 1573706803), (byte) 36);
									if (null == class105_13_ || (null == class105_13_.aClass105Array1292) || (-1309843523 * class105.anInt1154 >= (class105_13_.aClass105Array1292).length))
										continue;
									if ((class105_13_.aClass105Array1292[class105.anInt1154 * -1309843523]) != class105) {
										if (i <= 4)
											throw new IllegalStateException();
										continue;
									}
								}
								Class444.method5889(class298_sub46, (byte) -21);
							}
							if (Class113.aClass105_1373 == null)
								client.anInt8864 = 0;
							if (null != client.aClass105_8850)
								Class53.method602(-1193693208);
							if (client.playerRights * 1806357379 > 0 && Class372.aClass323_4052.method3936(82, -510265259) && Class372.aClass323_4052.method3936(81, 1722713678) && client.anInt8682 * 1170859143 != 0) {
								int i_14_ = ((Class287.myPlayer.plane) - client.anInt8682 * 1170859143);
								if (i_14_ < 0)
									i_14_ = 0;
								else if (i_14_ > 3)
									i_14_ = 3;
								Class341 class341 = client.aClass283_8716.method2628(681479919);
								Class476.method6083(i_14_, ((Class287.myPlayer.scenePositionXQueue[0]) + -1760580017 * class341.gameSceneBaseX), ((Class287.myPlayer.scenePositionYQueue[0]) + 283514611 * class341.gameSceneBaseY), 1979698840);
							}
							Graphics.method610(187981678);
							for (int i_15_ = 0; i_15_ < 5; i_15_++)
								client.anIntArray8790[i_15_]++;
							if (client.aBoolean8736 && (client.aLong8892 * -4876927317316500383L < Class122.method1319((byte) 1) - 60000L))
								Class52_Sub2.method589(1315881016);
							for (Class302_Sub2 class302_sub2 = ((Class302_Sub2) client.aClass442_8951.method5868(-16777216)); null != class302_sub2; class302_sub2 = ((Class302_Sub2) client.aClass442_8951.method5872(-1081988620))) {
								if ((long) (-1505693583 * (((Class302_Sub2) class302_sub2).anInt7647)) < (Class122.method1319((byte) 1) / 1000L - 5L)) {
									if ((((Class302_Sub2) class302_sub2).aShort7646) > 0)
										Class242_Sub1.method2282(5, 0, "", "", "", new StringBuilder().append(((Class302_Sub2) class302_sub2).aString7648).append(Tradution.aClass470_5901.method6049(Class321.aClass429_3357, -875414210)).toString(), 818502865);
									if ((((Class302_Sub2) class302_sub2).aShort7646) == 0)
										Class242_Sub1.method2282(5, 0, "", "", "", new StringBuilder().append(((Class302_Sub2) class302_sub2).aString7648).append(Tradution.aClass470_5902.method6049(Class321.aClass429_3357, -875414210)).toString(), -1731923786);
									class302_sub2.method3714(180959790);
								}
							}
							client.anInt8746 += -447320539;
							if (-1380319827 * client.anInt8746 > 506) {
								client.anInt8746 = 0;
								int i_16_ = (int) (Math.random() * 8.0);
								if ((i_16_ & 0x1) == 1)
									client.anInt8817 += client.anInt8741 * -969022135;
								if ((i_16_ & 0x2) == 2)
									client.anInt8742 += client.anInt8826 * 200330303;
								if (4 == (i_16_ & 0x4))
									client.anInt8744 += -284639445 * client.anInt8745;
							}
							if (1734240325 * client.anInt8817 < -51)
								client.anInt8741 = -57270710;
							if (client.anInt8817 * 1734240325 > 55)
								client.anInt8741 = 57270710;
							if (client.anInt8742 * 1874511679 < -62)
								client.anInt8826 = -792852734;
							if (client.anInt8742 * 1874511679 > 64)
								client.anInt8826 = 792852734;
							if (client.anInt8744 * -1419578297 < -44)
								client.anInt8745 = 901405925;
							if (client.anInt8744 * -1419578297 > 42)
								client.anInt8745 = -901405925;
							client.anInt8810 += -1075811357;
							if (1061958091 * client.anInt8810 > 505) {
								client.anInt8810 = 0;
								int i_17_ = (int) (Math.random() * 8.0);
								if ((i_17_ & 0x1) == 1)
									client.anInt8801 += -996860861 * client.anInt8878;
								if (2 == (i_17_ & 0x2))
									client.anInt8749 += -2133918149 * client.anInt8972;
							}
							if (1227356013 * client.anInt8801 < -67)
								client.anInt8878 = -640741266;
							if (1227356013 * client.anInt8801 > 67)
								client.anInt8878 = 640741266;
							if (356727603 * client.anInt8749 < -21)
								client.anInt8972 = 999313729;
							if (client.anInt8749 * 356727603 > 10)
								client.anInt8972 = -999313729;
							client.aClass25_8711.anInt339 += 1797987493;
							if (2033675053 * client.aClass25_8711.anInt339 > 50) {
								Class298_Sub36 class298_sub36 = Class18.method359((OutcommingPacket.PING_PACKET), (client.aClass25_8711.aClass449_330), (byte) 120);
								client.aClass25_8711.method390(class298_sub36, (byte) -57);
							}
							if (client.aBoolean8714) {
								Class82_Sub20.method933((byte) -12);
								client.aBoolean8714 = false;
							}
							try {
								client.aClass25_8711.method386(-1146717706);
							} catch (IOException ioexception) {
								SubIncommingPacket.method1923(1323080201);
							}
						}
					}
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fc.gu(").append(')').toString());
		}
	}

	static final void method1408(ClientScript2 class403, byte i) {
		try {
			int i_18_ = (((ClientScript2) class403).integerstack[1883543357 * ((ClientScript2) class403).integerPos]);
			Class376 class376 = Class299.aClass370_3199.method4576(i_18_, -1368678783);
			if (class376 == null)
				throw new RuntimeException();
			Integer integer = (((ClientScript2) class403).aClass162_5252.method1753(client.aClass411_8944.gameType * -937307905 << 16 | i_18_, (byte) -31));
			int i_19_;
			if (integer == null) {
				if (class376.aChar4085 == 'i' || class376.aChar4085 == '1')
					i_19_ = 0;
				else
					i_19_ = -1;
			} else
				i_19_ = integer.intValue();
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_19_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fc.bv(").append(')').toString());
		}
	}
}
