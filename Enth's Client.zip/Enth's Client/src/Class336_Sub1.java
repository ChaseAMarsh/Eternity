/* Class336_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class336_Sub1 extends Class336 {
	int anInt7711;
	Class424 aClass424_7712;

	public boolean method4090(int i, int i_0_, int i_1_, Class289 class289, int i_2_) {
		try {
			return class289.method2742(i_0_, i_1_, i, -1331662251 * toX, 1517720743 * toY, ((Class336_Sub1) this).aClass424_7712.method242(694163818), (((Class336_Sub1) this).anInt7711 * 83994365), 874579938);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acd.a(").append(')').toString());
		}
	}

	Class336_Sub1() {
		/* empty */
	}

	public boolean method4089(int i, int i_3_, int i_4_, Class289 class289) {
		return class289.method2742(i_3_, i_4_, i, -1331662251 * toX, 1517720743 * toY, ((Class336_Sub1) this).aClass424_7712.method242(694163818), ((Class336_Sub1) this).anInt7711 * 83994365, 520136743);
	}

	public boolean method4091(int i, int i_5_, int i_6_, Class289 class289) {
		return class289.method2742(i_5_, i_6_, i, -1331662251 * toX, 1517720743 * toY, ((Class336_Sub1) this).aClass424_7712.method242(694163818), ((Class336_Sub1) this).anInt7711 * 83994365, 2048707586);
	}
}
