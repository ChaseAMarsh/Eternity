/* Class123_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public final class Class123_Sub1 extends Class123 {
	Class_ra_Sub3_Sub2 aClass_ra_Sub3_Sub2_6948;
	Class110_Sub1 aClass110_Sub1_6949;
	boolean aBoolean6950;

	public boolean method1374() {
		return ((((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860) == ((Class123_Sub1) this).aClass110_Sub1_6949);
	}

	Class110 method1326(Class_ra_Sub3 class_ra_sub3, Class108 class108) {
		return new Class110_Sub1((Class_ra_Sub3_Sub2) class_ra_sub3, this, class108);
	}

	public boolean method1331(Class110 class110) {
		if (((Class123_Sub1) this).aClass110_Sub1_6949 == class110)
			return true;
		if (!class110.method1221())
			return false;
		((Class123_Sub1) this).aClass110_Sub1_6949 = (Class110_Sub1) class110;
		anInt1475 = method1329(class110, -180449856) * -1776466383;
		if (anInt1475 * -33664303 == -1)
			throw new IllegalArgumentException();
		if (((Class123_Sub1) this).aBoolean6950) {
			((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8597);
			((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8592);
			((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = ((Class123_Sub1) this).aClass110_Sub1_6949;
		}
		return true;
	}

	Class110 method1361(Class_ra_Sub3 class_ra_sub3, Class108 class108) {
		return new Class110_Sub1((Class_ra_Sub3_Sub2) class_ra_sub3, this, class108);
	}

	public void method1340() {
		if (((Class123_Sub1) this).aClass110_Sub1_6949 == null)
			throw new RuntimeException_Sub1();
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8597);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8592);
		((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = ((Class123_Sub1) this).aClass110_Sub1_6949;
		((Class123_Sub1) this).aBoolean6950 = true;
	}

	public void method1372() {
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(0L);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(0L);
		((Class123_Sub1) this).aBoolean6950 = false;
		((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = null;
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5357(1);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5358(null);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5357(0);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5358(null);
	}

	public boolean method1376(Class110 class110) {
		if (((Class123_Sub1) this).aClass110_Sub1_6949 == class110)
			return true;
		if (!class110.method1221())
			return false;
		((Class123_Sub1) this).aClass110_Sub1_6949 = (Class110_Sub1) class110;
		anInt1475 = method1329(class110, -180449856) * -1776466383;
		if (anInt1475 * -33664303 == -1)
			throw new IllegalArgumentException();
		if (((Class123_Sub1) this).aBoolean6950) {
			((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8597);
			((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8592);
			((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = ((Class123_Sub1) this).aClass110_Sub1_6949;
		}
		return true;
	}

	public void method1354() {
		if (((Class123_Sub1) this).aClass110_Sub1_6949 == null)
			throw new RuntimeException_Sub1();
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8597);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8592);
		((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = ((Class123_Sub1) this).aClass110_Sub1_6949;
		((Class123_Sub1) this).aBoolean6950 = true;
	}

	public void method1355() {
		if (((Class123_Sub1) this).aClass110_Sub1_6949 == null)
			throw new RuntimeException_Sub1();
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8597);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8592);
		((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = ((Class123_Sub1) this).aClass110_Sub1_6949;
		((Class123_Sub1) this).aBoolean6950 = true;
	}

	public boolean method1371() {
		return ((((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860) == ((Class123_Sub1) this).aClass110_Sub1_6949);
	}

	public void method1356() {
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(0L);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(0L);
		((Class123_Sub1) this).aBoolean6950 = false;
		((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = null;
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5357(1);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5358(null);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5357(0);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5358(null);
	}

	public void method1357() {
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(0L);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(0L);
		((Class123_Sub1) this).aBoolean6950 = false;
		((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = null;
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5357(1);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5358(null);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5357(0);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5358(null);
	}

	public void method1358() {
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(0L);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(0L);
		((Class123_Sub1) this).aBoolean6950 = false;
		((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = null;
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5357(1);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5358(null);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5357(0);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5358(null);
	}

	public boolean method1359() {
		return ((((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860) == ((Class123_Sub1) this).aClass110_Sub1_6949);
	}

	Class298_Sub31_Sub1 method1364(Class114 class114) {
		return new Class298_Sub31_Sub1_Sub2(this, class114);
	}

	Class123_Sub1(Class_ra_Sub3_Sub2 class_ra_sub3_sub2, Class109 class109) {
		super((Class_ra_Sub3) class_ra_sub3_sub2, class109);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948 = class_ra_sub3_sub2;
		((Class123_Sub1) this).aBoolean6950 = false;
	}

	Class110 method1362(Class_ra_Sub3 class_ra_sub3, Class108 class108) {
		return new Class110_Sub1((Class_ra_Sub3_Sub2) class_ra_sub3, this, class108);
	}

	public void method1373() {
		if (((Class123_Sub1) this).aClass110_Sub1_6949 == null)
			throw new RuntimeException_Sub1();
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8597);
		((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8592);
		((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = ((Class123_Sub1) this).aClass110_Sub1_6949;
		((Class123_Sub1) this).aBoolean6950 = true;
	}

	public boolean method1349(Class110 class110) {
		if (((Class123_Sub1) this).aClass110_Sub1_6949 == class110)
			return true;
		if (!class110.method1221())
			return false;
		((Class123_Sub1) this).aClass110_Sub1_6949 = (Class110_Sub1) class110;
		anInt1475 = method1329(class110, -180449856) * -1776466383;
		if (anInt1475 * -33664303 == -1)
			throw new IllegalArgumentException();
		if (((Class123_Sub1) this).aBoolean6950) {
			((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8597);
			((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8592);
			((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = ((Class123_Sub1) this).aClass110_Sub1_6949;
		}
		return true;
	}

	public boolean method1375(Class110 class110) {
		if (((Class123_Sub1) this).aClass110_Sub1_6949 == class110)
			return true;
		if (!class110.method1221())
			return false;
		((Class123_Sub1) this).aClass110_Sub1_6949 = (Class110_Sub1) class110;
		anInt1475 = method1329(class110, -180449856) * -1776466383;
		if (anInt1475 * -33664303 == -1)
			throw new IllegalArgumentException();
		if (((Class123_Sub1) this).aBoolean6950) {
			((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5543(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8597);
			((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948.method5566(((Class110_Sub1) ((Class123_Sub1) this).aClass110_Sub1_6949).aLong8592);
			((Class_ra_Sub3_Sub2) ((Class123_Sub1) this).aClass_ra_Sub3_Sub2_6948).aClass110_Sub1_9860 = ((Class123_Sub1) this).aClass110_Sub1_6949;
		}
		return true;
	}

	Class298_Sub31_Sub1 method1367(Class114 class114) {
		return new Class298_Sub31_Sub1_Sub2(this, class114);
	}
}
