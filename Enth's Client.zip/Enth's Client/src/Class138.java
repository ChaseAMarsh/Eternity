/* Class138 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class138 {
	public Interface9_Impl2 anInterface9_Impl2_1536;
	public Interface9_Impl2 anInterface9_Impl2_1537;
	public Interface7_Impl1 anInterface7_Impl1_1538;
	protected Class_ra_Sub3 aClass_ra_Sub3_1539;
	public Class233 aClass233_1540 = new Class233();
	public Class233 aClass233_1541 = new Class233();
	public Class233 aClass233_1542 = new Class233();
	public int anInt1543;
	public Class153 aClass153_1544;

	public abstract void method1525();

	public abstract void method1526(int i, int i_0_);

	public abstract void method1527();

	public abstract void method1528();

	public abstract void method1529(int i, int i_1_);

	public abstract void method1530(int i, int i_2_);

	public abstract void method1531();

	public abstract void method1532();

	public abstract void method1533();

	Class138(Class_ra_Sub3 class_ra_sub3) {
		aClass_ra_Sub3_1539 = class_ra_sub3;
	}

	public abstract void method1534();

	public abstract void method1535();

	public abstract void method1536();

	public abstract void method1537();

	public abstract void method1538();
}
