/* Class102 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class102 {
	public int anInt1085;
	public int anInt1086 = Class126.method1403(-2067769090) * -740789311;
	public int anInt1087;
	public String aString1088;
	public String aString1089;
	public String aString1090;
	public String aString1091;
	public int anInt1092;
	public int anInt1093;
	public String aString1094;

	void method1082(int i, int i_0_, String string, String string_1_, String string_2_, String string_3_, int i_4_, String string_5_, short i_6_) {
		try {
			anInt1086 = Class126.method1403(-2067769090) * -740789311;
			anInt1085 = -1698852737 * client.anInt8884;
			anInt1087 = i * 392659741;
			anInt1092 = i_0_ * 849125275;
			aString1088 = string;
			aString1090 = string_1_;
			aString1091 = string_2_;
			aString1089 = string_3_;
			anInt1093 = i_4_ * 1644525439;
			aString1094 = string_5_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ed.a(").append(')').toString());
		}
	}

	Class102(int i, int i_7_, String string, String string_8_, String string_9_, String string_10_, int i_11_, String string_12_) {
		anInt1085 = client.anInt8884 * -1698852737;
		anInt1087 = i * 392659741;
		anInt1092 = 849125275 * i_7_;
		aString1088 = string;
		aString1090 = string_8_;
		aString1091 = string_9_;
		aString1089 = string_10_;
		anInt1093 = i_11_ * 1644525439;
		aString1094 = string_12_;
	}

	static final void method1083(ClientScript2 class403, byte i) {
		try {
			if (Class452.aBoolean5642 && null != Class231.aFrame2589)
				Class357.method4276(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub12_7543.method5669((byte) 92), -1, -1, false, 2006169742);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ed.aej(").append(')').toString());
		}
	}

	static final void method1084(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = 1243777389 * Class360.anInt3866;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ed.ahj(").append(')').toString());
		}
	}

	static final void method1085(IComponentDefinition class105, Class119 class119, ClientScript2 class403, int i) {
		try {
			class105.anInt1173 = (((ClientScript2) class403).anIntArray5244[(((ClientScript2) class403).anInt5239 -= -391880689) * 681479919]) * -1041514725;
			Tradution.method6054(class105, -1371264268);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ed.db(").append(')').toString());
		}
	}
}
