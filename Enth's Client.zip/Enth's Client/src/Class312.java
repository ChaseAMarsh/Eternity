/* Class312 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class312 {
	int[] anIntArray3288;
	byte[] aByteArray3289;
	int anInt3290;
	byte aByte3291;
	byte aByte3292;
	byte aByte3293;
	byte aByte3294;

	Class312(int i, int i_0_, int i_1_, int i_2_, int i_3_, int[] is, byte[] is_4_) {
		((Class312) this).aByte3292 = (byte) i;
		((Class312) this).aByte3293 = (byte) i_0_;
		((Class312) this).anInt3290 = i_1_;
		((Class312) this).aByte3291 = (byte) i_2_;
		((Class312) this).aByte3294 = (byte) i_3_;
		((Class312) this).anIntArray3288 = is;
		((Class312) this).aByteArray3289 = is_4_;
	}
}
