/* Class127_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class127_Sub1 extends Class127 {
	Class57 aClass57_8569;
	Class57 aClass57_8570;
	Class57 aClass57_8571;
	Class57 aClass57_8572;
	Class57 aClass57_8573;
	Class57 aClass57_8574;

	public boolean method54() {
		if (!super.method52(-471154250))
			return false;
		Class128_Sub3 class128_sub3 = (Class128_Sub3) ((Class127_Sub1) this).aClass128_6375;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8563 * -876812375, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(1551490597 * class128_sub3.anInt8562, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(578265259 * class128_sub3.anInt8566, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8564 * 861652881, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(((class128_sub3.anInt8565) * -1259370861), -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8561 * 356687159, -457216440))
			return false;
		return true;
	}

	void method1409(boolean bool, int i, int i_0_) {
		if (bool) {
			int[] is = new int[4];
			Class373.aClass_ra4071.qa(is);
			Class373.aClass_ra4071.r(i, i_0_, (((Class127_Sub1) this).aClass128_6375.anInt6326) * -944287579 + i, (((Class127_Sub1) this).aClass128_6375.anInt6330) * -1387457793 + i_0_);
			int i_1_ = ((Class127_Sub1) this).aClass57_8571.method271();
			int i_2_ = ((Class127_Sub1) this).aClass57_8571.method626();
			int i_3_ = ((Class127_Sub1) this).aClass57_8570.method271();
			int i_4_ = ((Class127_Sub1) this).aClass57_8570.method626();
			((Class127_Sub1) this).aClass57_8571.method645(i, (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793 - i_2_) / 2 + i_0_);
			((Class127_Sub1) this).aClass57_8570.method645(i + (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579) - i_3_, (-1387457793 * ((Class127_Sub1) this).aClass128_6375.anInt6330 - i_4_) / 2 + i_0_);
			Class373.aClass_ra4071.r(i, i_0_, (-944287579 * (((Class127_Sub1) this).aClass128_6375.anInt6326) + i), i_0_ + ((Class127_Sub1) this).aClass57_8573.method626());
			((Class127_Sub1) this).aClass57_8573.method636(i_1_ + i, i_0_, (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579 - i_1_ - i_3_), (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
			int i_5_ = ((Class127_Sub1) this).aClass57_8574.method626();
			Class373.aClass_ra4071.r(i, (((Class127_Sub1) this).aClass128_6375.anInt6330) * -1387457793 + i_0_ - i_5_, i + -944287579 * (((Class127_Sub1) this).aClass128_6375.anInt6326), i_0_ + ((((Class127_Sub1) this).aClass128_6375.anInt6330) * -1387457793));
			((Class127_Sub1) this).aClass57_8574.method636(i_1_ + i, i_0_ + (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793) - i_5_, (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579 - i_1_ - i_3_), (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
			Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
		}
	}

	void method1412(boolean bool, int i, int i_6_, int i_7_) {
		try {
			if (bool) {
				int[] is = new int[4];
				Class373.aClass_ra4071.qa(is);
				Class373.aClass_ra4071.r(i, i_6_, (((Class127_Sub1) this).aClass128_6375.anInt6326) * -944287579 + i, (((Class127_Sub1) this).aClass128_6375.anInt6330) * -1387457793 + i_6_);
				int i_8_ = ((Class127_Sub1) this).aClass57_8571.method271();
				int i_9_ = ((Class127_Sub1) this).aClass57_8571.method626();
				int i_10_ = ((Class127_Sub1) this).aClass57_8570.method271();
				int i_11_ = ((Class127_Sub1) this).aClass57_8570.method626();
				((Class127_Sub1) this).aClass57_8571.method645(i, ((((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793) - i_9_) / 2 + i_6_);
				((Class127_Sub1) this).aClass57_8570.method645(i + (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579) - i_10_, ((-1387457793 * ((Class127_Sub1) this).aClass128_6375.anInt6330) - i_11_) / 2 + i_6_);
				Class373.aClass_ra4071.r(i, i_6_, -944287579 * (((Class127_Sub1) this).aClass128_6375.anInt6326) + i, i_6_ + ((Class127_Sub1) this).aClass57_8573.method626());
				((Class127_Sub1) this).aClass57_8573.method636(i_8_ + i, i_6_, (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579) - i_8_ - i_10_, (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
				int i_12_ = ((Class127_Sub1) this).aClass57_8574.method626();
				Class373.aClass_ra4071.r(i, (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793) + i_6_ - i_12_, i + (-944287579 * ((Class127_Sub1) this).aClass128_6375.anInt6326), i_6_ + (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
				((Class127_Sub1) this).aClass57_8574.method636(i_8_ + i, i_6_ + (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793) - i_12_, (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579) - i_8_ - i_10_, (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
				Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zb.x(").append(')').toString());
		}
	}

	void method1413(boolean bool, int i, int i_13_) {
		int i_14_ = i + ((Class127_Sub1) this).aClass57_8571.method271();
		int i_15_ = (-944287579 * ((Class127_Sub1) this).aClass128_6375.anInt6326 + i - ((Class127_Sub1) this).aClass57_8570.method271());
		int i_16_ = i_13_ + ((Class127_Sub1) this).aClass57_8573.method626();
		int i_17_ = (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793 + i_13_ - ((Class127_Sub1) this).aClass57_8574.method626());
		int i_18_ = i_15_ - i_14_;
		int i_19_ = i_17_ - i_16_;
		int i_20_ = method1418(652896143) * i_18_ / 10000;
		int[] is = new int[4];
		Class373.aClass_ra4071.qa(is);
		Class373.aClass_ra4071.r(i_14_, i_16_, i_14_ + i_20_, i_17_);
		method1424(i_14_, i_16_, i_18_, i_19_, 1789961003);
		Class373.aClass_ra4071.r(i_20_ + i_14_, i_16_, i_15_, i_17_);
		((Class127_Sub1) this).aClass57_8569.method636(i_14_, i_16_, i_18_, i_19_);
		Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
	}

	void method1424(int i, int i_21_, int i_22_, int i_23_, int i_24_) {
		try {
			((Class127_Sub1) this).aClass57_8572.method636(i, i_21_, i_22_, i_23_);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zb.c(").append(')').toString());
		}
	}

	public boolean method52(int i) {
		try {
			if (!super.method52(-571978774))
				return false;
			Class128_Sub3 class128_sub3 = (Class128_Sub3) ((Class127_Sub1) this).aClass128_6375;
			if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8563 * -876812375, -457216440))
				return false;
			if (!((Class127_Sub1) this).aClass243_6372.method2310(1551490597 * class128_sub3.anInt8562, -457216440))
				return false;
			if (!((Class127_Sub1) this).aClass243_6372.method2310(578265259 * class128_sub3.anInt8566, -457216440))
				return false;
			if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8564 * 861652881, -457216440))
				return false;
			if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8565 * -1259370861, -457216440))
				return false;
			if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8561 * 356687159, -457216440))
				return false;
			return true;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zb.b(").append(')').toString());
		}
	}

	public void method55() {
		super.method53(-1049861204);
		Class128_Sub3 class128_sub3 = (Class128_Sub3) ((Class127_Sub1) this).aClass128_6375;
		((Class127_Sub1) this).aClass57_8572 = Class422_Sub10.method5663(((Class127_Sub1) this).aClass243_6372, class128_sub3.anInt8563 * -876812375, (byte) -20);
		((Class127_Sub1) this).aClass57_8569 = Class422_Sub10.method5663(((Class127_Sub1) this).aClass243_6372, class128_sub3.anInt8562 * 1551490597, (byte) -36);
		((Class127_Sub1) this).aClass57_8571 = Class422_Sub10.method5663(((Class127_Sub1) this).aClass243_6372, 578265259 * class128_sub3.anInt8566, (byte) -107);
		((Class127_Sub1) this).aClass57_8570 = Class422_Sub10.method5663(((Class127_Sub1) this).aClass243_6372, 861652881 * class128_sub3.anInt8564, (byte) -11);
		((Class127_Sub1) this).aClass57_8573 = Class422_Sub10.method5663(((Class127_Sub1) this).aClass243_6372, -1259370861 * class128_sub3.anInt8565, (byte) -42);
		((Class127_Sub1) this).aClass57_8574 = Class422_Sub10.method5663(((Class127_Sub1) this).aClass243_6372, 356687159 * class128_sub3.anInt8561, (byte) -75);
	}

	public boolean method57() {
		if (!super.method52(-1053320809))
			return false;
		Class128_Sub3 class128_sub3 = (Class128_Sub3) ((Class127_Sub1) this).aClass128_6375;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8563 * -876812375, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(1551490597 * class128_sub3.anInt8562, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(578265259 * class128_sub3.anInt8566, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8564 * 861652881, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(((class128_sub3.anInt8565) * -1259370861), -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8561 * 356687159, -457216440))
			return false;
		return true;
	}

	public boolean method59() {
		if (!super.method52(-1356653583))
			return false;
		Class128_Sub3 class128_sub3 = (Class128_Sub3) ((Class127_Sub1) this).aClass128_6375;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8563 * -876812375, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(1551490597 * class128_sub3.anInt8562, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(578265259 * class128_sub3.anInt8566, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8564 * 861652881, -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(((class128_sub3.anInt8565) * -1259370861), -457216440))
			return false;
		if (!((Class127_Sub1) this).aClass243_6372.method2310(class128_sub3.anInt8561 * 356687159, -457216440))
			return false;
		return true;
	}

	void method1417(boolean bool, int i, int i_25_) {
		if (bool) {
			int[] is = new int[4];
			Class373.aClass_ra4071.qa(is);
			Class373.aClass_ra4071.r(i, i_25_, (((Class127_Sub1) this).aClass128_6375.anInt6326) * -944287579 + i, (((Class127_Sub1) this).aClass128_6375.anInt6330) * -1387457793 + i_25_);
			int i_26_ = ((Class127_Sub1) this).aClass57_8571.method271();
			int i_27_ = ((Class127_Sub1) this).aClass57_8571.method626();
			int i_28_ = ((Class127_Sub1) this).aClass57_8570.method271();
			int i_29_ = ((Class127_Sub1) this).aClass57_8570.method626();
			((Class127_Sub1) this).aClass57_8571.method645(i, (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793 - i_27_) / 2 + i_25_);
			((Class127_Sub1) this).aClass57_8570.method645(i + (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579) - i_28_, (-1387457793 * ((Class127_Sub1) this).aClass128_6375.anInt6330 - i_29_) / 2 + i_25_);
			Class373.aClass_ra4071.r(i, i_25_, (-944287579 * (((Class127_Sub1) this).aClass128_6375.anInt6326) + i), i_25_ + ((Class127_Sub1) this).aClass57_8573.method626());
			((Class127_Sub1) this).aClass57_8573.method636(i_26_ + i, i_25_, (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579 - i_26_ - i_28_), (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
			int i_30_ = ((Class127_Sub1) this).aClass57_8574.method626();
			Class373.aClass_ra4071.r(i, (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793 + i_25_ - i_30_), i + (-944287579 * ((Class127_Sub1) this).aClass128_6375.anInt6326), i_25_ + (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
			((Class127_Sub1) this).aClass57_8574.method636(i_26_ + i, i_25_ + (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793) - i_30_, (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579 - i_26_ - i_28_), (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
			Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
		}
	}

	void method1411(boolean bool, int i, int i_31_, int i_32_) {
		try {
			int i_33_ = i + ((Class127_Sub1) this).aClass57_8571.method271();
			int i_34_ = (-944287579 * ((Class127_Sub1) this).aClass128_6375.anInt6326 + i - ((Class127_Sub1) this).aClass57_8570.method271());
			int i_35_ = i_31_ + ((Class127_Sub1) this).aClass57_8573.method626();
			int i_36_ = ((((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793) + i_31_ - ((Class127_Sub1) this).aClass57_8574.method626());
			int i_37_ = i_34_ - i_33_;
			int i_38_ = i_36_ - i_35_;
			int i_39_ = method1418(1969642247) * i_37_ / 10000;
			int[] is = new int[4];
			Class373.aClass_ra4071.qa(is);
			Class373.aClass_ra4071.r(i_33_, i_35_, i_33_ + i_39_, i_36_);
			method1424(i_33_, i_35_, i_37_, i_38_, -1231781770);
			Class373.aClass_ra4071.r(i_39_ + i_33_, i_35_, i_34_, i_36_);
			((Class127_Sub1) this).aClass57_8569.method636(i_33_, i_35_, i_37_, i_38_);
			Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zb.r(").append(')').toString());
		}
	}

	void method1414(boolean bool, int i, int i_40_) {
		int i_41_ = i + ((Class127_Sub1) this).aClass57_8571.method271();
		int i_42_ = (-944287579 * ((Class127_Sub1) this).aClass128_6375.anInt6326 + i - ((Class127_Sub1) this).aClass57_8570.method271());
		int i_43_ = i_40_ + ((Class127_Sub1) this).aClass57_8573.method626();
		int i_44_ = (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793 + i_40_ - ((Class127_Sub1) this).aClass57_8574.method626());
		int i_45_ = i_42_ - i_41_;
		int i_46_ = i_44_ - i_43_;
		int i_47_ = method1418(-573228636) * i_45_ / 10000;
		int[] is = new int[4];
		Class373.aClass_ra4071.qa(is);
		Class373.aClass_ra4071.r(i_41_, i_43_, i_41_ + i_47_, i_44_);
		method1424(i_41_, i_43_, i_45_, i_46_, -672953345);
		Class373.aClass_ra4071.r(i_47_ + i_41_, i_43_, i_42_, i_44_);
		((Class127_Sub1) this).aClass57_8569.method636(i_41_, i_43_, i_45_, i_46_);
		Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
	}

	void method1415(boolean bool, int i, int i_48_) {
		int i_49_ = i + ((Class127_Sub1) this).aClass57_8571.method271();
		int i_50_ = (-944287579 * ((Class127_Sub1) this).aClass128_6375.anInt6326 + i - ((Class127_Sub1) this).aClass57_8570.method271());
		int i_51_ = i_48_ + ((Class127_Sub1) this).aClass57_8573.method626();
		int i_52_ = (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793 + i_48_ - ((Class127_Sub1) this).aClass57_8574.method626());
		int i_53_ = i_50_ - i_49_;
		int i_54_ = i_52_ - i_51_;
		int i_55_ = method1418(898782840) * i_53_ / 10000;
		int[] is = new int[4];
		Class373.aClass_ra4071.qa(is);
		Class373.aClass_ra4071.r(i_49_, i_51_, i_49_ + i_55_, i_52_);
		method1424(i_49_, i_51_, i_53_, i_54_, 2053935529);
		Class373.aClass_ra4071.r(i_55_ + i_49_, i_51_, i_50_, i_52_);
		((Class127_Sub1) this).aClass57_8569.method636(i_49_, i_51_, i_53_, i_54_);
		Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
	}

	void method1416(boolean bool, int i, int i_56_) {
		int i_57_ = i + ((Class127_Sub1) this).aClass57_8571.method271();
		int i_58_ = (-944287579 * ((Class127_Sub1) this).aClass128_6375.anInt6326 + i - ((Class127_Sub1) this).aClass57_8570.method271());
		int i_59_ = i_56_ + ((Class127_Sub1) this).aClass57_8573.method626();
		int i_60_ = (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793 + i_56_ - ((Class127_Sub1) this).aClass57_8574.method626());
		int i_61_ = i_58_ - i_57_;
		int i_62_ = i_60_ - i_59_;
		int i_63_ = method1418(2121135602) * i_61_ / 10000;
		int[] is = new int[4];
		Class373.aClass_ra4071.qa(is);
		Class373.aClass_ra4071.r(i_57_, i_59_, i_57_ + i_63_, i_60_);
		method1424(i_57_, i_59_, i_61_, i_62_, 1166821857);
		Class373.aClass_ra4071.r(i_63_ + i_57_, i_59_, i_58_, i_60_);
		((Class127_Sub1) this).aClass57_8569.method636(i_57_, i_59_, i_61_, i_62_);
		Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
	}

	void method1410(boolean bool, int i, int i_64_) {
		if (bool) {
			int[] is = new int[4];
			Class373.aClass_ra4071.qa(is);
			Class373.aClass_ra4071.r(i, i_64_, (((Class127_Sub1) this).aClass128_6375.anInt6326) * -944287579 + i, (((Class127_Sub1) this).aClass128_6375.anInt6330) * -1387457793 + i_64_);
			int i_65_ = ((Class127_Sub1) this).aClass57_8571.method271();
			int i_66_ = ((Class127_Sub1) this).aClass57_8571.method626();
			int i_67_ = ((Class127_Sub1) this).aClass57_8570.method271();
			int i_68_ = ((Class127_Sub1) this).aClass57_8570.method626();
			((Class127_Sub1) this).aClass57_8571.method645(i, (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793 - i_66_) / 2 + i_64_);
			((Class127_Sub1) this).aClass57_8570.method645(i + (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579) - i_67_, (-1387457793 * ((Class127_Sub1) this).aClass128_6375.anInt6330 - i_68_) / 2 + i_64_);
			Class373.aClass_ra4071.r(i, i_64_, (-944287579 * (((Class127_Sub1) this).aClass128_6375.anInt6326) + i), i_64_ + ((Class127_Sub1) this).aClass57_8573.method626());
			((Class127_Sub1) this).aClass57_8573.method636(i_65_ + i, i_64_, (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579 - i_65_ - i_67_), (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
			int i_69_ = ((Class127_Sub1) this).aClass57_8574.method626();
			Class373.aClass_ra4071.r(i, (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793 + i_64_ - i_69_), i + (-944287579 * ((Class127_Sub1) this).aClass128_6375.anInt6326), i_64_ + (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
			((Class127_Sub1) this).aClass57_8574.method636(i_65_ + i, i_64_ + (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793) - i_69_, (((Class127_Sub1) this).aClass128_6375.anInt6326 * -944287579 - i_65_ - i_67_), (((Class127_Sub1) this).aClass128_6375.anInt6330 * -1387457793));
			Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
		}
	}

	Class127_Sub1(CacheIndex class243, CacheIndex class243_70_, Class128_Sub3 class128_sub3) {
		super(class243, class243_70_, (Class128) class128_sub3);
	}

	public void method53(int i) {
		try {
			super.method53(215816169);
			Class128_Sub3 class128_sub3 = (Class128_Sub3) ((Class127_Sub1) this).aClass128_6375;
			((Class127_Sub1) this).aClass57_8572 = Class422_Sub10.method5663((((Class127_Sub1) this).aClass243_6372), (class128_sub3.anInt8563 * -876812375), (byte) 53);
			((Class127_Sub1) this).aClass57_8569 = Class422_Sub10.method5663((((Class127_Sub1) this).aClass243_6372), (class128_sub3.anInt8562 * 1551490597), (byte) -54);
			((Class127_Sub1) this).aClass57_8571 = Class422_Sub10.method5663((((Class127_Sub1) this).aClass243_6372), (578265259 * class128_sub3.anInt8566), (byte) -41);
			((Class127_Sub1) this).aClass57_8570 = Class422_Sub10.method5663((((Class127_Sub1) this).aClass243_6372), (861652881 * class128_sub3.anInt8564), (byte) -125);
			((Class127_Sub1) this).aClass57_8573 = Class422_Sub10.method5663((((Class127_Sub1) this).aClass243_6372), (-1259370861 * class128_sub3.anInt8565), (byte) 95);
			((Class127_Sub1) this).aClass57_8574 = Class422_Sub10.method5663((((Class127_Sub1) this).aClass243_6372), (356687159 * class128_sub3.anInt8561), (byte) -11);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zb.a(").append(')').toString());
		}
	}

	static int method1425(Class298_Sub37_Sub15 class298_sub37_sub15, Class505 class505, int i) {
		try {
			String string = Class8.method315(class298_sub37_sub15, 2106133220);
			int[] is = Class313.method3821(class298_sub37_sub15, (byte) -16);
			if (null != is)
				string = new StringBuilder().append(string).append(Class216.method1999(is, (byte) 1)).toString();
			int i_71_ = class505.method6254(string, Class436.aClass57Array5501, 1319235613);
			if (((Class298_Sub37_Sub15) class298_sub37_sub15).aBoolean9665)
				i_71_ += Graphics.aClass57_573.method623() + 4;
			return i_71_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zb.bm(").append(')').toString());
		}
	}

	public static String huffManDecryption(RsByteBuffer class298_sub53, int i) {
		try {
			return Class436.method5808(class298_sub53, 32767, 116620582);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zb.b(").append(')').toString());
		}
	}

	static void method1427(int i) {
		try {
			Class301_Sub1.aClass437_7636.method5811((byte) -14);
			Class301_Sub1.aClass437_7637.method5811((byte) -2);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zb.bp(").append(')').toString());
		}
	}

	static final void method1428(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_72_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239]);
			int i_73_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239 + 1]);
			Class113.method1254(i_72_, new Interface(i_73_, 3), null, true, -1040917955);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zb.sp(").append(')').toString());
		}
	}
}
