/* Class298_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub2 extends Class298 {
	static Class395 aClass395_7165;
	public Class453 aClass453_7166 = new Class453();
	static Class298_Sub19_Sub1 aClass298_Sub19_Sub1_7167;

	Class298_Sub2() {
		/* empty */
	}

	static final void method2847(int i, int i_0_, int i_1_, int i_2_, byte i_3_) {
		try {
			if (i - i_1_ >= Class372_Sub1.anInt4051 * -1424479739 && i_1_ + i <= Class372_Sub1.anInt4048 * 1135094847 && i_0_ - i_1_ >= Class372_Sub1.anInt4049 * 1155384281 && i_0_ + i_1_ <= Class372_Sub1.anInt4050 * -1062447355)
				Class433.method5797(i, i_0_, i_1_, i_2_, -586727793);
			else
				Class308.method3782(i, i_0_, i_1_, i_2_, 179222192);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aad.x(").append(')').toString());
		}
	}

	static final void method2848(ClientScript2 class403, int i) {
		try {
			Class390 class390 = (((ClientScript2) class403).aBoolean5261 ? ((ClientScript2) class403).aClass390_5247 : ((ClientScript2) class403).aClass390_5246);
			IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
			Class119 class119 = ((Class390) class390).aClass119_4167;
			Class194.method1870(class105, class119, class403, (byte) -5);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aad.jo(").append(')').toString());
		}
	}

	static final void method2849(ClientScript2 class403, int i) {
		try {
			int i_4_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_4_, (byte) -113);
			Class119 class119 = Class389.aClass119Array4165[i_4_ >> 16];
			Class249.method2393(class105, class119, class403, 131231409);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aad.ij(").append(')').toString());
		}
	}

	static final void method2850(ClientScript2 class403, int i) {
		try {
			int i_5_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			((ClientScript2) class403).anObjectArray5240[((((ClientScript2) class403).anInt5241 += 969361751) * -203050393 - 1)] = Integer.toString(i_5_);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aad.ze(").append(')').toString());
		}
	}
}
