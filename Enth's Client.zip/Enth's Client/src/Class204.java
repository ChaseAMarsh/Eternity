/* Class204 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Canvas;

public class Class204 {
	public static GraphicsToolkit method1911(Canvas canvas, Interface_ma interface_ma, CacheIndex class243, int i) {
		GraphicsToolkit class_ra;
		try {
			boolean bool = Class_ra_Sub3.method5421();
			if (!bool)
				throw new RuntimeException("");
			if (!Class85.method955(-739351876).method265("jagdx", 65483240))
				throw new RuntimeException("");
			class_ra = Class_ra_Sub3_Sub2.method5545(canvas, interface_ma, class243, Integer.valueOf(i));
		} catch (RuntimeException runtimeexception) {
			throw runtimeexception;
		} catch (Throwable throwable) {
			throw new RuntimeException("");
		}
		return class_ra;
	}

	public static GraphicsToolkit method1912(Canvas canvas, Interface_ma interface_ma, CacheIndex class243, int i) {
		GraphicsToolkit class_ra;
		try {
			boolean bool = Class_ra_Sub3.method5421();
			if (!bool)
				throw new RuntimeException("");
			if (!Class85.method955(-765516167).method265("jagdx", -1570923611))
				throw new RuntimeException("");
			class_ra = Class_ra_Sub3_Sub2.method5545(canvas, interface_ma, class243, Integer.valueOf(i));
		} catch (RuntimeException runtimeexception) {
			throw runtimeexception;
		} catch (Throwable throwable) {
			throw new RuntimeException("");
		}
		return class_ra;
	}

	Class204() throws Throwable {
		throw new Error();
	}

	public static GraphicsToolkit method1913(Canvas canvas, Interface_ma interface_ma, CacheIndex class243, int i) {
		GraphicsToolkit class_ra;
		try {
			boolean bool = Class_ra_Sub3.method5421();
			if (!bool)
				throw new RuntimeException("");
			if (!Class85.method955(1227056345).method265("jagdx", 1326863059))
				throw new RuntimeException("");
			class_ra = Class_ra_Sub3_Sub2.method5545(canvas, interface_ma, class243, Integer.valueOf(i));
		} catch (RuntimeException runtimeexception) {
			throw runtimeexception;
		} catch (Throwable throwable) {
			throw new RuntimeException("");
		}
		return class_ra;
	}
}
