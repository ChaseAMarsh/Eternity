/* Class172 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class172 {
	public static int anInt1746 = 0;
	public static int anInt1747 = 1;

	Class172() throws Throwable {
		throw new Error();
	}
}
