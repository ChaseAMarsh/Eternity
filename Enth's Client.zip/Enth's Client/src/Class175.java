/* Class175 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class175 {
	public static Class175 aClass175_1765;
	public int anInt1766;
	public static Class175 aClass175_1767;
	public static Class175 aClass175_1768;
	public static Class175 aClass175_1769;
	public static Class175 aClass175_1770 = new Class175(3);

	Class175(int i) {
		anInt1766 = i;
	}

	static {
		aClass175_1765 = new Class175(1);
		aClass175_1767 = new Class175(4);
		aClass175_1768 = new Class175(2);
		aClass175_1769 = new Class175(0);
	}
}
