/* Class298_Sub19_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub19_Sub1 extends Class298_Sub19 {
	Class298_Sub11[][] aClass298_Sub11ArrayArray9206;
	int anInt9207 = 1291273984;
	int anInt9208 = -1846438656;
	Class298_Sub13 aClass298_Sub13_9209;
	static int anInt9210 = 4;
	int[] anIntArray9211;
	int[] anIntArray9212;
	int[] anIntArray9213;
	int[] anIntArray9214;
	Class298_Sub19_Sub5 aClass298_Sub19_Sub5_9215;
	int[] anIntArray9216;
	boolean aBoolean9217;
	int[] anIntArray9218;
	int[] anIntArray9219;
	static int anInt9220 = 1;
	static int anInt9221 = 2;
	Class440 aClass440_9222;
	int anInt9223 = 585921344;
	int[] anIntArray9224;
	int[] anIntArray9225;
	int[] anIntArray9226;
	int[] anIntArray9227;
	int[] anIntArray9228;
	int anInt9229;
	Class298_Sub11[][] aClass298_Sub11ArrayArray9230;
	Class103 aClass103_9231;
	int[] anIntArray9232;
	int anInt9233;
	int[] anIntArray9234;
	long aLong9235;
	long aLong9236;
	boolean aBoolean9237;
	int[] anIntArray9238;
	int anInt9239;
	int[] anIntArray9240;

	void method2951(int i, int i_0_) {
		try {
			if (i < 0) {
				for (i = 0; i < 16; i++)
					method2951(i, -1250334263);
			} else {
				((Class298_Sub19_Sub1) this).anIntArray9211[i] = 12800;
				((Class298_Sub19_Sub1) this).anIntArray9212[i] = 8192;
				((Class298_Sub19_Sub1) this).anIntArray9213[i] = 16383;
				((Class298_Sub19_Sub1) this).anIntArray9232[i] = 8192;
				((Class298_Sub19_Sub1) this).anIntArray9218[i] = 0;
				((Class298_Sub19_Sub1) this).anIntArray9219[i] = 8192;
				method2973(i, 537893417);
				method2974(i, (byte) 0);
				((Class298_Sub19_Sub1) this).anIntArray9224[i] = 0;
				((Class298_Sub19_Sub1) this).anIntArray9234[i] = 32767;
				((Class298_Sub19_Sub1) this).anIntArray9225[i] = 256;
				((Class298_Sub19_Sub1) this).anIntArray9226[i] = 0;
				method2976(i, 8192, 2043925478);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.by(").append(')').toString());
		}
	}

	synchronized void method2952(Class298_Sub13 class298_sub13, boolean bool, boolean bool_1_, int i) {
		try {
			method2960(bool_1_, -310606613);
			((Class298_Sub19_Sub1) this).aClass103_9231.method1086(((Class298_Sub13) class298_sub13).aByteArray7258);
			((Class298_Sub19_Sub1) this).aBoolean9217 = bool;
			((Class298_Sub19_Sub1) this).aLong9235 = 0L;
			int i_2_ = ((Class298_Sub19_Sub1) this).aClass103_9231.method1088();
			for (int i_3_ = 0; i_3_ < i_2_; i_3_++) {
				((Class298_Sub19_Sub1) this).aClass103_9231.method1089(i_3_);
				((Class298_Sub19_Sub1) this).aClass103_9231.method1091(i_3_);
				((Class298_Sub19_Sub1) this).aClass103_9231.method1098(i_3_);
			}
			((Class298_Sub19_Sub1) this).anInt9233 = (((Class298_Sub19_Sub1) this).aClass103_9231.method1096() * 1034491793);
			((Class298_Sub19_Sub1) this).anInt9229 = ((((Class103) ((Class298_Sub19_Sub1) this).aClass103_9231).anIntArray1105[((Class298_Sub19_Sub1) this).anInt9233 * -1094678159]) * -1484027731);
			((Class298_Sub19_Sub1) this).aLong9236 = ((((Class298_Sub19_Sub1) this).aClass103_9231.method1095(((Class298_Sub19_Sub1) this).anInt9229 * -847832283)) * -5395595849438982007L);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.af(").append(')').toString());
		}
	}

	int method2953(byte i) {
		try {
			return ((Class298_Sub19_Sub1) this).anInt9207 * -207519113;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.at(").append(')').toString());
		}
	}

	synchronized void method2954(int i, int i_4_, int i_5_) {
		try {
			if (i < 0) {
				for (int i_6_ = 0; i_6_ < 16; i_6_++)
					((Class298_Sub19_Sub1) this).anIntArray9240[i_6_] = i_4_;
			} else
				((Class298_Sub19_Sub1) this).anIntArray9240[i] = i_4_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.ai(").append(')').toString());
		}
	}

	synchronized boolean method2955(Class298_Sub13 class298_sub13, CacheIndex class243, Class272 class272, int i, int i_7_) {
		try {
			class298_sub13.method2904();
			boolean bool = true;
			int[] is = null;
			if (i > 0)
				is = new int[] { i };
			for (Class298_Sub28 class298_sub28 = (Class298_Sub28) ((Class298_Sub13) class298_sub13).aClass440_7259.method5856(-1972132134); null != class298_sub28; class298_sub28 = (Class298_Sub28) ((Class298_Sub13) class298_sub13).aClass440_7259.method5857((byte) -88)) {
				int i_8_ = (int) (7051297995265073167L * class298_sub28.aLong3188);
				Class298_Sub34 class298_sub34 = ((Class298_Sub34) ((Class298_Sub19_Sub1) this).aClass440_9222.method5852((long) i_8_));
				if (class298_sub34 == null) {
					class298_sub34 = Class98_Sub2.method1060(class243, i_8_, -1675121341);
					if (null == class298_sub34) {
						bool = false;
						continue;
					}
					((Class298_Sub19_Sub1) this).aClass440_9222.method5858(class298_sub34, (long) i_8_);
				}
				if (!class298_sub34.method3397(class272, class298_sub28.aByteArray7365, is, 2068929620))
					bool = false;
			}
			if (bool)
				class298_sub13.method2906();
			return bool;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.al(").append(')').toString());
		}
	}

	synchronized void method2956(int i) {
		try {
			for (Class298_Sub34 class298_sub34 = (Class298_Sub34) ((Class298_Sub19_Sub1) this).aClass440_9222.method5856(-2020964435); class298_sub34 != null; class298_sub34 = (Class298_Sub34) ((Class298_Sub19_Sub1) this).aClass440_9222.method5857((byte) -107))
				class298_sub34.method3398((byte) 1);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.az(").append(')').toString());
		}
	}

	synchronized void method2957(byte i) {
		try {
			for (Class298_Sub34 class298_sub34 = (Class298_Sub34) ((Class298_Sub19_Sub1) this).aClass440_9222.method5856(-1054359069); class298_sub34 != null; class298_sub34 = (Class298_Sub34) ((Class298_Sub19_Sub1) this).aClass440_9222.method5857((byte) -24))
				class298_sub34.method2839(-1460969981);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.as(").append(')').toString());
		}
	}

	synchronized void method2958(Class298_Sub13 class298_sub13, boolean bool, byte i) {
		try {
			method2952(class298_sub13, bool, true, 752002788);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.ap(").append(')').toString());
		}
	}

	synchronized void method2948(int i) {
		if (((Class298_Sub19_Sub1) this).aClass103_9231.method1099()) {
			int i_9_ = ((((Class103) ((Class298_Sub19_Sub1) this).aClass103_9231).anInt1096) * (1957555245 * ((Class298_Sub19_Sub1) this).anInt9223) / (1164070869 * Class284.anInt3059));
			do {
				long l = ((5242905950797426295L * ((Class298_Sub19_Sub1) this).aLong9235) + (long) i * (long) i_9_);
				if ((((Class298_Sub19_Sub1) this).aLong9236 * 56522420256794041L) - l >= 0L) {
					((Class298_Sub19_Sub1) this).aLong9235 = 9035186418716527431L * l;
					break;
				}
				int i_10_ = (int) (((long) i_9_ + ((56522420256794041L * ((Class298_Sub19_Sub1) this).aLong9236) - (((Class298_Sub19_Sub1) this).aLong9235 * 5242905950797426295L)) - 1L) / (long) i_9_);
				((Class298_Sub19_Sub1) this).aLong9235 += 9035186418716527431L * ((long) i_9_ * (long) i_10_);
				((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2935(i_10_);
				i -= i_10_;
				method2978((byte) -80);
			} while (((Class298_Sub19_Sub1) this).aClass103_9231.method1099());
		}
		((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2935(i);
	}

	synchronized void method2959(byte i) {
		try {
			method2960(true, -310606613);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.ab(").append(')').toString());
		}
	}

	synchronized void method2960(boolean bool, int i) {
		try {
			((Class298_Sub19_Sub1) this).aClass103_9231.method1087();
			((Class298_Sub19_Sub1) this).aClass298_Sub13_9209 = null;
			method2972(bool, 1199726462);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.aj(").append(')').toString());
		}
	}

	synchronized void method2961(int i, int i_11_) {
		try {
			((Class298_Sub19_Sub1) this).anInt9207 = -1840449721 * i;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.av(").append(')').toString());
		}
	}

	public synchronized void method2962(int i, int i_12_, int i_13_) {
		try {
			method2963(i, i_12_, (byte) 122);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.aq(").append(')').toString());
		}
	}

	void method2963(int i, int i_14_, byte i_15_) {
		try {
			((Class298_Sub19_Sub1) this).anIntArray9214[i] = i_14_;
			((Class298_Sub19_Sub1) this).anIntArray9216[i] = i_14_ & ~0x7f;
			method2964(i, i_14_, (byte) 21);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.ag(").append(')').toString());
		}
	}

	void method2964(int i, int i_16_, byte i_17_) {
		try {
			if (i_16_ != ((Class298_Sub19_Sub1) this).anIntArray9238[i]) {
				((Class298_Sub19_Sub1) this).anIntArray9238[i] = i_16_;
				for (int i_18_ = 0; i_18_ < 128; i_18_++)
					((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230[i][i_18_] = null;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.an(").append(')').toString());
		}
	}

	void method2965(int i, int i_19_, int i_20_, int i_21_) {
		try {
			method2967(i, i_19_, 64, (byte) 1);
			if (0 != (((Class298_Sub19_Sub1) this).anIntArray9224[i] & 0x2)) {
				for (Class298_Sub11 class298_sub11 = (Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5964(-138512601); null != class298_sub11; class298_sub11 = (Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5966((byte) -23)) {
					if ((((Class298_Sub11) class298_sub11).anInt7254 * 70539643 == i) && (((Class298_Sub11) class298_sub11).anInt7248 * 1595133323) < 0) {
						((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206[i][(1458878633 * ((Class298_Sub11) class298_sub11).anInt7239)] = null;
						((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206[i][i_19_] = class298_sub11;
						int i_22_ = (((((Class298_Sub11) class298_sub11).anInt7243 * 397264215 * (1520725153 * (((Class298_Sub11) class298_sub11).anInt7234))) >> 12) + -1263376917 * ((Class298_Sub11) class298_sub11).anInt7242);
						((Class298_Sub11) class298_sub11).anInt7242 += (-1943561533 * (i_19_ - (((Class298_Sub11) class298_sub11).anInt7239) * 1458878633 << 8));
						((Class298_Sub11) class298_sub11).anInt7243 = -240322969 * (i_22_ - -1263376917 * (((Class298_Sub11) class298_sub11).anInt7242));
						((Class298_Sub11) class298_sub11).anInt7234 = 1198919680;
						((Class298_Sub11) class298_sub11).anInt7239 = i_19_ * -1468568679;
						return;
					}
				}
			}
			Class298_Sub34 class298_sub34 = ((Class298_Sub34) (((Class298_Sub19_Sub1) this).aClass440_9222.method5852((long) ((Class298_Sub19_Sub1) this).anIntArray9238[i])));
			if (class298_sub34 != null) {
				Class298_Sub26_Sub1 class298_sub26_sub1 = (((Class298_Sub34) class298_sub34).aClass298_Sub26_Sub1Array7387[i_19_]);
				if (class298_sub26_sub1 != null) {
					Class298_Sub11 class298_sub11 = new Class298_Sub11();
					((Class298_Sub11) class298_sub11).anInt7254 = i * -1979736653;
					((Class298_Sub11) class298_sub11).aClass298_Sub34_7249 = class298_sub34;
					((Class298_Sub11) class298_sub11).aClass298_Sub26_Sub1_7236 = class298_sub26_sub1;
					((Class298_Sub11) class298_sub11).aClass104_7246 = (((Class298_Sub34) class298_sub34).aClass104Array7391[i_19_]);
					((Class298_Sub11) class298_sub11).anInt7235 = -849737373 * (((Class298_Sub34) class298_sub34).aByteArray7386[i_19_]);
					((Class298_Sub11) class298_sub11).anInt7239 = i_19_ * -1468568679;
					((Class298_Sub11) class298_sub11).anInt7240 = (1024 + ((((Class298_Sub34) class298_sub34).aByteArray7388[i_19_]) * (i_20_ * i_20_ * ((((Class298_Sub34) class298_sub34).anInt7389) * -467589035))) >> 11) * 1149692649;
					((Class298_Sub11) class298_sub11).anInt7241 = ((((Class298_Sub34) class298_sub34).aByteArray7392[i_19_]) & 0xff) * -460356399;
					((Class298_Sub11) class298_sub11).anInt7242 = -1943561533 * ((i_19_ << 8) - ((((Class298_Sub34) class298_sub34).aShortArray7390[i_19_]) & 0x7fff));
					((Class298_Sub11) class298_sub11).anInt7245 = 0;
					((Class298_Sub11) class298_sub11).anInt7238 = 0;
					((Class298_Sub11) class298_sub11).anInt7247 = 0;
					((Class298_Sub11) class298_sub11).anInt7248 = -984183331;
					((Class298_Sub11) class298_sub11).anInt7244 = 0;
					if (0 == ((Class298_Sub19_Sub1) this).anIntArray9226[i])
						((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252 = (Class298_Sub19_Sub2.method3027(class298_sub26_sub1, method2984(class298_sub11, (byte) -68), method2982(class298_sub11, 1560432059), method2977(class298_sub11, -1934295725)));
					else {
						((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252 = (Class298_Sub19_Sub2.method3027(class298_sub26_sub1, method2984(class298_sub11, (byte) -65), 0, method2977(class298_sub11, -1934295725)));
						method2966(class298_sub11, (((Class298_Sub34) class298_sub34).aShortArray7390[i_19_]) < 0, (byte) 1);
					}
					if ((((Class298_Sub34) class298_sub34).aShortArray7390[i_19_]) < 0)
						((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method2991(-1);
					if (((Class298_Sub11) class298_sub11).anInt7235 * 279429195 >= 0) {
						Class298_Sub11 class298_sub11_23_ = (((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230[i][279429195 * (((Class298_Sub11) class298_sub11).anInt7235)]);
						if (null != class298_sub11_23_ && (((Class298_Sub11) class298_sub11_23_).anInt7248 * 1595133323) < 0) {
							((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206[i][(((Class298_Sub11) class298_sub11_23_).anInt7239) * 1458878633] = null;
							((Class298_Sub11) class298_sub11_23_).anInt7248 = 0;
						}
						((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230[i][(((Class298_Sub11) class298_sub11).anInt7235 * 279429195)] = class298_sub11;
					}
					((Class298_Sub19_Sub5) ((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215).aClass458_9271.method5968(class298_sub11, 1099032834);
					((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206[i][i_19_] = class298_sub11;
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.au(").append(')').toString());
		}
	}

	void method2966(Class298_Sub11 class298_sub11, boolean bool, byte i) {
		try {
			int i_24_ = (((Class298_Sub11) class298_sub11).aClass298_Sub26_Sub1_7236.aByteArray9309).length;
			int i_25_;
			if (bool && (((Class298_Sub11) class298_sub11).aClass298_Sub26_Sub1_7236.aBoolean9313)) {
				int i_26_ = i_24_ + i_24_ - (((Class298_Sub11) class298_sub11).aClass298_Sub26_Sub1_7236.anInt9311);
				i_25_ = (int) (((long) i_26_ * (long) (((Class298_Sub19_Sub1) this).anIntArray9226[(((Class298_Sub11) class298_sub11).anInt7254) * 70539643])) >> 6);
				i_24_ <<= 8;
				if (i_25_ >= i_24_) {
					i_25_ = i_24_ + i_24_ - 1 - i_25_;
					((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method3026(true);
				}
			} else
				i_25_ = (int) (((long) i_24_ * (long) (((Class298_Sub19_Sub1) this).anIntArray9226[(((Class298_Sub11) class298_sub11).anInt7254) * 70539643])) >> 6);
			((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method2997(i_25_);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.ar(").append(')').toString());
		}
	}

	void method2967(int i, int i_27_, int i_28_, byte i_29_) {
		try {
			Class298_Sub11 class298_sub11 = (((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206[i][i_27_]);
			if (null != class298_sub11) {
				((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206[i][i_27_] = null;
				if ((((Class298_Sub19_Sub1) this).anIntArray9224[i] & 0x2) != 0) {
					for (Class298_Sub11 class298_sub11_30_ = (Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5967(1494711989); null != class298_sub11_30_; class298_sub11_30_ = (Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5969((byte) -16)) {
						if (((70539643 * ((Class298_Sub11) class298_sub11).anInt7254) == (((Class298_Sub11) class298_sub11_30_).anInt7254) * 70539643) && 1595133323 * ((Class298_Sub11) class298_sub11_30_).anInt7248 < 0 && class298_sub11 != class298_sub11_30_) {
							((Class298_Sub11) class298_sub11).anInt7248 = 0;
							break;
						}
					}
				} else
					((Class298_Sub11) class298_sub11).anInt7248 = 0;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.ac(").append(')').toString());
		}
	}

	void method2968(int i, int i_31_, byte i_32_) {
		try {
			/* empty */
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bd(").append(')').toString());
		}
	}

	void method2969(int i, int i_33_, int i_34_) {
		try {
			((Class298_Sub19_Sub1) this).anIntArray9232[i] = i_33_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bf(").append(')').toString());
		}
	}

	void method2970(int i, int i_35_) {
		try {
			for (Class298_Sub11 class298_sub11 = ((Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5967(1687020518)); null != class298_sub11; class298_sub11 = ((Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5969((byte) -28))) {
				if (i < 0 || i == 70539643 * (((Class298_Sub11) class298_sub11).anInt7254)) {
					if ((((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252) != null) {
						((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method2993(1164070869 * Class284.anInt3059 / 100);
						if (((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method3003())
							((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass298_Sub19_Sub4_9272.method3043(((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252);
						class298_sub11.method2902((byte) -31);
					}
					if ((1595133323 * ((Class298_Sub11) class298_sub11).anInt7248) < 0)
						((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206[(((Class298_Sub11) class298_sub11).anInt7254 * 70539643)][(1458878633 * ((Class298_Sub11) class298_sub11).anInt7239)] = null;
					class298_sub11.method2839(-1460969981);
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.be(").append(')').toString());
		}
	}

	void method2971(int i, int i_36_) {
		try {
			for (Class298_Sub11 class298_sub11 = ((Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5967(1987891181)); null != class298_sub11; class298_sub11 = ((Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5969((byte) -41))) {
				if ((i < 0 || (70539643 * ((Class298_Sub11) class298_sub11).anInt7254 == i)) && (((Class298_Sub11) class298_sub11).anInt7248 * 1595133323) < 0) {
					((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206[(((Class298_Sub11) class298_sub11).anInt7254 * 70539643)][(1458878633 * ((Class298_Sub11) class298_sub11).anInt7239)] = null;
					((Class298_Sub11) class298_sub11).anInt7248 = 0;
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bm(").append(')').toString());
		}
	}

	void method2972(boolean bool, int i) {
		try {
			if (bool)
				method2970(-1, -2134438754);
			else
				method2971(-1, -975680599);
			method2951(-1, 1450402912);
			for (int i_37_ = 0; i_37_ < 16; i_37_++)
				((Class298_Sub19_Sub1) this).anIntArray9238[i_37_] = ((Class298_Sub19_Sub1) this).anIntArray9214[i_37_];
			for (int i_38_ = 0; i_38_ < 16; i_38_++)
				((Class298_Sub19_Sub1) this).anIntArray9216[i_38_] = (((Class298_Sub19_Sub1) this).anIntArray9214[i_38_] & ~0x7f);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bc(").append(')').toString());
		}
	}

	void method2973(int i, int i_39_) {
		try {
			if ((((Class298_Sub19_Sub1) this).anIntArray9224[i] & 0x2) != 0) {
				for (Class298_Sub11 class298_sub11 = (Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5967(1928964592); null != class298_sub11; class298_sub11 = (Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5969((byte) 3)) {
					if ((((Class298_Sub11) class298_sub11).anInt7254 * 70539643 == i) && null == (((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206[i][(((Class298_Sub11) class298_sub11).anInt7239) * 1458878633]) && (((Class298_Sub11) class298_sub11).anInt7248 * 1595133323) < 0)
						((Class298_Sub11) class298_sub11).anInt7248 = 0;
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bx(").append(')').toString());
		}
	}

	void method2974(int i, byte i_40_) {
		try {
			if ((((Class298_Sub19_Sub1) this).anIntArray9224[i] & 0x4) != 0) {
				for (Class298_Sub11 class298_sub11 = (Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5967(2033370125); null != class298_sub11; class298_sub11 = (Class298_Sub11) ((Class298_Sub19_Sub5) (((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215)).aClass458_9271.method5969((byte) -105)) {
					if (70539643 * ((Class298_Sub11) class298_sub11).anInt7254 == i)
						((Class298_Sub11) class298_sub11).anInt7255 = 0;
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bo(").append(')').toString());
		}
	}

	synchronized void method2975(int i, int i_41_) {
		try {
			((Class298_Sub19_Sub1) this).anInt9208 = 1754395029 * i;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.ah(").append(')').toString());
		}
	}

	void method2976(int i, int i_42_, int i_43_) {
		try {
			((Class298_Sub19_Sub1) this).anIntArray9227[i] = i_42_;
			((Class298_Sub19_Sub1) this).anIntArray9228[i] = (int) (2097152.0 * Math.pow(2.0, (double) i_42_ * 5.4931640625E-4) + 0.5);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bl(").append(')').toString());
		}
	}

	int method2977(Class298_Sub11 class298_sub11, int i) {
		try {
			int i_44_ = (((Class298_Sub19_Sub1) this).anIntArray9212[70539643 * ((Class298_Sub11) class298_sub11).anInt7254]);
			if (i_44_ < 8192)
				return ((32 + i_44_ * (((Class298_Sub11) class298_sub11).anInt7241 * -1836886991)) >> 6);
			return (16384 - (((16384 - i_44_) * (128 - -1836886991 * (((Class298_Sub11) class298_sub11).anInt7241))) + 32 >> 6));
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bk(").append(')').toString());
		}
	}

	synchronized Class298_Sub19 method2930() {
		try {
			return ((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.f(").append(')').toString());
		}
	}

	synchronized Class298_Sub19 method2931() {
		try {
			return null;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.b(").append(')').toString());
		}
	}

	synchronized void method2934(int[] is, int i, int i_45_) {
		try {
			if (((Class298_Sub19_Sub1) this).aClass103_9231.method1099()) {
				int i_46_ = (((Class103) ((Class298_Sub19_Sub1) this).aClass103_9231).anInt1096 * (((Class298_Sub19_Sub1) this).anInt9223 * 1957555245) / (Class284.anInt3059 * 1164070869));
				do {
					long l = ((5242905950797426295L * ((Class298_Sub19_Sub1) this).aLong9235) + (long) i_46_ * (long) i_45_);
					if ((((Class298_Sub19_Sub1) this).aLong9236 * 56522420256794041L) - l >= 0L) {
						((Class298_Sub19_Sub1) this).aLong9235 = 9035186418716527431L * l;
						break;
					}
					int i_47_ = (int) (((long) i_46_ + ((56522420256794041L * ((Class298_Sub19_Sub1) this).aLong9236) - (((Class298_Sub19_Sub1) this).aLong9235 * 5242905950797426295L)) - 1L) / (long) i_46_);
					((Class298_Sub19_Sub1) this).aLong9235 += 9035186418716527431L * ((long) i_46_ * (long) i_47_);
					((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2934(is, i, i_47_);
					i += i_47_;
					i_45_ -= i_47_;
					method2978((byte) -114);
				} while (((Class298_Sub19_Sub1) this).aClass103_9231.method1099());
			}
			((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2934(is, i, i_45_);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.k(").append(')').toString());
		}
	}

	synchronized int method2936() {
		return 0;
	}

	public Class298_Sub19_Sub1() {
		((Class298_Sub19_Sub1) this).anIntArray9240 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9211 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9212 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9213 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9214 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9238 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9216 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9232 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9218 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9219 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9224 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9234 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9225 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9226 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9227 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9228 = new int[16];
		((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206 = new Class298_Sub11[16][128];
		((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230 = new Class298_Sub11[16][128];
		((Class298_Sub19_Sub1) this).aClass103_9231 = new Class103();
		((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215 = new Class298_Sub19_Sub5(this);
		((Class298_Sub19_Sub1) this).aClass440_9222 = new Class440(128);
		method2954(-1, 256, -1253398615);
		method2972(true, 214293801);
	}

	void method2978(byte i) {
		try {
			int i_48_ = ((Class298_Sub19_Sub1) this).anInt9233 * -1094678159;
			int i_49_ = -847832283 * ((Class298_Sub19_Sub1) this).anInt9229;
			long l = 56522420256794041L * ((Class298_Sub19_Sub1) this).aLong9236;
			if (null != ((Class298_Sub19_Sub1) this).aClass298_Sub13_9209 && (i_49_ == -911546629 * ((Class298_Sub19_Sub1) this).anInt9239)) {
				method2952(((Class298_Sub19_Sub1) this).aClass298_Sub13_9209, ((Class298_Sub19_Sub1) this).aBoolean9217, ((Class298_Sub19_Sub1) this).aBoolean9237, -913403234);
				method2978((byte) -108);
			} else {
				while (i_49_ == (-847832283 * ((Class298_Sub19_Sub1) this).anInt9229)) {
					while (i_49_ == (((Class103) (((Class298_Sub19_Sub1) this).aClass103_9231)).anIntArray1105[i_48_])) {
						((Class298_Sub19_Sub1) this).aClass103_9231.method1089(i_48_);
						int i_50_ = ((Class298_Sub19_Sub1) this).aClass103_9231.method1092(i_48_);
						if (1 == i_50_) {
							((Class298_Sub19_Sub1) this).aClass103_9231.method1090();
							((Class298_Sub19_Sub1) this).aClass103_9231.method1098(i_48_);
							if (!((Class298_Sub19_Sub1) this).aClass103_9231.method1097()) {
								if (i >= 0)
									return;
							} else {
								if ((((Class298_Sub19_Sub1) this).aClass298_Sub13_9209) != null) {
									method2958((((Class298_Sub19_Sub1) this).aClass298_Sub13_9209), (((Class298_Sub19_Sub1) this).aBoolean9217), (byte) 111);
									method2978((byte) -64);
									return;
								}
								if (((Class298_Sub19_Sub1) this).aBoolean9217 && i_49_ != 0)
									((Class298_Sub19_Sub1) this).aClass103_9231.method1100(l);
								else {
									method2972(true, 1006206254);
									((Class298_Sub19_Sub1) this).aClass103_9231.method1087();
									return;
								}
							}
							break;
						}
						if (0 != (i_50_ & 0x80))
							method2981(i_50_, 2134974919);
						((Class298_Sub19_Sub1) this).aClass103_9231.method1091(i_48_);
						((Class298_Sub19_Sub1) this).aClass103_9231.method1098(i_48_);
					}
					i_48_ = ((Class298_Sub19_Sub1) this).aClass103_9231.method1096();
					i_49_ = ((Class103) (((Class298_Sub19_Sub1) this).aClass103_9231)).anIntArray1105[i_48_];
					l = ((Class298_Sub19_Sub1) this).aClass103_9231.method1095(i_49_);
				}
				((Class298_Sub19_Sub1) this).anInt9233 = i_48_ * 1034491793;
				((Class298_Sub19_Sub1) this).anInt9229 = -1484027731 * i_49_;
				((Class298_Sub19_Sub1) this).aLong9236 = l * -5395595849438982007L;
				if (null != ((Class298_Sub19_Sub1) this).aClass298_Sub13_9209 && (-911546629 * ((Class298_Sub19_Sub1) this).anInt9239 < i_49_)) {
					((Class298_Sub19_Sub1) this).anInt9233 = -1034491793;
					((Class298_Sub19_Sub1) this).anInt9229 = ((Class298_Sub19_Sub1) this).anInt9239 * 981233567;
					((Class298_Sub19_Sub1) this).aLong9236 = (((Class298_Sub19_Sub1) this).aClass103_9231.method1095(((Class298_Sub19_Sub1) this).anInt9229 * -847832283)) * -5395595849438982007L;
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bg(").append(')').toString());
		}
	}

	synchronized void method2979(Class298_Sub13 class298_sub13, boolean bool, boolean bool_51_, long l) {
		try {
			method2952(class298_sub13, bool, bool_51_, 33655883);
			method2987(l * (long) ((Class103) (((Class298_Sub19_Sub1) this).aClass103_9231)).anInt1096);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.aw(").append(')').toString());
		}
	}

	boolean method2980(Class298_Sub11 class298_sub11, int[] is, int i, int i_52_, int i_53_) {
		try {
			((Class298_Sub11) class298_sub11).anInt7253 = Class284.anInt3059 * 1164070869 / 100 * 718794433;
			if (1595133323 * ((Class298_Sub11) class298_sub11).anInt7248 >= 0 && (null == (((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252) || ((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method3002())) {
				class298_sub11.method2902((byte) 20);
				class298_sub11.method2839(-1460969981);
				if (((Class298_Sub11) class298_sub11).anInt7235 * 279429195 > 0 && (((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230[(((Class298_Sub11) class298_sub11).anInt7254 * 70539643)][279429195 * (((Class298_Sub11) class298_sub11).anInt7235)]) == class298_sub11)
					((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230[(70539643 * ((Class298_Sub11) class298_sub11).anInt7254)][(279429195 * ((Class298_Sub11) class298_sub11).anInt7235)] = null;
				return true;
			}
			int i_54_ = 1520725153 * ((Class298_Sub11) class298_sub11).anInt7234;
			if (i_54_ > 0) {
				i_54_ -= (int) ((16.0 * Math.pow(2.0, (4.921259842519685E-4 * (double) (((Class298_Sub19_Sub1) this).anIntArray9219[((((Class298_Sub11) class298_sub11).anInt7254) * 70539643)])))) + 0.5);
				if (i_54_ < 0)
					i_54_ = 0;
				((Class298_Sub11) class298_sub11).anInt7234 = -659261599 * i_54_;
			}
			((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method3000(method2984(class298_sub11, (byte) -70));
			Class104 class104 = ((Class298_Sub11) class298_sub11).aClass104_7246;
			boolean bool = false;
			((Class298_Sub11) class298_sub11).anInt7251 += -770032815;
			((Class298_Sub11) class298_sub11).anInt7237 += -1969267435 * ((Class104) class104).anInt1116;
			double d = ((double) ((1458878633 * (((Class298_Sub11) class298_sub11).anInt7239) - 60 << 8) + ((((Class298_Sub11) class298_sub11).anInt7243 * 397264215 * (((Class298_Sub11) class298_sub11).anInt7234 * 1520725153)) >> 12)) * 5.086263020833333E-6);
			if (((Class104) class104).anInt1111 * 1753302577 > 0) {
				if (-219256033 * ((Class104) class104).anInt1109 > 0)
					((Class298_Sub11) class298_sub11).anInt7245 += (int) (128.0 * Math.pow(2.0, d * (double) ((((Class104) class104).anInt1109) * -219256033)) + 0.5) * 1456370825;
				else
					((Class298_Sub11) class298_sub11).anInt7245 += 1731871872;
				if ((((Class298_Sub11) class298_sub11).anInt7245 * -272678471 * (((Class104) class104).anInt1111 * 1753302577)) >= 819200)
					bool = true;
			}
			if (((Class104) class104).aByteArray1114 != null) {
				if (((Class104) class104).anInt1112 * 440036513 > 0)
					((Class298_Sub11) class298_sub11).anInt7238 += (int) (128.0 * Math.pow(2.0, d * (double) ((((Class104) class104).anInt1112) * 440036513)) + 0.5) * -840260727;
				else
					((Class298_Sub11) class298_sub11).anInt7238 += -179190656;
				for (/**/; ((-842627811 * ((Class298_Sub11) class298_sub11).anInt7247 < ((Class104) class104).aByteArray1114.length - 2) && ((((Class298_Sub11) class298_sub11).anInt7238 * -84753735) > ((((Class104) class104).aByteArray1114[-842627811 * (((Class298_Sub11) class298_sub11).anInt7247) + 2]) & 0xff) << 8)); ((Class298_Sub11) class298_sub11).anInt7247 += 1519700586) {
					/* empty */
				}
				if ((((Class298_Sub11) class298_sub11).anInt7247 * -842627811 == ((Class104) class104).aByteArray1114.length - 2) && (((Class104) class104).aByteArray1114[1 + (((Class298_Sub11) class298_sub11).anInt7247 * -842627811)]) == 0)
					bool = true;
			}
			if (((Class298_Sub11) class298_sub11).anInt7248 * 1595133323 >= 0 && ((Class104) class104).aByteArray1110 != null && 0 == ((((Class298_Sub19_Sub1) this).anIntArray9224[(70539643 * ((Class298_Sub11) class298_sub11).anInt7254)]) & 0x1) && (((Class298_Sub11) class298_sub11).anInt7235 * 279429195 < 0 || (class298_sub11 != (((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230[(70539643 * ((Class298_Sub11) class298_sub11).anInt7254)][279429195 * (((Class298_Sub11) class298_sub11).anInt7235)])))) {
				if (20905307 * ((Class104) class104).anInt1113 > 0)
					((Class298_Sub11) class298_sub11).anInt7248 += (int) (128.0 * Math.pow(2.0, ((double) (20905307 * (((Class104) class104).anInt1113)) * d)) + 0.5) * 984183331;
				else
					((Class298_Sub11) class298_sub11).anInt7248 += 1421414784;
				for (/**/; ((((Class298_Sub11) class298_sub11).anInt7244 * 607608861 < ((Class104) class104).aByteArray1110.length - 2) && ((1595133323 * ((Class298_Sub11) class298_sub11).anInt7248) > ((((Class104) class104).aByteArray1110[2 + (((Class298_Sub11) class298_sub11).anInt7244 * 607608861)]) & 0xff) << 8)); ((Class298_Sub11) class298_sub11).anInt7244 += -1465072534) {
					/* empty */
				}
				if (((Class298_Sub11) class298_sub11).anInt7244 * 607608861 == ((Class104) class104).aByteArray1110.length - 2)
					bool = true;
			}
			if (bool) {
				((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method2993(((Class298_Sub11) class298_sub11).anInt7253 * -129654463);
				if (null != is)
					((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method2934(is, i, i_52_);
				else
					((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method2935(i_52_);
				if (((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method3003())
					((Class298_Sub19_Sub5) ((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215).aClass298_Sub19_Sub4_9272.method3043(((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252);
				class298_sub11.method2902((byte) -27);
				if (((Class298_Sub11) class298_sub11).anInt7248 * 1595133323 >= 0) {
					class298_sub11.method2839(-1460969981);
					if ((279429195 * ((Class298_Sub11) class298_sub11).anInt7235) > 0 && (((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230[(((Class298_Sub11) class298_sub11).anInt7254 * 70539643)][279429195 * (((Class298_Sub11) class298_sub11).anInt7235)]) == class298_sub11)
						((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230[(70539643 * ((Class298_Sub11) class298_sub11).anInt7254)][(279429195 * ((Class298_Sub11) class298_sub11).anInt7235)] = null;
				}
				return true;
			}
			((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252.method3023(((Class298_Sub11) class298_sub11).anInt7253 * -129654463, method2982(class298_sub11, 847582824), method2977(class298_sub11, -1934295725));
			return false;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bp(").append(')').toString());
		}
	}

	synchronized Class298_Sub19 method2944() {
		return ((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215;
	}

	synchronized Class298_Sub19 method2937() {
		return ((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215;
	}

	synchronized Class298_Sub19 method2939() {
		return ((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215;
	}

	void method2981(int i, int i_55_) {
		try {
			int i_56_ = i & 0xf0;
			if (128 == i_56_) {
				int i_57_ = i & 0xf;
				int i_58_ = i >> 8 & 0x7f;
				int i_59_ = i >> 16 & 0x7f;
				method2967(i_57_, i_58_, i_59_, (byte) -64);
			} else if (144 == i_56_) {
				int i_60_ = i & 0xf;
				int i_61_ = i >> 8 & 0x7f;
				int i_62_ = i >> 16 & 0x7f;
				if (i_62_ > 0)
					method2965(i_60_, i_61_, i_62_, -1647062049);
				else
					method2967(i_60_, i_61_, 64, (byte) 75);
			} else if (160 == i_56_) {
				int i_63_ = i & 0xf;
				int i_64_ = i >> 8 & 0x7f;
				int i_65_ = i >> 16 & 0x7f;
				method2983(i_63_, i_64_, i_65_, -2102837520);
			} else if (i_56_ == 176) {
				int i_66_ = i & 0xf;
				int i_67_ = i >> 8 & 0x7f;
				int i_68_ = i >> 16 & 0x7f;
				if (i_67_ == 0)
					((Class298_Sub19_Sub1) this).anIntArray9216[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9216[i_66_] & ~0x1fc000) + (i_68_ << 14);
				if (i_67_ == 32)
					((Class298_Sub19_Sub1) this).anIntArray9216[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9216[i_66_] & ~0x3f80) + (i_68_ << 7);
				if (1 == i_67_)
					((Class298_Sub19_Sub1) this).anIntArray9218[i_66_] = (i_68_ << 7) + ((((Class298_Sub19_Sub1) this).anIntArray9218[i_66_]) & ~0x3f80);
				if (i_67_ == 33)
					((Class298_Sub19_Sub1) this).anIntArray9218[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9218[i_66_] & ~0x7f) + i_68_;
				if (i_67_ == 5)
					((Class298_Sub19_Sub1) this).anIntArray9219[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9219[i_66_] & ~0x3f80) + (i_68_ << 7);
				if (i_67_ == 37)
					((Class298_Sub19_Sub1) this).anIntArray9219[i_66_] = i_68_ + ((((Class298_Sub19_Sub1) this).anIntArray9219[i_66_]) & ~0x7f);
				if (7 == i_67_)
					((Class298_Sub19_Sub1) this).anIntArray9211[i_66_] = (i_68_ << 7) + ((((Class298_Sub19_Sub1) this).anIntArray9211[i_66_]) & ~0x3f80);
				if (39 == i_67_)
					((Class298_Sub19_Sub1) this).anIntArray9211[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9211[i_66_] & ~0x7f) + i_68_;
				if (i_67_ == 10)
					((Class298_Sub19_Sub1) this).anIntArray9212[i_66_] = (i_68_ << 7) + ((((Class298_Sub19_Sub1) this).anIntArray9212[i_66_]) & ~0x3f80);
				if (i_67_ == 42)
					((Class298_Sub19_Sub1) this).anIntArray9212[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9212[i_66_] & ~0x7f) + i_68_;
				if (11 == i_67_)
					((Class298_Sub19_Sub1) this).anIntArray9213[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9213[i_66_] & ~0x3f80) + (i_68_ << 7);
				if (43 == i_67_)
					((Class298_Sub19_Sub1) this).anIntArray9213[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9213[i_66_] & ~0x7f) + i_68_;
				if (i_67_ == 64) {
					if (i_68_ >= 64)
						((Class298_Sub19_Sub1) this).anIntArray9224[i_66_] |= 0x1;
					else
						((Class298_Sub19_Sub1) this).anIntArray9224[i_66_] &= ~0x1;
				}
				if (i_67_ == 65) {
					if (i_68_ >= 64)
						((Class298_Sub19_Sub1) this).anIntArray9224[i_66_] |= 0x2;
					else {
						method2973(i_66_, 1763105998);
						((Class298_Sub19_Sub1) this).anIntArray9224[i_66_] &= ~0x2;
					}
				}
				if (99 == i_67_)
					((Class298_Sub19_Sub1) this).anIntArray9234[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9234[i_66_] & 0x7f) + (i_68_ << 7);
				if (i_67_ == 98)
					((Class298_Sub19_Sub1) this).anIntArray9234[i_66_] = i_68_ + ((((Class298_Sub19_Sub1) this).anIntArray9234[i_66_]) & 0x3f80);
				if (101 == i_67_)
					((Class298_Sub19_Sub1) this).anIntArray9234[i_66_] = (i_68_ << 7) + (16384 + ((((Class298_Sub19_Sub1) this).anIntArray9234[i_66_]) & 0x7f));
				if (i_67_ == 100)
					((Class298_Sub19_Sub1) this).anIntArray9234[i_66_] = 16384 + ((((Class298_Sub19_Sub1) this).anIntArray9234[i_66_]) & 0x3f80) + i_68_;
				if (i_67_ == 120)
					method2970(i_66_, -2093466123);
				if (121 == i_67_)
					method2951(i_66_, 1442077178);
				if (123 == i_67_)
					method2971(i_66_, -975680599);
				if (6 == i_67_) {
					int i_69_ = ((Class298_Sub19_Sub1) this).anIntArray9234[i_66_];
					if (16384 == i_69_)
						((Class298_Sub19_Sub1) this).anIntArray9225[i_66_] = ((((Class298_Sub19_Sub1) this).anIntArray9225[i_66_]) & ~0x3f80) + (i_68_ << 7);
				}
				if (38 == i_67_) {
					int i_70_ = ((Class298_Sub19_Sub1) this).anIntArray9234[i_66_];
					if (i_70_ == 16384)
						((Class298_Sub19_Sub1) this).anIntArray9225[i_66_] = ((((Class298_Sub19_Sub1) this).anIntArray9225[i_66_]) & ~0x7f) + i_68_;
				}
				if (i_67_ == 16)
					((Class298_Sub19_Sub1) this).anIntArray9226[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9226[i_66_] & ~0x3f80) + (i_68_ << 7);
				if (i_67_ == 48)
					((Class298_Sub19_Sub1) this).anIntArray9226[i_66_] = (((Class298_Sub19_Sub1) this).anIntArray9226[i_66_] & ~0x7f) + i_68_;
				if (i_67_ == 81) {
					if (i_68_ >= 64)
						((Class298_Sub19_Sub1) this).anIntArray9224[i_66_] |= 0x4;
					else {
						method2974(i_66_, (byte) 0);
						((Class298_Sub19_Sub1) this).anIntArray9224[i_66_] &= ~0x4;
					}
				}
				if (17 == i_67_)
					method2976(i_66_, ((((Class298_Sub19_Sub1) this).anIntArray9227[i_66_]) & ~0x3f80) + (i_68_ << 7), 2145961561);
				if (49 == i_67_)
					method2976(i_66_, i_68_ + ((((Class298_Sub19_Sub1) this).anIntArray9227[i_66_]) & ~0x7f), 1479954642);
			} else if (192 == i_56_) {
				int i_71_ = i & 0xf;
				int i_72_ = i >> 8 & 0x7f;
				method2964(i_71_, (((Class298_Sub19_Sub1) this).anIntArray9216[i_71_] + i_72_), (byte) 120);
			} else if (208 == i_56_) {
				int i_73_ = i & 0xf;
				int i_74_ = i >> 8 & 0x7f;
				method2968(i_73_, i_74_, (byte) 6);
			} else if (224 == i_56_) {
				int i_75_ = i & 0xf;
				int i_76_ = (i >> 9 & 0x3f80) + (i >> 8 & 0x7f);
				method2969(i_75_, i_76_, -724209394);
			} else {
				i_56_ = i & 0xff;
				if (255 == i_56_)
					method2972(true, 1683987385);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bb(").append(')').toString());
		}
	}

	synchronized int method2943() {
		return 0;
	}

	synchronized void method2932(int[] is, int i, int i_77_) {
		if (((Class298_Sub19_Sub1) this).aClass103_9231.method1099()) {
			int i_78_ = ((((Class103) ((Class298_Sub19_Sub1) this).aClass103_9231).anInt1096) * (((Class298_Sub19_Sub1) this).anInt9223 * 1957555245) / (Class284.anInt3059 * 1164070869));
			do {
				long l = ((5242905950797426295L * ((Class298_Sub19_Sub1) this).aLong9235) + (long) i_78_ * (long) i_77_);
				if ((((Class298_Sub19_Sub1) this).aLong9236 * 56522420256794041L) - l >= 0L) {
					((Class298_Sub19_Sub1) this).aLong9235 = 9035186418716527431L * l;
					break;
				}
				int i_79_ = (int) (((long) i_78_ + ((56522420256794041L * ((Class298_Sub19_Sub1) this).aLong9236) - (((Class298_Sub19_Sub1) this).aLong9235 * 5242905950797426295L)) - 1L) / (long) i_78_);
				((Class298_Sub19_Sub1) this).aLong9235 += 9035186418716527431L * ((long) i_78_ * (long) i_79_);
				((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2934(is, i, i_79_);
				i += i_79_;
				i_77_ -= i_79_;
				method2978((byte) -27);
			} while (((Class298_Sub19_Sub1) this).aClass103_9231.method1099());
		}
		((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2934(is, i, i_77_);
	}

	synchronized Class298_Sub19 method2940() {
		return null;
	}

	synchronized void method2945(int[] is, int i, int i_80_) {
		if (((Class298_Sub19_Sub1) this).aClass103_9231.method1099()) {
			int i_81_ = ((((Class103) ((Class298_Sub19_Sub1) this).aClass103_9231).anInt1096) * (((Class298_Sub19_Sub1) this).anInt9223 * 1957555245) / (Class284.anInt3059 * 1164070869));
			do {
				long l = ((5242905950797426295L * ((Class298_Sub19_Sub1) this).aLong9235) + (long) i_81_ * (long) i_80_);
				if ((((Class298_Sub19_Sub1) this).aLong9236 * 56522420256794041L) - l >= 0L) {
					((Class298_Sub19_Sub1) this).aLong9235 = 9035186418716527431L * l;
					break;
				}
				int i_82_ = (int) (((long) i_81_ + ((56522420256794041L * ((Class298_Sub19_Sub1) this).aLong9236) - (((Class298_Sub19_Sub1) this).aLong9235 * 5242905950797426295L)) - 1L) / (long) i_81_);
				((Class298_Sub19_Sub1) this).aLong9235 += 9035186418716527431L * ((long) i_81_ * (long) i_82_);
				((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2934(is, i, i_82_);
				i += i_82_;
				i_80_ -= i_82_;
				method2978((byte) -81);
			} while (((Class298_Sub19_Sub1) this).aClass103_9231.method1099());
		}
		((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2934(is, i, i_80_);
	}

	synchronized void method2949(int i) {
		if (((Class298_Sub19_Sub1) this).aClass103_9231.method1099()) {
			int i_83_ = ((((Class103) ((Class298_Sub19_Sub1) this).aClass103_9231).anInt1096) * (1957555245 * ((Class298_Sub19_Sub1) this).anInt9223) / (1164070869 * Class284.anInt3059));
			do {
				long l = ((5242905950797426295L * ((Class298_Sub19_Sub1) this).aLong9235) + (long) i * (long) i_83_);
				if ((((Class298_Sub19_Sub1) this).aLong9236 * 56522420256794041L) - l >= 0L) {
					((Class298_Sub19_Sub1) this).aLong9235 = 9035186418716527431L * l;
					break;
				}
				int i_84_ = (int) (((long) i_83_ + ((56522420256794041L * ((Class298_Sub19_Sub1) this).aLong9236) - (((Class298_Sub19_Sub1) this).aLong9235 * 5242905950797426295L)) - 1L) / (long) i_83_);
				((Class298_Sub19_Sub1) this).aLong9235 += 9035186418716527431L * ((long) i_83_ * (long) i_84_);
				((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2935(i_84_);
				i -= i_84_;
				method2978((byte) -113);
			} while (((Class298_Sub19_Sub1) this).aClass103_9231.method1099());
		}
		((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2935(i);
	}

	synchronized void method2947(int i) {
		if (((Class298_Sub19_Sub1) this).aClass103_9231.method1099()) {
			int i_85_ = ((((Class103) ((Class298_Sub19_Sub1) this).aClass103_9231).anInt1096) * (1957555245 * ((Class298_Sub19_Sub1) this).anInt9223) / (1164070869 * Class284.anInt3059));
			do {
				long l = ((5242905950797426295L * ((Class298_Sub19_Sub1) this).aLong9235) + (long) i * (long) i_85_);
				if ((((Class298_Sub19_Sub1) this).aLong9236 * 56522420256794041L) - l >= 0L) {
					((Class298_Sub19_Sub1) this).aLong9235 = 9035186418716527431L * l;
					break;
				}
				int i_86_ = (int) (((long) i_85_ + ((56522420256794041L * ((Class298_Sub19_Sub1) this).aLong9236) - (((Class298_Sub19_Sub1) this).aLong9235 * 5242905950797426295L)) - 1L) / (long) i_85_);
				((Class298_Sub19_Sub1) this).aLong9235 += 9035186418716527431L * ((long) i_85_ * (long) i_86_);
				((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2935(i_86_);
				i -= i_86_;
				method2978((byte) -34);
			} while (((Class298_Sub19_Sub1) this).aClass103_9231.method1099());
		}
		((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2935(i);
	}

	synchronized Class298_Sub19 method2946() {
		return ((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215;
	}

	int method2982(Class298_Sub11 class298_sub11, int i) {
		try {
			if (0 == (((Class298_Sub19_Sub1) this).anIntArray9240[((Class298_Sub11) class298_sub11).anInt7254 * 70539643]))
				return 0;
			Class104 class104 = ((Class298_Sub11) class298_sub11).aClass104_7246;
			int i_87_ = (((((Class298_Sub19_Sub1) this).anIntArray9213[70539643 * ((Class298_Sub11) class298_sub11).anInt7254]) * (((Class298_Sub19_Sub1) this).anIntArray9211[(((Class298_Sub11) class298_sub11).anInt7254 * 70539643)])) + 4096 >> 13);
			i_87_ = 16384 + i_87_ * i_87_ >> 15;
			i_87_ = 16384 + (((Class298_Sub11) class298_sub11).anInt7240 * 1380355417 * i_87_) >> 15;
			i_87_ = i_87_ * (((Class298_Sub19_Sub1) this).anInt9207 * -207519113) + 128 >> 8;
			i_87_ = (((Class298_Sub19_Sub1) this).anInt9208 * 2020528573 * i_87_ >> 8);
			i_87_ = 128 + i_87_ * (((Class298_Sub19_Sub1) this).anIntArray9240[(((Class298_Sub11) class298_sub11).anInt7254 * 70539643)]) >> 8;
			if (1753302577 * ((Class104) class104).anInt1111 > 0)
				i_87_ = (int) (((double) i_87_ * Math.pow(0.5, (1.953125E-5 * (double) ((((Class298_Sub11) class298_sub11).anInt7245) * -272678471) * (double) ((((Class104) class104).anInt1111) * 1753302577)))) + 0.5);
			if (((Class104) class104).aByteArray1114 != null) {
				int i_88_ = -84753735 * ((Class298_Sub11) class298_sub11).anInt7238;
				int i_89_ = (((Class104) class104).aByteArray1114[1 + (((Class298_Sub11) class298_sub11).anInt7247 * -842627811)]);
				if (-842627811 * ((Class298_Sub11) class298_sub11).anInt7247 < ((Class104) class104).aByteArray1114.length - 2) {
					int i_90_ = ((((Class104) class104).aByteArray1114[(((Class298_Sub11) class298_sub11).anInt7247 * -842627811)]) & 0xff) << 8;
					int i_91_ = ((((Class104) class104).aByteArray1114[(((Class298_Sub11) class298_sub11).anInt7247 * -842627811) + 2]) & 0xff) << 8;
					i_89_ += ((i_88_ - i_90_) * ((((Class104) class104).aByteArray1114[3 + -842627811 * ((Class298_Sub11) class298_sub11).anInt7247]) - i_89_) / (i_91_ - i_90_));
				}
				i_87_ = i_87_ * i_89_ + 32 >> 6;
			}
			if (((Class298_Sub11) class298_sub11).anInt7248 * 1595133323 > 0 && null != ((Class104) class104).aByteArray1110) {
				int i_92_ = 1595133323 * ((Class298_Sub11) class298_sub11).anInt7248;
				int i_93_ = (((Class104) class104).aByteArray1110[1 + (607608861 * ((Class298_Sub11) class298_sub11).anInt7244)]);
				if (((Class298_Sub11) class298_sub11).anInt7244 * 607608861 < ((Class104) class104).aByteArray1110.length - 2) {
					int i_94_ = (((((Class104) class104).aByteArray1110[(607608861 * ((Class298_Sub11) class298_sub11).anInt7244)]) & 0xff) << 8);
					int i_95_ = (((((Class104) class104).aByteArray1110[607608861 * (((Class298_Sub11) class298_sub11).anInt7244) + 2]) & 0xff) << 8);
					i_93_ += ((i_92_ - i_94_) * ((((Class104) class104).aByteArray1110[3 + (((Class298_Sub11) class298_sub11).anInt7244) * 607608861]) - i_93_) / (i_95_ - i_94_));
				}
				i_87_ = 32 + i_93_ * i_87_ >> 6;
			}
			return i_87_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bw(").append(')').toString());
		}
	}

	public Class298_Sub19_Sub1(Class298_Sub19_Sub1 class298_sub19_sub1_96_) {
		((Class298_Sub19_Sub1) this).anIntArray9240 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9211 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9212 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9213 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9214 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9238 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9216 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9232 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9218 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9219 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9224 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9234 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9225 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9226 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9227 = new int[16];
		((Class298_Sub19_Sub1) this).anIntArray9228 = new int[16];
		((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9206 = new Class298_Sub11[16][128];
		((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230 = new Class298_Sub11[16][128];
		((Class298_Sub19_Sub1) this).aClass103_9231 = new Class103();
		((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215 = new Class298_Sub19_Sub5(this);
		((Class298_Sub19_Sub1) this).aClass440_9222 = ((Class298_Sub19_Sub1) class298_sub19_sub1_96_).aClass440_9222;
		method2954(-1, 256, 1130954485);
		method2972(true, 662178451);
	}

	void method2983(int i, int i_97_, int i_98_, int i_99_) {
		try {
			/* empty */
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.am(").append(')').toString());
		}
	}

	int method2984(Class298_Sub11 class298_sub11, byte i) {
		try {
			int i_100_ = (-1263376917 * ((Class298_Sub11) class298_sub11).anInt7242 + ((1520725153 * ((Class298_Sub11) class298_sub11).anInt7234 * (((Class298_Sub11) class298_sub11).anInt7243 * 397264215)) >> 12));
			i_100_ += (((((Class298_Sub19_Sub1) this).anIntArray9232[((Class298_Sub11) class298_sub11).anInt7254 * 70539643]) - 8192) * (((Class298_Sub19_Sub1) this).anIntArray9225[70539643 * (((Class298_Sub11) class298_sub11).anInt7254)])) >> 12;
			Class104 class104 = ((Class298_Sub11) class298_sub11).aClass104_7246;
			if (430264429 * ((Class104) class104).anInt1116 > 0 && (671305261 * ((Class104) class104).anInt1115 > 0 || (((Class298_Sub19_Sub1) this).anIntArray9218[(((Class298_Sub11) class298_sub11).anInt7254 * 70539643)]) > 0)) {
				int i_101_ = 671305261 * ((Class104) class104).anInt1115 << 2;
				int i_102_ = 505758083 * ((Class104) class104).anInt1117 << 1;
				if (((Class298_Sub11) class298_sub11).anInt7251 * 1896082865 < i_102_)
					i_101_ = i_101_ * (((Class298_Sub11) class298_sub11).anInt7251 * 1896082865) / i_102_;
				i_101_ += (((Class298_Sub19_Sub1) this).anIntArray9218[70539643 * (((Class298_Sub11) class298_sub11).anInt7254)]) >> 7;
				double d = Math.sin((double) ((((Class298_Sub11) class298_sub11).anInt7237) * -1932760071 & 0x1ff) * 0.01227184630308513);
				i_100_ += (int) ((double) i_101_ * d);
			}
			int i_103_ = (int) (((double) (256 * (((Class298_Sub11) class298_sub11).aClass298_Sub26_Sub1_7236.anInt9312)) * Math.pow(2.0, (double) i_100_ * 3.255208333333333E-4) / (double) (1164070869 * Class284.anInt3059)) + 0.5);
			return i_103_ < 1 ? 1 : i_103_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bu(").append(')').toString());
		}
	}

	synchronized int method2929() {
		try {
			return 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.p(").append(')').toString());
		}
	}

	synchronized Class298_Sub19 method2941() {
		return null;
	}

	synchronized Class298_Sub19 method2938() {
		return ((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215;
	}

	synchronized int method2942() {
		return 0;
	}

	synchronized boolean method2985(int i) {
		try {
			return ((Class298_Sub19_Sub1) this).aClass103_9231.method1099();
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.ay(").append(')').toString());
		}
	}

	synchronized void method2928(int[] is, int i, int i_104_) {
		if (((Class298_Sub19_Sub1) this).aClass103_9231.method1099()) {
			int i_105_ = ((((Class103) ((Class298_Sub19_Sub1) this).aClass103_9231).anInt1096) * (((Class298_Sub19_Sub1) this).anInt9223 * 1957555245) / (Class284.anInt3059 * 1164070869));
			do {
				long l = ((5242905950797426295L * ((Class298_Sub19_Sub1) this).aLong9235) + (long) i_105_ * (long) i_104_);
				if ((((Class298_Sub19_Sub1) this).aLong9236 * 56522420256794041L) - l >= 0L) {
					((Class298_Sub19_Sub1) this).aLong9235 = 9035186418716527431L * l;
					break;
				}
				int i_106_ = (int) (((long) i_105_ + ((56522420256794041L * ((Class298_Sub19_Sub1) this).aLong9236) - (((Class298_Sub19_Sub1) this).aLong9235 * 5242905950797426295L)) - 1L) / (long) i_105_);
				((Class298_Sub19_Sub1) this).aLong9235 += 9035186418716527431L * ((long) i_105_ * (long) i_106_);
				((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2934(is, i, i_106_);
				i += i_106_;
				i_104_ -= i_106_;
				method2978((byte) -106);
			} while (((Class298_Sub19_Sub1) this).aClass103_9231.method1099());
		}
		((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2934(is, i, i_104_);
	}

	synchronized void method2935(int i) {
		try {
			if (((Class298_Sub19_Sub1) this).aClass103_9231.method1099()) {
				int i_107_ = (((Class103) ((Class298_Sub19_Sub1) this).aClass103_9231).anInt1096 * (1957555245 * ((Class298_Sub19_Sub1) this).anInt9223) / (1164070869 * Class284.anInt3059));
				do {
					long l = ((5242905950797426295L * ((Class298_Sub19_Sub1) this).aLong9235) + (long) i * (long) i_107_);
					if ((((Class298_Sub19_Sub1) this).aLong9236 * 56522420256794041L) - l >= 0L) {
						((Class298_Sub19_Sub1) this).aLong9235 = 9035186418716527431L * l;
						break;
					}
					int i_108_ = (int) (((long) i_107_ + ((56522420256794041L * ((Class298_Sub19_Sub1) this).aLong9236) - (((Class298_Sub19_Sub1) this).aLong9235 * 5242905950797426295L)) - 1L) / (long) i_107_);
					((Class298_Sub19_Sub1) this).aLong9235 += 9035186418716527431L * ((long) i_107_ * (long) i_108_);
					((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2935(i_108_);
					i -= i_108_;
					method2978((byte) -85);
				} while (((Class298_Sub19_Sub1) this).aClass103_9231.method1099());
			}
			((Class298_Sub19_Sub1) this).aClass298_Sub19_Sub5_9215.method2935(i);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.d(").append(')').toString());
		}
	}

	boolean method2986(Class298_Sub11 class298_sub11, byte i) {
		try {
			if (null == (((Class298_Sub11) class298_sub11).aClass298_Sub19_Sub2_7252)) {
				if (1595133323 * ((Class298_Sub11) class298_sub11).anInt7248 >= 0) {
					class298_sub11.method2839(-1460969981);
					if ((((Class298_Sub11) class298_sub11).anInt7235 * 279429195) > 0 && (class298_sub11 == (((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230[(((Class298_Sub11) class298_sub11).anInt7254 * 70539643)][(((Class298_Sub11) class298_sub11).anInt7235 * 279429195)])))
						((Class298_Sub19_Sub1) this).aClass298_Sub11ArrayArray9230[(70539643 * ((Class298_Sub11) class298_sub11).anInt7254)][(279429195 * ((Class298_Sub11) class298_sub11).anInt7235)] = null;
				}
				return true;
			}
			return false;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bs(").append(')').toString());
		}
	}

	void method2987(long l) {
		try {
			long l_109_;
			for (/**/; (((Class298_Sub19_Sub1) this).aLong9236 * 56522420256794041L <= l); ((Class298_Sub19_Sub1) this).aLong9236 = l_109_ * -5395595849438982007L) {
				int i = ((Class298_Sub19_Sub1) this).anInt9233 * -1094678159;
				int i_110_ = ((Class298_Sub19_Sub1) this).anInt9229 * -847832283;
				l_109_ = (56522420256794041L * ((Class298_Sub19_Sub1) this).aLong9236);
				while (i_110_ == (((Class298_Sub19_Sub1) this).anInt9229 * -847832283)) {
					while (((Class103) (((Class298_Sub19_Sub1) this).aClass103_9231)).anIntArray1105[i] == i_110_) {
						((Class298_Sub19_Sub1) this).aClass103_9231.method1089(i);
						int i_111_ = ((Class298_Sub19_Sub1) this).aClass103_9231.method1092(i);
						if (1 == i_111_) {
							((Class298_Sub19_Sub1) this).aClass103_9231.method1090();
							((Class298_Sub19_Sub1) this).aClass103_9231.method1098(i);
							if (((Class298_Sub19_Sub1) this).aClass103_9231.method1097()) {
								if (((Class298_Sub19_Sub1) this).aBoolean9217 && 0 != i_110_)
									((Class298_Sub19_Sub1) this).aClass103_9231.method1100(l_109_);
								else {
									method2972(true, 1442105861);
									((Class298_Sub19_Sub1) this).aClass103_9231.method1087();
									return;
								}
							}
							break;
						}
						if ((i_111_ & 0x80) != 0 && (i_111_ & 0xf0) != 144)
							method2981(i_111_, 2124246731);
						((Class298_Sub19_Sub1) this).aClass103_9231.method1091(i);
						((Class298_Sub19_Sub1) this).aClass103_9231.method1098(i);
					}
					((Class298_Sub19_Sub1) this).aLong9235 = 9035186418716527431L * l_109_;
					i = ((Class298_Sub19_Sub1) this).aClass103_9231.method1096();
					i_110_ = ((Class103) (((Class298_Sub19_Sub1) this).aClass103_9231)).anIntArray1105[i];
					l_109_ = ((Class298_Sub19_Sub1) this).aClass103_9231.method1095(i_110_);
				}
				((Class298_Sub19_Sub1) this).anInt9233 = i * 1034491793;
				((Class298_Sub19_Sub1) this).anInt9229 = -1484027731 * i_110_;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aib.bq(").append(')').toString());
		}
	}
}
