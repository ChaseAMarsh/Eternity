/* Class298_Sub32_Sub30 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub32_Sub30 extends Class298_Sub32 {
	public Class298_Sub32_Sub30() {
		super(0, true);
	}

	int[] method3131(int i, int i_0_) {
		try {
			int[] is = aClass257_7384.method2448(i, 227305520);
			if (aClass257_7384.aBoolean2810)
				Class425.method5740(is, 0, Class250.anInt2755 * -1474554145, Class250.anIntArray2760[i]);
			return is;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ahs.i(").append(')').toString());
		}
	}

	int[] method3332(int i) {
		int[] is = aClass257_7384.method2448(i, 943354587);
		if (aClass257_7384.aBoolean2810)
			Class425.method5740(is, 0, Class250.anInt2755 * -1474554145, Class250.anIntArray2760[i]);
		return is;
	}

	int[] method3333(int i) {
		int[] is = aClass257_7384.method2448(i, 1917492545);
		if (aClass257_7384.aBoolean2810)
			Class425.method5740(is, 0, Class250.anInt2755 * -1474554145, Class250.anIntArray2760[i]);
		return is;
	}

	public static int method3334(CacheIndex class243, byte i) {
		try {
			int i_1_ = 0;
			if (class243.method2310(-1217066055 * Class74.anInt692, -457216440))
				i_1_++;
			if (class243.method2310(Class74.anInt694 * -355151363, -457216440))
				i_1_++;
			if (class243.method2310(1838189665 * Class143.anInt1558, -457216440))
				i_1_++;
			if (class243.method2310(Class400.anInt5223 * 1862609057, -457216440))
				i_1_++;
			if (class243.method2310(Class74.anInt693 * -81301735, -457216440))
				i_1_++;
			if (class243.method2310(-2088314757 * Class74.anInt696, -457216440))
				i_1_++;
			if (class243.method2310(-1199789537 * Class298_Sub36.anInt7398, -457216440))
				i_1_++;
			if (class243.method2310(Class82_Sub6.anInt6842 * -2107184677, -457216440))
				i_1_++;
			if (class243.method2310(Class494.anInt6092 * -1624054445, -457216440))
				i_1_++;
			if (class243.method2310(1200791325 * Class74.anInt697, -457216440))
				i_1_++;
			if (class243.method2310(493809835 * Class257.anInt2802, -457216440))
				i_1_++;
			if (class243.method2310(1359711467 * Class237.anInt6667, -457216440))
				i_1_++;
			if (class243.method2310(Class128_Sub1.anInt8557 * -1848350339, -457216440))
				i_1_++;
			if (class243.method2310(Class298_Sub24_Sub1.anInt9281 * -328242359, -457216440))
				i_1_++;
			return i_1_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ahs.i(").append(')').toString());
		}
	}
}
