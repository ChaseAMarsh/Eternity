/* Class336_Sub6 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class336_Sub6 extends Class336 {
	public boolean method4091(int i, int i_0_, int i_1_, Class289 class289) {
		return (-1331662251 * toX == i_0_ && i_1_ == 1517720743 * toY);
	}

	Class336_Sub6() {
		/* empty */
	}

	public boolean method4089(int i, int i_2_, int i_3_, Class289 class289) {
		return (-1331662251 * toX == i_2_ && i_3_ == 1517720743 * toY);
	}

	public boolean method4090(int i, int i_4_, int i_5_, Class289 class289, int i_6_) {
		try {
			return (-1331662251 * toX == i_4_ && i_5_ == 1517720743 * toY);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acy.a(").append(')').toString());
		}
	}

	static final void method4106(ClientScript2 class403, byte i) {
		try {
			String string = (String) (((ClientScript2) class403).anObjectArray5240[(((ClientScript2) class403).anInt5241 -= 969361751) * -203050393]);
			Class12.method338(string, true, (short) 5563);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acy.ww(").append(')').toString());
		}
	}

	public static void method4107(Class113 class113, int i) {
		try {
			Class106.aClass113_1308 = class113;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acy.a(").append(')').toString());
		}
	}

	public static Class424[] method4108(int i) {
		try {
			return (new Class424[] { Class424.aClass424_6614, Class424.aClass424_6597, Class424.aClass424_6603, Class424.aClass424_6601, Class424.aClass424_6593, Class424.aClass424_6598, Class424.aClass424_6594, Class424.aClass424_6604, Class424.aClass424_6591, Class424.aClass424_6612, Class424.aClass424_6609, Class424.aClass424_6606, Class424.aClass424_6605, Class424.aClass424_6607, Class424.aClass424_6608, Class424.aClass424_6610, Class424.aClass424_6595, Class424.aClass424_6600, Class424.aClass424_6596, Class424.aClass424_6592, Class424.aClass424_6599, Class424.aClass424_6611, Class424.aClass424_6602 });
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acy.a(").append(')').toString());
		}
	}
}
