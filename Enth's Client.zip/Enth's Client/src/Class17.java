/* Class17 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class17 {
	int[] anIntArray233;
	short aShort234;
	short[] aShortArray235;
	short aShort236;
	int[] anIntArray237;
	short[] aShortArray238;
	short[] aShortArray239;
	short[] aShortArray240;
	short[] aShortArray241;
	byte[] aByteArray242;
	short[] aShortArray243;

	Class17() {
		/* empty */
	}
}
