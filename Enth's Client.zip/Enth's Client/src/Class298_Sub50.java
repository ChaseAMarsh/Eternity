/* Class298_Sub50 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class298_Sub50 extends Class298 {
	static int anInt7595 = 3;
	public static int anInt7596 = 0;
	static int anInt7597 = 1;
	public static int anInt7598 = -1;//TODO
	public static int anInt7599 = 6;
	static int anInt7600 = 4;
	public static int anInt7601 = 2;
	static int anInt7602 = 5;

	Class298_Sub50() {
		/* empty */
	}

	public abstract int method3546(int i);

	public abstract int method3547(byte i);

	public abstract int method3548(int i);

	public abstract long method3549(byte i);

	public abstract void method3550(int i);

	public abstract int method3551();

	public abstract long method3552();

	public abstract int method3553();

	public abstract int method3554();

	public abstract void method3555();

	public abstract long method3556();

	public abstract int method3557();

	public abstract long method3558();

	public abstract long method3559();

	public abstract int method3560(int i);

	public abstract int method3561();

	public abstract int method3562();

	public abstract void method3563();

	public abstract int method3564();

	public abstract int method3565();

	static Class211[] method3566(int i) {
		try {
			return (new Class211[] { Class211.aClass211_2408, Class211.aClass211_2416, Class211.aClass211_2412, Class211.aClass211_2407, Class211.aClass211_2419, Class211.aClass211_2414, Class211.aClass211_2411, Class211.aClass211_2417, Class211.aClass211_2413, Class211.aClass211_2409, Class211.aClass211_2415 });
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acr.a(").append(')').toString());
		}
	}

	public static void method3567(int i, int i_0_) {
		try {
			Class298_Sub37_Sub12 class298_sub37_sub12 = Class410.method4985(9, (long) i);
			class298_sub37_sub12.method3445(-1279082519);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acr.s(").append(')').toString());
		}
	}
}
