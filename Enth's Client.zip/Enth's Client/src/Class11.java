/* Class11 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class11 {
	static int anInt141 = 20074;
	static int anInt142 = 5030;
	static int anInt143 = 503;
	static long aLong144 = 64425238954L;
	static int anInt145 = 12010;
	static int anInt146 = 5033;
	static int anInt147 = 2018;
	static float aFloat148 = 1.1F;
	static int anInt149 = 10033;
	static int anInt150 = 1003;
	static int anInt151 = 101;
	static long aLong152 = 60129613779L;
	public static boolean aBoolean153 = false;
	public static boolean aBoolean154 = false;
	public static boolean aBoolean155 = false;
	public static int anInt156;

	Class11() throws Throwable {
		throw new Error();
	}

	static final void method326(ClientScript2 class403, byte i) {
		try {
			int i_0_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_0_, (byte) -80);
			Class119 class119 = Class389.aClass119Array4165[i_0_ >> 16];
			Class148.method1616(class105, class119, class403, -2017048321);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("al.fw(").append(')').toString());
		}
	}

	static final void method327(ClientScript2 class403, short i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_1_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239]);
			int i_2_ = (((ClientScript2) class403).anIntArray5244[1 + ((ClientScript2) class403).anInt5239 * 681479919]);
			Class497 class497 = Class92.aClass504_905.method6251(i_2_, 831421944);
			if (class497.method6206(1883696427))
				((ClientScript2) class403).anObjectArray5240[((((ClientScript2) class403).anInt5241 += 969361751) * -203050393) - 1] = Class363.aClass339_3931.method4116(i_1_, -1801093114).method4239(i_2_, class497.aString6101, (byte) -38);
			else
				((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919) - 1] = (Class363.aClass339_3931.method4116(i_1_, -183647434).method4241(i_2_, -388931549 * class497.anInt6100, 1379930702));
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("al.amg(").append(')').toString());
		}
	}

	static int method328(byte[] is, int i, int i_3_, int i_4_) {
		try {
			int i_5_ = -1;
			for (int i_6_ = i; i_6_ < i_3_; i_6_++)
				i_5_ = i_5_ >>> 8 ^ (RsByteBuffer.anIntArray7614[(i_5_ ^ is[i_6_]) & 0xff]);
			i_5_ ^= 0xffffffff;
			return i_5_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("al.a(").append(')').toString());
		}
	}

	static void method329(int i) {
		try {
			Class79.anInt734 = 0;
			Class417.aClass298_Sub13_5337 = null;
			Class298_Sub32_Sub22.aClass272_9466 = null;
			Class79.aClass243_744 = null;
			Class79.aClass298_Sub19_Sub1_748 = null;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("al.v(").append(')').toString());
		}
	}

	static final void method330(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = (null != WorldMap.aClass298_Sub37_Sub13_3218 ? -947282109 * WorldMap.aClass298_Sub37_Sub13_3218.anInt9643 : -1);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("al.aea(").append(')').toString());
		}
	}

	static final void method331(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = (int) (Class247.aLong2748 * -536549149186981023L / 60000L);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = (int) ((Class247.aLong2748 * -536549149186981023L - Class122.method1319((byte) 1) - Class298_Sub35.aLong7395 * -7323824110069770829L) / 60000L);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class510.aBoolean6222 ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("al.amh(").append(')').toString());
		}
	}
}
