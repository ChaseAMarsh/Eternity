/* Class179 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class179 {
	static Class179 aClass179_1811 = new Class179();
	public static Class179 aClass179_1812 = new Class179();

	Class179() {
		/* empty */
	}
}
